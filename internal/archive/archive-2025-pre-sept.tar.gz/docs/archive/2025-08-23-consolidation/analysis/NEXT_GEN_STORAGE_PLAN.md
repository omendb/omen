# Next-Generation Storage Architecture for OmenDB
*Created: August 23, 2025*

## 🚫 **Why Traditional WAL Storage is Wrong for Vector Databases**

### **Research Analysis (2024-2025)**
- **Qdrant abandoned RocksDB/WAL** → Custom "Gridstore" (2x faster)
- **Milvus uses object storage** + memory-mapped files
- **AiSAQ research**: 10MB memory for billion-scale (vs our 25MB buffer)
- **NDSEARCH**: 31.7x throughput with near-data processing
- **Fresh-DiskANN**: Real-time updates without WAL overhead

### **Why Our WAL Implementation is Obsolete**
| Issue | Traditional WAL | Vector Database Reality |
|-------|-----------------|------------------------|
| **Workload** | Random OLTP updates | Graph topology changes |
| **Consistency** | ACID transactions | Eventual consistency OK |
| **Access Pattern** | Sequential logs | Random graph traversals |
| **Recovery** | Point-in-time replay | Index reconstruction |
| **Performance** | ~1.4ms latency | **Need <0.5ms** |

## 🏆 **State-of-the-Art Vector Storage (2025)**

### **Memory-Mapped Graph Storage** ⭐
```mojo
struct DiskANNStorage:
    var graph_mmap: MemoryMappedFile     # HNSW graph structure  
    var vectors_mmap: MemoryMappedFile   # Raw vector data
    var metadata_store: CompressedKV     # Minimal metadata
    var update_buffer: AsyncRingBuffer   # Hot writes
```

**Benefits:**
- **OS-managed caching**: No manual buffer management
- **Zero-copy access**: Direct pointer arithmetic 
- **SSD-optimized**: Block-aligned, prefetch-friendly
- **Incremental updates**: No full checkpoints

### **Research-Backed Optimizations**

**1. AiSAQ-Style Compression** (Feb 2025)
- **Product Quantization** for 10x memory reduction
- **SSD-native compressed vectors**
- **Runtime decompression** during search

**2. NDSEARCH Near-Data Processing** (May 2024)  
- **Custom SSD access patterns** for graph traversal
- **Prefetch optimization** during search
- **31.7x throughput** vs traditional approaches

**3. AGILE Async GPU-SSD** (Apr 2025)
- **Direct GPU-SSD** without CPU bottleneck
- **HBM-based caching** for hot data
- **Asynchronous prefetching** during operations

## 🎯 **Implementation Roadmap**

### **Phase 1: Memory-Mapped Foundation** (2-3 weeks)
```mojo
# New core storage interface
struct MemoryMappedStorage(StorageEngine):
    var graph_file: MemoryMappedFile
    var vector_file: MemoryMappedFile
    var hot_buffer: VectorBuffer
    var compaction_task: Optional[Task]
```

**Tasks:**
1. ✅ Create memory-mapped file abstractions
2. ✅ Implement SSD-optimized block layout
3. ✅ Add async background compaction  
4. ✅ Integrate with existing DiskANN algorithm

**Expected Performance:** 2-3x faster persistence, 50% less memory

### **Phase 2: Research Integration** (3-4 weeks)
1. **AiSAQ compression** integration
2. **Graph-aware prefetching** during search
3. **Streaming updates** without checkpoints
4. **SSD access pattern optimization**

**Expected Performance:** 5-10x faster than current, 10MB memory target

### **Phase 3: Next-Gen Engine** (6-8 weeks)
1. **DiskANN-native storage format**
2. **GPU-SSD async integration** (when Mojo supports)
3. **Vector compression** with runtime decompression
4. **Distributed graph partitioning**

**Expected Performance:** Match AiSAQ (10MB memory, billion-scale)

## 📊 **Performance Targets vs Research**

| Metric | Current | Phase 1 Target | Research SOTA |
|--------|---------|----------------|---------------|
| **Insert Latency** | 1.4ms | **0.7ms** | 0.5ms (NDSEARCH) |
| **Memory Usage** | 25MB buffer | **12MB** | 10MB (AiSAQ) |
| **Throughput** | 70K vec/s | **150K vec/s** | 200K+ vec/s |
| **Storage Format** | Snapshot dumps | **Incremental** | Streaming |

## 🔧 **DiskANN-Specific Optimizations**

### **Graph Topology Awareness**
```mojo
# Optimize for graph traversal patterns
struct GraphAwareLayout:
    var node_clusters: List[MemoryBlock]  # Spatial locality
    var edge_cache: SIMDAlignedBuffer     # Prefetch-friendly  
    var vector_blocks: CompressedSegments # AiSAQ-style compression
```

### **SSD Access Pattern Optimization**
- **Block-aligned graph nodes** for NVMe efficiency
- **Prefetch groups** based on graph connectivity
- **Async I/O** for background graph maintenance
- **ZNS SSD support** for append-only patterns

### **Real-Time Update Protocol**
```mojo
# Replace checkpointing with streaming
struct StreamingDiskANN:
    var memory_tier: VectorBuffer        # Hot data in memory  
    var ssd_tier: MemoryMappedGraph      # Cold data on SSD
    var update_stream: AsyncChannel      # Background updates
```

## 🚀 **Implementation Priority**

**Skip WAL Compilation Fixes** → **Jump to Memory-Mapped Storage**

**Rationale:**
1. **Traditional WAL = 2x slower** than state-of-the-art 
2. **Memory-mapped = foundation** for all 2025 optimizations
3. **Research shows 10-30x gains** possible with modern approaches
4. **4 hours WAL fixes < 2 weeks memory-mapped** with 10x better result

**Next Action:** Implement `MemoryMappedStorage` struct with SSD-optimized layout

---

**Bottom Line**: Our current storage is 2 generations behind. The research shows clear path to 10x performance gains through memory-mapping and DiskANN-specific optimizations. Skip legacy WAL → Build 2025 storage architecture.