# OmenDB Technical Specification
*Version: 0.2.0-beta | Last Updated: 2025-08-23*

## Architecture Overview

OmenDB is an embedded vector database written in pure Mojo, designed as the "DuckDB of vector databases" - embedded, fast, and simple.

### Core Stack
```
┌─────────────────────────────────────┐
│         Python API Layer            │  ← User interface
│    (numpy/list input support)       │
├─────────────────────────────────────┤
│         Mojo FFI Bridge             │  ← BOTTLENECK (0.66ms/vector)
├─────────────────────────────────────┤
│         Mojo Core Engine            │  ← Pure Mojo implementation
│  ┌─────────────────────────────┐   │
│  │   VectorStore (Buffer)      │   │  ← Deferred indexing (10K threshold)
│  ├─────────────────────────────┤   │
│  │   DiskANN Index             │   │  ← Graph-based index
│  ├─────────────────────────────┤   │
│  │   SnapshotStorage           │   │  ← Persistence layer
│  └─────────────────────────────┘   │
├─────────────────────────────────────┤
│      File System Storage            │  ← .omen files
└─────────────────────────────────────┘
```

## Technology Choices

### Language: Mojo
**Rationale**: 
- Python-compatible syntax
- Systems-level performance potential
- No GC overhead
- SIMD/GPU capabilities

**Current Limitations**:
- FFI overhead (can't do true zero-copy yet)
- No stable memory pools
- Limited ecosystem

### Algorithm: DiskANN
**Rationale**:
- No rebuilds needed (vs HNSW)
- Incremental construction
- Bounded memory usage
- Microsoft Research proven

**Implementation**:
- R=16, L=32, alpha=1.2 (default params)
- Robust pruning for bounded degree
- Entry point navigation
- Deferred indexing for batch operations

### Storage: SnapshotStorage
**Rationale**:
- Simple binary format
- Atomic writes
- Fast recovery
- No external dependencies

**Format**:
```
[magic_bytes][version][vector_count][dimension]
[vector_0_id][vector_0_data]
[vector_1_id][vector_1_data]
...
```

## Design Patterns

### 1. Deferred Indexing
```mojo
# Buffer writes, build index at threshold
if buffer.size < 10000:
    buffer.append(vector)  # Fast O(1)
else:
    build_index_from_buffer()  # Batch build
```

### 2. Unified Processing Path
- Same code path for numpy/lists
- No special casing that adds complexity
- Easier to optimize one path well

### 3. Value Semantics
- Mojo ownership model
- No shared mutable state
- Clear lifecycle management

## Performance Analysis

### Current Performance (2025-08-23)
```
Metric          | Current | Target  | Gap
----------------|---------|---------|--------
Batch Insert    | 1,465/s | 20,000/s| 13.6x
FFI Overhead    | 0.66ms  | 0.05ms  | 13.2x
Memory/Vector   | 16KB    | 2KB     | 8x
Search Latency  | 0.6ms   | 0.5ms   | 1.2x
```

### Bottleneck Breakdown
```
Operation       | Time    | % Total | Fix
----------------|---------|---------|------------------
FFI Conversion  | 0.66ms  | 65%     | Phase 1: Numpy buffer
Memory Alloc    | 0.15ms  | 15%     | Phase 2: Memory pool
Distance Calc   | 0.08ms  | 8%      | Phase 3: SIMD
Graph Build     | 0.12ms  | 12%     | Phase 3: Batch build
```

## Security Considerations

### Input Validation
- Dimension checking on all inputs
- Bounds checking for searches
- ID uniqueness enforcement

### Memory Safety
- Mojo's ownership prevents use-after-free
- Bounds checking on all array access
- No buffer overflows possible

### Persistence Security
- Atomic writes prevent corruption
- Version checking on load
- Magic bytes validation

## Performance Targets

### Phase 1 (FFI Fix)
- **Target**: 5,000 vec/s
- **Approach**: True numpy zero-copy
- **Validation**: numpy 10x faster than lists

### Phase 2 (Memory)
- **Target**: 10,000 vec/s
- **Approach**: Flat storage, memory pools
- **Validation**: No malloc in hot path

### Phase 3 (Algorithm)
- **Target**: 20,000 vec/s
- **Approach**: SIMD, optimized params
- **Validation**: Profile shows balanced time

### Phase 4 (Hybrid - if needed)
- **Target**: 50,000 vec/s
- **Approach**: C/Rust backend
- **Validation**: Competitive with LanceDB

## API Design

### Core Operations
```python
# Batch insert (primary optimization target)
db.add_batch(vectors: np.ndarray) -> List[str]

# Search (must stay <1ms)
db.search(query: np.ndarray, limit: int) -> List[Result]

# Persistence
db.set_persistence(path: str) -> bool
db.checkpoint() -> bool
db.recover() -> int
```

### Design Principles
1. **Numpy-first**: Optimize for numpy arrays
2. **Batch-oriented**: Batch operations always faster
3. **Simple**: Minimal configuration required
4. **Pythonic**: Follow Python conventions

## Implementation Status

### ✅ Completed
- DiskANN algorithm implementation
- Deferred indexing (10K threshold)
- Persistence with checkpoint/recovery
- Python API with numpy support
- Basic search functionality

### 🚧 In Progress
- Phase 1: FFI optimization
- Performance testing framework
- Documentation updates

### 📋 Planned
- Phase 2: Memory optimization
- Phase 3: Algorithm optimization
- Phase 4: Hybrid architecture (if needed)

## File Structure
```
omendb/
├── native.mojo           # Entry point, FFI bridge
├── algorithms/
│   └── diskann.mojo     # Core algorithm
├── core/
│   ├── vector_buffer.mojo  # Buffer for deferred indexing
│   ├── storage.mojo        # Persistence layer
│   └── memory_pool.mojo    # Memory management (disabled)
└── python/
    └── omendb/
        └── api.py          # Python interface
```

## Testing Requirements

### Unit Tests
- Algorithm correctness
- Storage integrity
- API contracts

### Performance Tests
- Batch vs single operations
- Numpy vs lists
- Search latency at scale

### Regression Tests
- No performance degradation
- Backward compatibility
- Data integrity

## Deployment Considerations

### Embedded Usage
```python
import omendb

# Single-file database
db = omendb.DB()
db.set_persistence("vectors.omen")
```

### Resource Requirements
- Memory: ~2GB for 1M vectors (target)
- Disk: ~512MB for 1M 128d vectors
- CPU: Benefits from AVX2/AVX512

### Platform Support
- Linux x86_64 ✅
- macOS ARM64 ✅
- Windows ❌ (Mojo limitation)