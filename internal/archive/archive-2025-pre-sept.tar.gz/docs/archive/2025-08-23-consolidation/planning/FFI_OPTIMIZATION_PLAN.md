# FFI Optimization Implementation Plan

**Created**: August 21, 2025

## Problem Analysis

### Current Bottleneck
- **66ms overhead** for 100 vectors (0.66ms per vector)
- Python list → Mojo conversion is element-by-element
- 10x slower than it should be

### Root Cause
```python
# CURRENT (slow) - from native.mojo line 2055-2058
for j in range(vec_len):
    var elem = vector_list[j]
    var float_val = Float64(python.float(elem))
    vector.append(Float32(float_val))
```
Each element goes through: Python → Float64 → Float32 → Mojo List

## Solution: Zero-Copy Numpy Interface

### Implementation (see ffi_optimization.mojo)

Using the pattern from `modular/mojo/integration-test/python-extension-modules/basic-numpy-raw/`:

```mojo
@register_passable("trivial")
struct PyArrayObject[dtype: DType]:
    var data: UnsafePointer[Scalar[dtype]]  # Direct memory pointer!
    var nd: Int
    var dimensions: UnsafePointer[Int]
    var strides: UnsafePointer[Int]
    # ...
```

### Performance Gains

| Operation | Current | With Zero-Copy | Speedup |
|-----------|---------|----------------|---------|
| Get numpy pointer | N/A | <0.001ms | N/A |
| Copy 100 vectors | 66ms | 0.1ms | 660x |
| Total batch add | 70ms | 4ms | 17.5x |

## Implementation Steps

### Phase 1: Basic Zero-Copy (This Week)
1. Add `PyArrayObject` struct to native.mojo
2. Implement `get_numpy_array_ptr()` function
3. Update `add_vector_batch()` to use zero-copy path
4. Test with benchmarks

### Phase 2: Columnar Integration (Next Week)
1. Modify storage to accept columnar layout
2. Direct memcpy from numpy to columnar storage
3. Single operation for entire batch

### Phase 3: Full Pipeline Optimization
1. Return numpy arrays from search
2. Zero-copy for all operations
3. Benchmark against FAISS

## Code Changes Required

### 1. native.mojo
```mojo
# Add at top
from ffi_optimization import PyArrayObject, get_numpy_array_ptr

# Replace line 2038
numpy_ptr = get_numpy_array_ptr[DType.float32](vectors_array)

# Replace lines 2055-2058 with
memcpy(vector.unsafe_ptr(), numpy_ptr.offset(i * dimension), dimension * 4)
```

### 2. api.py
```python
# Ensure numpy arrays are passed through
if isinstance(vectors, np.ndarray):
    if vectors.dtype != np.float32:
        vectors = vectors.astype(np.float32)
    # Pass directly to native
    return _native.add_vector_batch(ids, vectors, metadata)
```

## Testing Plan

```python
# benchmarks/test_ffi_zero_copy.py
import numpy as np
import omendb

# Test 1: Python lists (current)
py_vectors = [[float(i) for i in range(128)] for _ in range(1000)]
# Time: ~660ms

# Test 2: Numpy arrays (optimized)  
np_vectors = np.array(py_vectors, dtype=np.float32)
# Time: ~10ms (66x faster!)

# Test 3: Large batch
np_large = np.random.rand(10000, 128).astype(np.float32)
# Should handle 10K vectors in <100ms
```

## Risks & Mitigations

| Risk | Mitigation |
|------|------------|
| Memory alignment issues | Ensure numpy arrays are C-contiguous |
| Type mismatches | Validate dtype=float32 before zero-copy |
| Lifetime management | Keep Python object alive during operation |
| Platform differences | Test on Linux/macOS separately |

## Success Metrics

- [ ] FFI overhead < 1ms for 100 vectors
- [ ] Batch add > 50K vec/s with numpy
- [ ] No memory leaks or segfaults
- [ ] Tests pass on all platforms

## Next Steps After FFI

Once FFI is fixed, the path is clear:
1. **Columnar storage** - 2x additional speedup
2. **Memory-mapped files** - Instant startup
3. **Server mode** - HTTP/gRPC wrapper

With all optimizations: **60-80K vec/s** (beating all competitors except FAISS)