# OmenDB Documentation Index
*Last Updated: August 23, 2025*

## Directory Structure & Contents

### 📍 Root Level (Key Files)
- `TECH_SPEC.md` - Core architecture, technology stack, design decisions
- `TODO.md` - Active task list and priorities
- `COMPETITIVE_ANALYSIS.md` - Competitor analysis (duplicate - use internal/current/)

### 📂 `/implementation/` - How to Build Features
- `IMPLEMENTATION_GUIDE.md` - Step-by-step guide to reach 50K+ vec/s
- `FFI_INTEGRATION_PLAN.md` - FFI optimization strategy
- `FFI_INTEGRATION_STATUS.md` - Current FFI implementation status
- `FFI_BOTTLENECK_ANALYSIS.md` - FFI performance analysis
- `FINAL_FFI_ANALYSIS.md` - How we achieved 67K vec/s
- `REALITY_CHECK.md` - Honest assessment of challenges
- `UNIFIED_API_DESIGN.md` - API architecture decisions

### 📂 `/internal/` - Private Analysis & Strategy

#### `/internal/current/` - Active Work (THIS SPRINT)
- `MASTER_STATUS.md` - Overall project status
- `CURRENT_SPRINT.md` - Current sprint tasks
- `PERFORMANCE_FIX_PLAN.md` - Fix 70K→665 vec/s regression
- `NEXT_GEN_STORAGE_PLAN.md` - Memory-mapped storage implementation
- `COMPETITIVE_ANALYSIS.md` - Why competitors are faster
- `FFI_OPTIMIZATION_PLAN.md` - FFI improvements roadmap
- `DEV_ROADMAP_AUG_2025.md` - Development roadmap
- `KNOWN_ISSUES.md` - Active bugs and issues
- `STRATEGY.md` - Overall technical strategy

#### `/internal/strategy/` - Long-term Decisions
- `DISKANN_COMPLETE_STRATEGY.md` - Why DiskANN-only approach
- `STORAGE_ENGINE_FUTURE.md` - Storage architecture vision

#### `/internal/audits/` - Code Quality
- `CODEBASE_AUDIT_AUG_21.md` - Recent code audit
- `MEMORY_CORRUPTION_AUDIT.md` - Memory safety analysis
- `PRE_RELEASE_AUDIT.md` - Release readiness check

#### `/internal/business/` - Company Strategy
- `INVESTOR_OVERVIEW.md` - Investor pitch materials
- `YC_APPLICATION_DRAFT.md` - YC application
- `business.md` - Business strategy

### 📂 `/archive/` - Historical Reference

#### `/archive/old/` - Outdated docs (reference only)
- Previous iterations of current docs
- Old implementation attempts
- Historical decisions

#### `/archive/performance/` - Past optimization work
- Previous benchmark results
- Old optimization strategies
- SIMD attempts that failed

#### `/archive/redundant/` - Duplicates and obsolete
- Files moved here during cleanup
- Superseded documentation

## 🎯 Which Files to Include for Tasks

### Performance Optimization
```bash
@docs/internal/current/PERFORMANCE_FIX_PLAN.md
@docs/internal/current/COMPETITIVE_ANALYSIS.md
@docs/implementation/IMPLEMENTATION_GUIDE.md
```

### Storage Work
```bash
@docs/internal/current/NEXT_GEN_STORAGE_PLAN.md
@docs/internal/strategy/STORAGE_ENGINE_FUTURE.md
```

### Bug Fixes
```bash
@docs/internal/current/KNOWN_ISSUES.md
@docs/internal/current/MASTER_STATUS.md
```

### Architecture Decisions
```bash
@docs/TECH_SPEC.md
@docs/internal/strategy/DISKANN_COMPLETE_STRATEGY.md
@docs/implementation/UNIFIED_API_DESIGN.md
```

### Sprint Planning
```bash
@docs/TODO.md
@docs/internal/current/CURRENT_SPRINT.md
@docs/internal/current/DEV_ROADMAP_AUG_2025.md
```

## 📋 Documentation Rules

1. **Single Source of Truth**: Each piece of information lives in ONE place
2. **Current vs Archive**: Active work in `/internal/current/`, old in `/archive/`
3. **Implementation vs Strategy**: How-to guides in `/implementation/`, decisions in `/internal/strategy/`
4. **Token Efficiency**: Reference files by path, don't duplicate content
5. **Clear Naming**: File names should clearly indicate content and relevance

## 🚨 Common Pitfalls

- Don't create new docs without checking if info already exists
- Don't put internal/private docs in the public repo
- Don't duplicate information across multiple files
- Always update INDEX.md when adding/moving docs
- Archive old docs instead of deleting (preserves history)