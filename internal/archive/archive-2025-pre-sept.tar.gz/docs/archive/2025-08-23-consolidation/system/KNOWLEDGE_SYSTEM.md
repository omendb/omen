# OmenDB AI Agent Knowledge System
*System Version: 1.0 | Created: 2025-08-23*

## 🎯 Design Principles

### 1. Living Documents Over Static Files
- **CURRENT_STATE.md** - Single source of truth, always current
- **CONTEXT_MAPS/** - Task-specific includes, never duplicated
- **DECISIONS.md** - Append-only decision log with rationale

### 2. Automatic Staleness Detection
```yaml
---
expires: 2025-08-30  # Force review after this date
version: 1.2.3       # Tied to code version
last_verified: 2025-08-23
update_triggers:
  - "After each performance test"
  - "When architecture changes"
  - "On version release"
---
```

### 3. Progressive Context Loading
```bash
# Minimal context (always include)
@CURRENT_STATE.md     # 2-3KB snapshot of NOW

# Task-specific contexts (include as needed)
@CONTEXT_MAPS/performance.md  # Links to perf files
@CONTEXT_MAPS/storage.md      # Links to storage files
@CONTEXT_MAPS/debugging.md    # Links to debug files

# Deep dive (rarely needed)
@[specific implementation file]
```

## 📂 Optimal Structure

```
omendb-cloud/
├── CURRENT_STATE.md          # LIVING - Always current snapshot
├── DECISIONS.md              # APPEND-ONLY - Never edit, only add
├── KNOWLEDGE_SYSTEM.md       # THIS FILE - How to use the system
│
├── CONTEXT_MAPS/             # Task-specific include lists
│   ├── performance.md        # What to include for perf work
│   ├── storage.md           # What to include for storage work
│   ├── architecture.md      # What to include for design work
│   ├── debugging.md         # What to include for bug fixes
│   └── release.md           # What to include for releases
│
├── SPECIFICATIONS/           # Immutable specs (version controlled)
│   ├── architecture_v1.md   # Original design
│   ├── architecture_v2.md   # Current design
│   └── api_v0.2.0.md       # API for this version
│
├── ANALYSIS/                 # Deep dives (reference only)
│   ├── competitive/         # Competitor analysis
│   ├── performance/         # Performance investigations  
│   └── postmortems/        # What went wrong and why
│
└── archive/                  # Old stuff (never delete, rarely read)
```

## 📋 CURRENT_STATE.md Template

```markdown
# OmenDB Current State
*Auto-updated: [timestamp] | Version: [version] | Expires: [date]*

## Metrics Dashboard
| Metric | Current | Target | Status |
|--------|---------|--------|--------|
| Throughput | X vec/s | Y vec/s | 🔴🟡🟢 |
| Latency | Xms | Yms | 🔴🟡🟢 |

## Active Issues (Top 3)
1. **[Issue]** - [Impact] - [Status]
2. **[Issue]** - [Impact] - [Status]
3. **[Issue]** - [Impact] - [Status]

## In Progress
- [ ] Task 1 (Owner, ETA)
- [ ] Task 2 (Owner, ETA)

## Key Files
- Main: `path:lines` - Description
- Hot: `path:lines` - Currently editing

## Recent Decisions
- [Date]: [Decision] → [Impact]

## Next Actions
1. Immediate: [What]
2. Today: [What]
3. This Week: [What]
```

## 🔄 Update Protocol

### What Updates When

| Document | Update Trigger | Owner | Frequency |
|----------|---------------|-------|-----------|
| CURRENT_STATE.md | Any significant change | Active developer | Daily during sprints |
| DECISIONS.md | Major decisions only | Append only | As needed |
| CONTEXT_MAPS/* | New workflow discovered | Anyone | Rarely |
| SPECIFICATIONS/* | New version/release | Tech lead | Per version |

### Update Commands

```bash
# Quick state update (most common)
./scripts/update_state.sh

# Add decision (append-only)
echo "$(date +%Y-%m-%d): Decision - Rationale - Impact" >> DECISIONS.md

# Version bump (creates new spec)
./scripts/version_bump.sh v0.2.1
```

## 🎯 Task-Based Context Loading

### Performance Optimization
```bash
@CURRENT_STATE.md
@CONTEXT_MAPS/performance.md
# Then follow the map to specific files
```

### Bug Fix
```bash
@CURRENT_STATE.md
@CONTEXT_MAPS/debugging.md
# Then follow the map to error logs/traces
```

### Architecture Change
```bash
@CURRENT_STATE.md
@DECISIONS.md  # Check past decisions
@CONTEXT_MAPS/architecture.md
@SPECIFICATIONS/architecture_v2.md
```

## ⚙️ Automation Opportunities

### 1. Auto-generate CURRENT_STATE.md
```python
# scripts/update_state.py
def update_current_state():
    metrics = run_benchmarks()
    issues = get_github_issues(label='critical')
    todos = parse_todo_files()
    
    with open('CURRENT_STATE.md', 'w') as f:
        f.write(render_template(metrics, issues, todos))
```

### 2. Staleness Warnings
```python
# Check at start of each session
if document.expires < today:
    warn(f"{document} is stale - needs review")
```

### 3. Context Size Optimization
```python
# Automatically suggest minimal context
def suggest_context(task_description):
    always = ['@CURRENT_STATE.md']
    
    if 'performance' in task:
        return always + ['@CONTEXT_MAPS/performance.md']
    elif 'bug' in task:
        return always + ['@CONTEXT_MAPS/debugging.md']
    # etc...
```

## 🚫 Anti-Patterns to Avoid

1. **Don't duplicate information** - Link to it instead
2. **Don't edit immutable docs** - Create new versions
3. **Don't create "summary of summary"** - Use progressive disclosure
4. **Don't forget expiration dates** - Set them on creation
5. **Don't mix concerns** - Keep task contexts separate

## 📊 Success Metrics

- **Update frequency**: CURRENT_STATE.md updated daily during active development
- **Context size**: Average task needs <10KB of context
- **Staleness**: No doc older than 1 week during sprints
- **Duplication**: Zero duplicate information across docs
- **Find-ability**: Any info reachable in ≤3 includes

## 🔧 Implementation Checklist

- [ ] Create CURRENT_STATE.md from current STATUS.md
- [ ] Create CONTEXT_MAPS/ directory with task maps
- [ ] Add expiration dates to all living documents
- [ ] Create update_state.sh script
- [ ] Move immutable specs to SPECIFICATIONS/
- [ ] Archive old analyses
- [ ] Set up staleness checks
- [ ] Document update triggers

## 💡 Key Insight

The best documentation system is one that:
1. **Stays current automatically** (scripts, not manual updates)
2. **Loads progressively** (summary → details as needed)  
3. **Expires explicitly** (forces review, prevents staleness)
4. **Maps to tasks** (context follows work patterns)
5. **Separates concerns** (living vs immutable vs historical)

This system minimizes maintenance burden while maximizing AI agent effectiveness.