# AI Agent Instructions for OmenDB Documentation
*How to use and maintain the knowledge system effectively*

## 🎯 Your Primary Responsibilities

1. **Keep CURRENT_STATE.md updated** - This is the single source of truth
2. **Append to DECISIONS.md** - Never edit, only add new decisions
3. **Use CONTEXT_MAPS/** - Load only required context for each task
4. **Check expiration dates** - Flag stale documents for review

## 📋 Task Workflows

### Starting Any Task
```bash
# 1. ALWAYS start with:
@CURRENT_STATE.md

# 2. Identify task type and load appropriate context map:
- Performance issue? → @CONTEXT_MAPS/performance.md
- Storage work? → @CONTEXT_MAPS/storage.md  
- Bug fix? → @CONTEXT_MAPS/debugging.md
- Architecture? → @CONTEXT_MAPS/architecture.md

# 3. Follow the context map to load specific files
```

### After Making Changes

#### If you changed performance:
```bash
# 1. Run benchmark
PYTHONPATH=/Users/nick/github/omendb/omendb/python:$PYTHONPATH python benchmarks/quick_benchmark.py

# 2. Update CURRENT_STATE.md metrics dashboard
[Edit "Metrics Dashboard" section with new numbers]

# 3. If major improvement/regression, append to DECISIONS.md
echo "2025-08-23: [What changed] 
Why: [Reason]
Impact: [Performance change]
Result: [New metric]" >> DECISIONS.md
```

#### If you fixed a bug:
```bash
# 1. Update CURRENT_STATE.md
- Remove from "Active Issues" if fixed
- Update metrics if affected

# 2. Document if architectural impact
[Append to DECISIONS.md if the fix required design change]
```

#### If you made architectural decision:
```bash
# Always append to DECISIONS.md
echo "[Date]: [Decision]
Why: [Detailed rationale]
Impact: [What will change]
Result: [TBD or actual result]" >> DECISIONS.md
```

## 🔄 Update Patterns

### Pattern: Check Staleness
```python
# At start of session, check dates
if "Expires:" in document and expires_date < today:
    print(f"⚠️ {document} is stale - needs review")
    # Flag for human review
```

### Pattern: Update Metrics
```markdown
# In CURRENT_STATE.md, update the metrics table:
| Metric | Current | Target | Status |
|--------|---------|--------|--------|
| Throughput | NEW_VALUE vec/s | 50K+ vec/s | 🔴🟡🟢 |

# Status indicators:
🟢 Meeting/exceeding target
🟡 Acceptable but needs work  
🔴 Critical issue
```

### Pattern: Track Progress
```markdown
# In CURRENT_STATE.md "In Progress" section:
- [x] Completed task
- [ ] Pending task (Owner, ETA)
```

## 📁 File Organization Rules

### What Goes Where
- **CURRENT_STATE.md** - Only current snapshot (metrics, active issues, in-progress)
- **DECISIONS.md** - Append-only technical decisions with rationale
- **CONTEXT_MAPS/** - Never edit unless adding new workflow
- **docs/internal/current/** - Active development docs
- **docs/archive/** - Old stuff (don't update, don't delete)

### When to Create New Files
- **DON'T** create summaries of summaries
- **DON'T** duplicate existing information
- **DO** create new CONTEXT_MAP if discovering new workflow
- **DO** create new version of spec for major version bump

## 🚫 Common Mistakes to Avoid

1. **Editing old entries in DECISIONS.md** - Only append!
2. **Forgetting to update CURRENT_STATE.md** - Update after every significant change
3. **Including too much context** - Follow CONTEXT_MAPS exactly
4. **Creating redundant documentation** - Check if info exists first
5. **Not checking expiration dates** - Always check at session start

## ✅ Quick Checklist

Before completing any task:
- [ ] CURRENT_STATE.md updated with latest metrics?
- [ ] Active issues list current?
- [ ] In-progress tasks updated?
- [ ] Major decisions appended to DECISIONS.md?
- [ ] No duplicate information created?
- [ ] Context was minimal but sufficient?

## 🔧 Maintenance Commands

```bash
# Update metrics after benchmark
./scripts/update_metrics.sh  # TODO: Create this

# Check for stale docs
find . -name "*.md" -exec grep -l "Expires:" {} \; | while read f; do
    # Check if expired
done

# Quick status update
echo "Updated: $(date +%Y-%m-%d)" > LAST_UPDATED
```

## 📊 Success Metrics for Documentation

- CURRENT_STATE.md updated daily during active development
- Zero duplicate information across files
- Average context load <10KB per task
- All decisions traceable in DECISIONS.md
- No documentation older than 1 week during sprints

## 🎯 Remember

**Your goal**: Maintain a single source of truth (CURRENT_STATE.md) while keeping historical context (DECISIONS.md) and task-specific guidance (CONTEXT_MAPS/) separate and clean.

**Key principle**: It's better to update one file frequently than to create many files that go stale.