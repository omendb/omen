# Storage & Persistence Context Map
*For: Database persistence, checkpointing, recovery*
*Updated: 2025-08-23 | Next Review: 2025-08-30*

## Always Include (Base Context)
```bash
@CURRENT_STATE.md                                    # Current state
@CONTEXT_MAPS/storage.md                            # This file
```

## Task-Specific Includes

### Fixing Checkpoint Performance
```bash
# Add to base:
@omendb/core/memory_mapped_storage.mojo             # Memory-mapped implementation
@omendb/core/storage.mojo                           # Storage interface
@docs/internal/current/NEXT_GEN_STORAGE_PLAN.md     # Storage architecture
```

### Implementing New Storage Backend
```bash
# Add to base:
@omendb/core/storage.mojo                           # Interface to implement
@docs/internal/strategy/STORAGE_ENGINE_FUTURE.md    # Storage vision
@DECISIONS.md                                        # Storage decisions
```

### Debugging Storage Issues
```bash
# Add to base:
@test_memory_mapped_storage.py                      # Storage tests
@omendb/native.mojo:271-310                        # Recovery function
[Check error logs for specific line numbers]
```

## Key Storage Metrics
- Checkpoint throughput: 665 vec/s (Target: 50K+)
- Recovery speed: Unknown (Target: 100K+ vec/s)
- File size: ~40MB/1M vectors (Target: <20MB)
- WAL overhead: N/A (using memory-mapped)

## Update Triggers
- After storage implementation → Update NEXT_GEN_STORAGE_PLAN.md
- After performance test → Update checkpoint metrics in CURRENT_STATE.md
- After architecture change → Add decision to DECISIONS.md

## Common Patterns

### Pattern: Implement Storage Feature
```bash
# 1. Check interface requirements
@omendb/core/storage.mojo  # trait StorageEngine

# 2. Implement in new file or modify existing
@omendb/core/memory_mapped_storage.mojo

# 3. Test implementation
python test_memory_mapped_storage.py

# 4. Update documentation
[Update CURRENT_STATE.md with results]
```

### Pattern: Debug Storage Crash
```bash
# 1. Run with debug output
OMENDB_DEBUG=1 python test_memory_mapped_storage.py

# 2. Check crash location
[Note file:line from stack trace]

# 3. Include specific file at crash point
@[crashed_file:line-20:line+20]

# 4. Fix and verify
[Make fix, rerun test]
```

## Storage Architecture Notes
- Memory-mapped files for zero-copy access
- Hot buffer for recent writes (low latency)
- Async compaction to persistent storage
- No WAL - direct memory-mapped updates