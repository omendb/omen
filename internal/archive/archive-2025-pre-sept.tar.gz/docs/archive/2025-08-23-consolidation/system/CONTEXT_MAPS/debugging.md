# Debugging & Bug Fix Context Map
*For: Crashes, errors, unexpected behavior*
*Updated: 2025-08-23 | Next Review: 2025-08-30*

## Always Include (Base Context)
```bash
@CURRENT_STATE.md                                    # Active issues
@CONTEXT_MAPS/debugging.md                          # This file
```

## Bug-Specific Includes

### Segmentation Fault / Crash
```bash
# Add to base:
@docs/internal/current/KNOWN_ISSUES.md              # Known problems
[Include file at crash location from stack trace]
[Include 50 lines before/after crash point]
```

### Performance Regression
```bash
# Add to base:
@docs/internal/current/PERFORMANCE_FIX_PLAN.md      # Current fixes
@benchmarks/quick_benchmark.py                       # To reproduce
[Include slow function from profiler output]
```

### Wrong Results
```bash
# Add to base:
@omendb/algorithms/diskann.mojo                     # Algorithm implementation
@omendb/core/vector_buffer.mojo                     # Vector storage
[Include test that demonstrates issue]
```

## Debug Commands

```bash
# Enable debug output
export OMENDB_DEBUG=1

# Run with Python debugger
python -m pdb test_file.py

# Memory debugging
valgrind python test_file.py  # If available

# Trace system calls
strace -e trace=file python test_file.py
```

## Update Triggers
- Bug found → Add to KNOWN_ISSUES.md
- Bug fixed → Update CURRENT_STATE.md, remove from KNOWN_ISSUES.md
- Root cause found → Add to DECISIONS.md if architectural

## Common Patterns

### Pattern: Reproduce → Isolate → Fix
```bash
# 1. Reproduce reliably
python minimal_repro.py  # Create minimal test case

# 2. Isolate problem
# Add debug prints at key points
print(f"DEBUG: checkpoint before save, count={len(vectors)}")

# 3. Fix and verify
[Make fix]
python minimal_repro.py  # Should pass
python benchmarks/quick_benchmark.py  # Should not regress
```

### Pattern: Binary Search for Regression
```bash
# When performance regressed between commits
git bisect start
git bisect bad HEAD
git bisect good [last-known-good-commit]
# Test each commit
python benchmarks/quick_benchmark.py
git bisect [good|bad]
# Find exact commit that broke it
```

## Known Issue Template
```markdown
### [Issue Name]
- **Symptoms**: What happens
- **Impact**: How bad (critical/high/medium/low)
- **Reproduce**: Minimal steps
- **Root Cause**: If known
- **Workaround**: If any
- **Fix Plan**: Next steps
```