# Performance Optimization Context Map
*For: Speed improvements, benchmarking, profiling*
*Updated: 2025-08-23 | Next Review: 2025-08-30*

## Always Include (Base Context)
```bash
@CURRENT_STATE.md                                    # Current metrics and issues
@CONTEXT_MAPS/performance.md                         # This file
```

## Task-Specific Includes

### Fixing Performance Regression
```bash
# Add to base:
@docs/internal/current/PERFORMANCE_FIX_PLAN.md      # Detailed fix plan
@omendb/core/memory_mapped_storage.mojo             # Storage implementation
@omendb/native.mojo:221-271                         # Checkpoint function
```

### Benchmarking/Testing
```bash
# Add to base:
@benchmarks/quick_benchmark.py                       # Main benchmark
@test_memory_mapped_storage.py                       # Storage tests
@docs/internal/current/COMPETITIVE_ANALYSIS.md      # Competitor metrics
```

### Optimization Planning
```bash
# Add to base:
@docs/implementation/IMPLEMENTATION_GUIDE.md         # How to reach 50K+ vec/s
@docs/internal/current/COMPETITIVE_ANALYSIS.md      # What competitors do
@DECISIONS.md                                        # Past optimization decisions
```

## Key Metrics to Track
- Throughput (vec/s) - Current: 665, Target: 50K+
- Latency (ms) - Current: 0.62, Target: <0.5
- Memory (MB/1M vec) - Current: 40, Target: 12

## Update Triggers
- After running benchmarks → Update CURRENT_STATE.md metrics
- After implementing optimization → Update PERFORMANCE_FIX_PLAN.md progress
- After discovering bottleneck → Add to Active Issues in CURRENT_STATE.md

## Common Patterns

### Pattern: Measure → Fix → Verify
```bash
# 1. Measure baseline
python benchmarks/quick_benchmark.py > before.txt

# 2. Make changes
[edit files]

# 3. Verify improvement
python benchmarks/quick_benchmark.py > after.txt
diff before.txt after.txt

# 4. Update metrics
[edit CURRENT_STATE.md with new numbers]
```

### Pattern: Profile → Identify → Optimize
```bash
# 1. Profile to find bottleneck
python -m cProfile benchmarks/quick_benchmark.py

# 2. Identify slow function
[look for high cumtime]

# 3. Optimize that specific function
@[specific_file:line_range]
```

## Success Criteria
- ✅ Checkpoint reaches 50K+ vec/s
- ✅ Search latency under 0.5ms
- ✅ Memory usage under 20MB/1M vectors
- ✅ All optimizations have tests