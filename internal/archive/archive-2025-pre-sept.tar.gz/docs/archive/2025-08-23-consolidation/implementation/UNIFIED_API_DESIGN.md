# Unified API Design for OmenDB
*Following best practices from Qdrant, Weaviate, and Pinecone*

## Current Problem

We have 4 confusing methods:
```python
db.add(id, vector)       # Single with ID  
db.add_batch(vectors)    # Batch without IDs
db.upsert(id, vector)    # Single upsert
db.upsert_batch(vectors) # Batch upsert
```

Users have to think about:
- Single vs batch
- Add vs upsert  
- ID placement
- Different signatures

## What Top Competitors Do

### Qdrant (Best UX)
```python
# ONE method handles everything!
client.upsert(
    collection_name="test",
    points=[
        PointStruct(id=1, vector=[0.1, 0.2], payload={"city": "London"}),
        PointStruct(id=2, vector=[0.3, 0.4], payload={"city": "Paris"})
    ]
)
# Works for 1 point or 1000 points - same method!
```

### Weaviate (Auto-batching)
```python
# Single method, auto-batches internally
with client.batch as batch:
    batch.add_data_object(data, "Article")  # Buffered automatically
# Flushes when batch context exits
```

### Pinecone (Clean & Simple)
```python
# One method for all
index.upsert(vectors=[
    ("id1", [0.1, 0.2], {"meta": "data"}),
    ("id2", [0.3, 0.4], {"meta": "data"})
])
```

## Proposed Unified API

### Single Method That Does Everything
```python
def add(self, 
        vectors,           # Single vector or batch
        ids=None,          # Optional: auto-generate if not provided
        metadata=None,     # Optional: metadata dict or list
        auto_batch=True):  # Enable auto-batching
    """
    Universal add method - the ONLY method users need.
    
    Examples:
        # Single vector
        db.add([0.1, 0.2, 0.3])
        db.add([0.1, 0.2, 0.3], id="vec1")
        
        # Batch of vectors
        db.add([[0.1, 0.2], [0.3, 0.4]])
        db.add(numpy_array)
        
        # With metadata
        db.add(vector, metadata={"category": "sports"})
        
        # Everything
        db.add(vectors, ids=["id1", "id2"], metadata=[{...}, {...}])
    """
```

### Implementation with Auto-batching
```python
class DB:
    def __init__(self):
        self._batch_buffer = []
        self._batch_size = 1000
        self._auto_flush = True
    
    def add(self, vectors, ids=None, metadata=None):
        """Single unified method."""
        
        # Normalize input to batch format
        vectors, ids, metadata = self._normalize_input(vectors, ids, metadata)
        
        # Add to buffer
        self._batch_buffer.extend(zip(vectors, ids, metadata))
        
        # Auto-flush when buffer is full
        if len(self._batch_buffer) >= self._batch_size:
            return self._flush()
        
        return ids
    
    def _normalize_input(self, vectors, ids, metadata):
        """Convert any input to batch format."""
        
        # Detect if single vector
        if self._is_single_vector(vectors):
            vectors = [vectors]
            if ids is not None and not isinstance(ids, list):
                ids = [ids]
            if metadata is not None and not isinstance(metadata, list):
                metadata = [metadata]
        
        # Auto-generate IDs if needed
        if ids is None:
            ids = [str(uuid.uuid4()) for _ in range(len(vectors))]
        
        # Default metadata
        if metadata is None:
            metadata = [{}] * len(vectors)
        
        return vectors, ids, metadata
    
    def _is_single_vector(self, vectors):
        """Detect if input is a single vector."""
        # Check if it's a 1D array/list
        if isinstance(vectors, (list, np.ndarray)):
            if len(vectors) > 0:
                # If first element is not a list/array, it's 1D
                return not isinstance(vectors[0], (list, np.ndarray))
        return False
    
    def _flush(self):
        """Flush buffer using FastBuffer for speed."""
        if not self._batch_buffer:
            return []
        
        # Use FastBuffer for zero-copy
        vectors = [v for v, _, _ in self._batch_buffer]
        
        # This is where we'd use the fast path
        self._fast_buffer.add_batch_fast(np.array(vectors))
        
        # Clear buffer
        ids = [id for _, id, _ in self._batch_buffer]
        self._batch_buffer.clear()
        
        return ids
```

## Migration Path

### Phase 1: Add Unified Method (Backward Compatible)
```python
def add(self, *args, **kwargs):
    """New unified method."""
    # ... implementation ...

# Keep old methods but mark deprecated
@deprecated("Use add() instead")
def add_batch(self, vectors):
    return self.add(vectors)
```

### Phase 2: Update Documentation
```python
# Old way (deprecated)
db.add_batch(vectors)  # ❌ Don't use

# New way
db.add(vectors)  # ✅ Use this for everything
```

### Phase 3: Remove Old Methods (v1.0)
```python
# Only one method remains
class DB:
    def add(self, vectors, **kwargs):
        # The only method users need
```

## Benefits

### For Users
1. **One method to learn** - not 4
2. **Auto-batching** - optimal performance automatically
3. **Flexible** - works with any input format
4. **Intuitive** - matches mental model

### For Performance  
1. **Always batched** - even single adds are buffered
2. **FastBuffer integration** - zero-copy under the hood
3. **Optimal batch sizes** - auto-tuned

### For Maintenance
1. **Single code path** - easier to optimize
2. **Less documentation** - one method to document
3. **Fewer bugs** - simpler implementation

## Example Usage

### Before (Confusing)
```python
# User has to think about which method
db.add("id1", vector)           # Single
db.add_batch(vectors)            # Batch
db.upsert("id1", vector)         # Update?
db.upsert_batch(vectors, ids)    # Different signature!
```

### After (Simple)
```python
# One method for everything
db.add(vector)                   # Single
db.add(vectors)                  # Batch
db.add(vector, id="custom")      # With ID
db.add(vectors, ids=ids)         # Batch with IDs

# Auto-batching for free
for vector in huge_dataset:
    db.add(vector)  # Automatically batched!
```

## Competitor Comparison

| Database | Methods | Auto-batch | Zero-copy | Our Score |
|----------|---------|------------|-----------|-----------|
| Qdrant | 1 (upsert) | ✅ | ✅ | 10/10 |
| Weaviate | 1 (add) | ✅ | ✅ | 10/10 |
| Pinecone | 1 (upsert) | ✅ | ❓ | 9/10 |
| ChromaDB | 2 (add/upsert) | ❌ | ❌ | 6/10 |
| **OmenDB (current)** | 4 | ❌ | ❌ | 4/10 |
| **OmenDB (proposed)** | 1 | ✅ | ✅ | 10/10 |

## Implementation Priority

1. **First**: Integrate FastBuffer (performance foundation)
2. **Second**: Implement unified `add()` method
3. **Third**: Add auto-batching logic
4. **Fourth**: Deprecate old methods
5. **Finally**: Remove old methods in v1.0