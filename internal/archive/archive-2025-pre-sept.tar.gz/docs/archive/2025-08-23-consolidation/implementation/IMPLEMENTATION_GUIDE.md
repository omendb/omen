# Optimal Implementation Guide for OmenDB
*Target: 50,000+ vec/s matching LanceDB performance*

## Current vs Optimal Performance

| Metric | Current | Optimal | Improvement |
|--------|---------|---------|-------------|
| Batch Insert | 3,250 vec/s | 50,000 vec/s | 15x |
| Memory Usage | 16.7KB/vector | 4.2KB/vector | 4x |
| Startup Time | 0.001ms | 0.001ms | Same |
| Search Time | 0.6ms | 0.3ms | 2x |
| Index Build | Immediate | Deferred | ∞ |

## The Optimal Architecture Stack

```
┌─────────────────────────────────────┐
│         Python API Layer            │
│    (Zero-copy Arrow/NumPy)          │
├─────────────────────────────────────┤
│         Mojo Core Engine            │
│  ┌─────────────────────────────┐    │
│  │   WAL (Write-Ahead Log)     │    │
│  ├─────────────────────────────┤    │
│  │   Active Segment (Flat)     │    │
│  ├─────────────────────────────┤    │
│  │  Sealed Segments (Indexed)  │    │
│  ├─────────────────────────────┤    │
│  │   Background Index Builder  │    │
│  └─────────────────────────────┘    │
├─────────────────────────────────────┤
│      Memory-Mapped Storage          │
│         (OS Page Cache)             │
└─────────────────────────────────────┘
```

## Implementation Phases

### Phase 1: Fix Critical Issues (1 week → 15K vec/s)

#### 1.1 Remove Debug Prints
```mojo
# Before (current)
print("✅ Numpy array detected")  # KILLS PERFORMANCE

# After
alias DEBUG = False
@parameter
if DEBUG:
    print("Debug: Numpy array detected")
```

#### 1.2 True Zero-Copy from NumPy
```mojo
# Current (FAKE zero-copy)
var flat = numpy_array.flatten()    # COPY!
for i in range(size):                # SLOW!
    ptr[i] = Float32(flat[i])

# Optimal (TRUE zero-copy)
fn add_numpy_direct(addr: Int, count: Int, dim: Int):
    # Cast integer address to pointer
    var ptr = UnsafePointer[Float32].from_address(addr)
    # Use directly - NO COPYING
    self.storage.append_view(ptr, count * dim)
```

#### 1.3 Stop Immediate Index Building
```mojo
# Current (builds index on EVERY insert)
fn add_vector(self, vector):
    self.index.add(vector)        # EXPENSIVE!
    self.index.prune_edges()      # MORE EXPENSIVE!

# Optimal (defer indexing)
fn add_vector(self, vector):
    self.flat_buffer.append(vector)  # Just append (fast)
    if self.flat_buffer.size > 10000:
        self.trigger_async_build()   # Build later
```

### Phase 2: Modern Segment Architecture (2 weeks → 30K vec/s)

#### 2.1 Segment-Based Storage
```mojo
struct Segment:
    var id: String
    var vectors: FlatVectorStorage  # Just arrays
    var index: Optional[DiskANN]    # Built async
    var sealed: Bool                # Immutable when true
    
    fn append(mut self, vectors: ArrayView):
        if self.sealed:
            raise Error("Cannot write to sealed segment")
        self.vectors.extend(vectors)
    
    fn seal_and_index(mut self):
        self.sealed = True
        # Spawn background task
        async_build_index(self.vectors)
```

#### 2.2 Write-Ahead Log
```mojo
struct WAL:
    var file: MMapFile
    var position: Int
    
    fn append(mut self, vectors: ArrayView):
        # Direct memory write
        memcpy(self.file.ptr + self.position, vectors.ptr, vectors.size)
        self.position += vectors.size
        # OS handles fsync asynchronously
```

#### 2.3 Background Index Builder
```mojo
fn background_indexer():
    while True:
        var segment = pending_segments.pop()
        if segment:
            # Build index without blocking inserts
            var index = DiskANN.build_from_flat(segment.vectors)
            segment.index = index
            indexed_segments.append(segment)
        sleep(100ms)
```

### Phase 3: Arrow Columnar Storage (3 weeks → 50K+ vec/s)

#### 3.1 Arrow Integration
```python
# Python side
import pyarrow as pa
import pyarrow.compute as pc

# Create Arrow table
vectors = pa.array(numpy_vectors.flatten())
table = pa.Table.from_arrays(
    [vectors], 
    schema=pa.schema([("embeddings", pa.list_(pa.float32(), 128))])
)

# Pass zero-copy to Mojo
buffer_address = table.column(0).chunks[0].buffers()[1].address
db.add_arrow_batch(buffer_address, len(table))
```

#### 3.2 Columnar Operations
```mojo
struct ColumnarStorage:
    var dimensions: List[Float32Array]  # Each dim is a column
    
    fn distance_compute(self, query: List[Float32]) -> List[Float32]:
        var distances = List[Float32](self.count)
        
        # SIMD operations on entire columns
        @parameter
        for d in range(self.dim):
            var dim_column = self.dimensions[d]
            # Process 16 values at once with AVX-512
            vectorize[simd_width, _compute_partial](self.count)
        
        return distances
```

#### 3.3 Memory-Mapped Files
```mojo
struct MMapStorage:
    var file: FileDescriptor
    var ptr: UnsafePointer[Float32]
    var size: Int
    var capacity: Int
    
    fn __init__(mut self, path: String, size: Int):
        self.file = open(path, O_RDWR | O_CREAT)
        ftruncate(self.file, size)
        self.ptr = mmap(null, size, PROT_READ | PROT_WRITE, MAP_SHARED, self.file, 0)
        self.capacity = size
    
    fn append(mut self, vectors: ArrayView):
        # Direct memory write - OS handles persistence
        memcpy(self.ptr + self.size, vectors.ptr, vectors.byte_size)
        self.size += vectors.byte_size
```

## Optimal Query Processing

### Multi-Tier Search Strategy
```mojo
fn search(self, query: Vector, k: Int) -> List[Result]:
    var results = List[Result]()
    
    # 1. Search active segment (flat)
    if self.active_segment.size > 0:
        results.extend(brute_force_search(self.active_segment, query, k))
    
    # 2. Search indexed segments (fast)
    for segment in self.indexed_segments:
        results.extend(segment.index.search(query, k))
    
    # 3. Merge and return top-k
    return merge_top_k(results, k)
```

## Performance Optimizations

### 1. SIMD Everywhere
```mojo
fn dot_product_simd[width: Int](a: UnsafePointer[Float32], b: UnsafePointer[Float32], size: Int) -> Float32:
    var sum = SIMD[DType.float32, width](0)
    
    @parameter
    fn compute_partial[simd_width: Int](idx: Int):
        sum += a.load[width=simd_width](idx) * b.load[width=simd_width](idx)
    
    vectorize[width, compute_partial](size)
    return sum.reduce_add()
```

### 2. Cache-Friendly Layouts
```mojo
# Align vectors to cache lines (64 bytes)
alias CACHE_LINE = 64
alias VECTORS_PER_CACHELINE = CACHE_LINE // sizeof[Float32]()

struct CacheAlignedStorage:
    var data: UnsafePointer[Float32]
    
    fn __init__(mut self, count: Int, dim: Int):
        # Round up to cache line
        var aligned_dim = ((dim + VECTORS_PER_CACHELINE - 1) // VECTORS_PER_CACHELINE) * VECTORS_PER_CACHELINE
        self.data = UnsafePointer[Float32].alloc(count * aligned_dim, alignment=CACHE_LINE)
```

### 3. Prefetching
```mojo
fn search_with_prefetch(self, query: Vector) -> List[Result]:
    @parameter
    fn process_vector(i: Int):
        # Prefetch next vector while processing current
        if i + 1 < self.count:
            __builtin_prefetch(self.vectors[i + 1], 0, 3)
        
        var distance = compute_distance(self.vectors[i], query)
        results.append((i, distance))
    
    return results
```

## Testing & Benchmarking

### Standard Benchmark
```python
def benchmark_against_competitors():
    """
    Use the same benchmark all competitors use.
    """
    import numpy as np
    import time
    
    # Standard parameters
    NUM_VECTORS = 1_000_000
    DIMENSION = 128
    BATCH_SIZE = 1000
    
    # Generate data
    vectors = np.random.rand(NUM_VECTORS, DIMENSION).astype(np.float32)
    
    # Measure insertion
    start = time.perf_counter()
    for i in range(0, NUM_VECTORS, BATCH_SIZE):
        batch = vectors[i:i+BATCH_SIZE]
        db.add_batch(batch)
    elapsed = time.perf_counter() - start
    
    rate = NUM_VECTORS / elapsed
    print(f"Insertion rate: {rate:,.0f} vec/s")
    
    # Should achieve:
    # - Phase 1: 15,000 vec/s
    # - Phase 2: 30,000 vec/s  
    # - Phase 3: 50,000+ vec/s
```

## Success Metrics

| Milestone | Target Performance | Key Features |
|-----------|--------------------|--------------|
| Phase 1 | 15,000 vec/s | True zero-copy, no debug prints, deferred indexing |
| Phase 2 | 30,000 vec/s | Segments, WAL, background indexing |
| Phase 3 | 50,000 vec/s | Arrow columnar, memory-mapped, SIMD |

## Common Pitfalls to Avoid

1. **Don't build index on insert** - Always defer
2. **Don't copy data** - Use views and pointers
3. **Don't print in hot paths** - Use conditional compilation
4. **Don't use small batches** - Batch everything
5. **Don't ignore cache alignment** - Align to 64 bytes
6. **Don't serialize operations** - Use async everywhere

## References

- [Qdrant Architecture](https://qdrant.tech/documentation/concepts/storage/)
- [LanceDB Design](https://lancedb.github.io/lance/design.html)
- [Weaviate Storage](https://weaviate.io/developers/weaviate/concepts/storage)
- [DuckDB's ART Index](https://duckdb.org/2020/12/03/art.html)
- [Arrow Columnar Format](https://arrow.apache.org/docs/format/Columnar.html)