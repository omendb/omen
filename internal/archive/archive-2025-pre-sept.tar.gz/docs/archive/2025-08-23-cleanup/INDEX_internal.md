# Documentation Index
*Last Updated: August 23, 2025*

## Directory Structure

### `/current/` - Active Development (Dec 2024 - Recent)
- `MASTER_STATUS.md` - Overall project status (380 lines)
- `DEV_ROADMAP_AUG_2025.md` - Development roadmap (183 lines)
- `FFI_OPTIMIZATION_PLAN.md` - FFI optimization details (130 lines)
- `STRATEGY.md` - Strategic decisions (115 lines)
- `CURRENT_SPRINT.md` - Current tasks (93 lines)
- `KNOWN_ISSUES.md` - Active bugs (132 lines)

### `/storage/` - Storage Architecture
- `STORAGE_ENGINE_ARCHITECTURE_DECISION.md` - Why snapshot vs WAL
- `STORAGE_ENGINE_PRACTICAL.md` - Implementation details
- `COLUMNAR_STORAGE_DESIGN.md` - Future columnar approach
- `TECHNICAL_ARCHITECTURE.md` - Overall architecture

### `/api/` - API Design
- `API_DESIGN.md` - Current API structure
- `API_REDESIGN_PROPOSAL.md` - Proposed improvements

### `/analysis/` - Technical Analysis
- `RUST_FEASIBILITY_ANALYSIS.md` - Rust vs Mojo analysis
- `RUST_STORAGE_SOLUTION.md` - Hybrid storage options
- `LANGUAGE_COMPARISON.md` - Language benchmarks

### `/audits/` - Code Audits
- `CODEBASE_AUDIT_AUG_21.md` - Recent code audit
- `MEMORY_CORRUPTION_AUDIT.md` - Memory safety analysis
- `PRE_RELEASE_AUDIT.md` - Release readiness

### `/dev-process/` - Development Process
- `RELEASE_CHECKLIST_v0.1.0.md` - Release procedures
- `MAINTENANCE_PLAN.md` - Maintenance strategy
- `PRODUCTION_DEPLOYMENT_STRATEGY.md` - Deployment guide

### `/business/` - Business Documents
- `INVESTOR_OVERVIEW.md` - Investor pitch
- `YC_APPLICATION_DRAFT.md` - YC application
- `business.md` - Business strategy

### `/dev/` - Development Standards
- `MOJO_STYLE_GUIDE.md` - Mojo coding standards
- `IDIOMATIC_PYTHON_BEST_PRACTICES.md` - Python standards
- `TESTING_STRATEGY.md` - Testing approach
- `PERFORMANCE_REGRESSION_SYSTEM.md` - Performance tracking

### `/strategy/` - Strategic Documents
- `DISKANN_COMPLETE_STRATEGY.md` - DiskANN implementation
- `STORAGE_ENGINE_FUTURE.md` - Future storage plans

### `/archive/` - Historical Reference
Old documentation kept for reference but no longer authoritative.

## Quick Reference

**Most Important Files:**
1. `/Users/nick/github/omendb/omendb-cloud/CLAUDE.md` - Entry point
2. `/Users/nick/github/omendb/omendb-cloud/STATUS.md` - Current state
3. `/Users/nick/github/omendb/omendb-cloud/docs/TECH_SPEC.md` - Architecture
4. `/Users/nick/github/omendb/omendb-cloud/docs/PERFORMANCE_ROADMAP.md` - 4-phase optimization plan
5. `/Users/nick/github/omendb/omendb-cloud/docs/COMPETITIVE_ANALYSIS.md` - Competitor analysis

**When to Use Each:**
- Starting work? → Read `CLAUDE.md` first
- Need current state? → Check `STATUS.md`
- Architecture questions? → `TECH_SPEC.md`
- Performance work? → `PERFORMANCE_ROADMAP.md`
- Understanding competitors? → `COMPETITIVE_ANALYSIS.md`