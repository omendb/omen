# OmenDB Internal Documentation Index

**Last Updated**: August 21, 2025
**Version**: v0.0.1-dev

## Documentation Hierarchy

### 📍 Primary Documents (Start Here)
- [`STATUS.md`](../../STATUS.md) - Current sprint status and tasks
- [`CLAUDE.md`](../../CLAUDE.md) - AI assistant context and guidelines
- [`SPEC.md`](../../SPEC.md) - Technical specification

### 🏗️ Architecture & Design
- [`ALGORITHM_STRATEGY.md`](ALGORITHM_STRATEGY.md) - Why DiskANN only
- [`API_DESIGN.md`](API_DESIGN.md) - set/get/from_numpy API design
- [`ARCHITECTURE_REVIEW.md`](ARCHITECTURE_REVIEW.md) - System architecture
- [`ENTERPRISE_SCALE_ANALYSIS.md`](ENTERPRISE_SCALE_ANALYSIS.md) - Scaling strategy

### ⚡ Performance & Optimization  
- [`performance/OPTIMIZATION_FINAL_AUG_21.md`](performance/OPTIMIZATION_FINAL_AUG_21.md) - Latest optimizations
- [`performance/BATCH_OPTIMIZATION.md`](performance/BATCH_OPTIMIZATION.md) - Batching analysis
- [`performance/OPTIMIZATION_ANALYSIS.md`](performance/OPTIMIZATION_ANALYSIS.md) - Performance deep dive
- [`performance/Phase1_Analysis.md`](performance/Phase1_Analysis.md) - Phase 1 results

### 🐛 Issues & Lessons
- [`MEMORY_POOL_LESSONS.md`](MEMORY_POOL_LESSONS.md) - Memory pool issues
- [`FFI_INVESTIGATION_DEC_19.md`](FFI_INVESTIGATION_DEC_19.md) - FFI bottlenecks
- [`IMPLEMENTATION_SUMMARY_AUG_21.md`](IMPLEMENTATION_SUMMARY_AUG_21.md) - Current blockers

### 📊 Competitive Analysis
- [`COMPETITIVE_ANALYSIS.md`](COMPETITIVE_ANALYSIS.md) - vs Qdrant, Weaviate
- [`COMPETITIVE_LANDSCAPE_DETAILED.md`](COMPETITIVE_LANDSCAPE_DETAILED.md) - Market analysis

### 🔮 Future Planning
- [`PRODUCT_VISION.md`](PRODUCT_VISION.md) - Long-term vision
- [`MARKETING_ANALYSIS.md`](MARKETING_ANALYSIS.md) - Go-to-market strategy
- [`TOKEN_EFFICIENT_SUMMARY.md`](TOKEN_EFFICIENT_SUMMARY.md) - Optimization roadmap

## Quick Reference

### Current Performance
- **Throughput**: 23K vec/s (batch)
- **Search**: 0.46ms @ 128d
- **SIMD**: 19.5M vec/s scan rate
- **Target**: 30K+ vec/s

### Key Limitations
1. **FFI overhead**: No zero-copy (Mojo lacks pointer casting)
2. **Memory pool**: Disabled (no thread safety)
3. **Collections**: Disabled (memory corruption)
4. **mmap**: Not working (FFI crashes)

### Architecture Decisions
- **Algorithm**: DiskANN only (no switching)
- **Storage**: Row-major (not columnar)
- **API**: Moving to set/get pattern
- **Language**: Staying with Mojo (for now)

## Document Status

### ✅ Up-to-date (August 21, 2025)
- STATUS.md
- IMPLEMENTATION_SUMMARY_AUG_21.md
- API_DESIGN.md
- This INDEX.md

### ⚠️ Needs Update
- Public README (very outdated)
- Website docs (references old API)
- Benchmarks (use old metrics)

### 📝 To Create
- Migration guide (old API → new API)
- Deployment guide (Docker, K8s)
- Performance tuning guide

## Navigation Tips

1. **New to codebase?** Start with STATUS.md → SPEC.md → ARCHITECTURE_REVIEW.md
2. **Working on performance?** See performance/ folder
3. **Debugging issues?** Check MEMORY_POOL_LESSONS.md and FFI_INVESTIGATION.md
4. **Planning features?** Read API_DESIGN.md and PRODUCT_VISION.md

## File Organization Rules

- **omendb-cloud/**: Internal docs only (private repo)
- **omendb/**: Public docs only (user-facing)
- **Date in filename**: For time-sensitive docs (e.g., AUG_21)
- **Folder grouping**: Related docs (e.g., performance/)
- **CAPS filenames**: For primary documents
- **Markdown only**: All docs in .md format