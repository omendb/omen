# Documentation Index

**Last Updated**: August 21, 2025

## 📚 Primary Context Files (Always Include)
- `/CLAUDE.md` - AI agent instructions
- `/STATUS.md` - Current sprint & performance metrics  
- `/SPEC.md` - Technical specification

## 🗂️ Documentation Structure

### `/docs/internal/` - Core Technical Docs

#### **Architecture & Design**
- `ALGORITHM_STRATEGY.md` - DiskANN-only strategy decision
- `ARCHITECTURE.md` - System architecture overview
- `BUFFER_STRATEGY.md` - Buffer + DiskANN approach
- `TECHNICAL_ARCHITECTURE.md` - Detailed technical design
- `STORAGE_ENGINE_ARCHITECTURE_DECISION.md` - Storage decisions
- `STORAGE_ENGINE_PRACTICAL.md` - Storage implementation

#### **Current State**
- `IMPLEMENTATION_STATUS.md` - What's built, what's pending
- `MASTER_STATUS.md` - Master tracking document
- `KNOWN_ISSUES.md` - Current bugs and limitations
- `CURRENT_SPRINT.md` - Active development tasks

#### **Memory & Performance** 
- `MEMORY_POOL_LESSONS.md` - Thread safety issues & lessons
- `MEMORY_CORRUPTION_AUDIT.md` - Memory safety analysis
- `OPTIMIZATION_STATUS.md` - Optimization tracking
- `OPTIMIZATION_INITIATIVE_FINAL_REPORT.md` - Phase 1-3 results

#### **Release & Deployment**
- `PRE_RELEASE_AUDIT.md` - Pre-release checklist
- `RELEASE_CHECKLIST_v0.1.0.md` - v0.1.0 release plan
- `PRODUCTION_DEPLOYMENT_STRATEGY.md` - Deployment guide
- `MAINTENANCE_PLAN.md` - Ongoing maintenance

### `/docs/internal/dev/` - Development Guides
- `MOJO_STYLE_GUIDE.md` - Mojo coding standards
- `IDIOMATIC_PYTHON_BEST_PRACTICES.md` - Python API patterns
- `TESTING_STRATEGY.md` - Testing approach
- `PYPI_SETUP.md` - Package distribution
- `NEXT_STEPS.md` - Development roadmap

### `/docs/internal/performance/` - Performance Analysis
- `OPTIMIZATION_FINAL_AUG_21.md` - Latest optimization results
- `FFI_PERFORMANCE_ISSUE_AUG_2025.md` - FFI bottleneck analysis
- `COMPETITIVE_ANALYSIS.md` - vs Qdrant, Weaviate, FAISS
- `BENCHMARK_RESULTS_JAN_2025.md` - Benchmark data
- `PERFORMANCE_BOTTLENECKS.md` - Current bottlenecks

### `/docs/internal/strategy/` - Strategic Decisions
- `DISKANN_COMPLETE_STRATEGY.md` - Why DiskANN only
- `STORAGE_ENGINE_FUTURE.md` - Storage roadmap

### `/docs/internal/business/` - Business Docs
- `INVESTOR_OVERVIEW.md` - Investor pitch
- `YC_APPLICATION_DRAFT.md` - YC application
- `business.md` - Business strategy

### `/docs/internal/archive/` - Historical Docs
Outdated documentation moved here for reference

## 📝 Documentation Guidelines

1. **Update STATUS.md** - After each major change
2. **Archive old docs** - Move to `/archive/` when outdated
3. **Date all updates** - Include "Last Updated: Month DD, YYYY"
4. **Cross-reference** - Link related documents
5. **Keep concise** - Token-efficient for AI agents