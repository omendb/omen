# FFI Integration Plan: FastBuffer to Production
*Date: August 23, 2025*

## Current State
- **Performance**: 1,465 vec/s (element-by-element conversion)
- **Bottleneck**: FFI conversion in `native.mojo:2009-2038`
- **Solution Found**: FastBuffer with ctypes (41M vec/s potential)
- **Status**: Proof of concept works, NOT integrated

## Integration Architecture

```
Python Side                    Shared Memory                 Mojo Side
-----------                    -------------                 ---------
FastBuffer                     ctypes buffer                 native.mojo
  ↓                                 ↓                            ↓
add_batch()  ──memmove──>     [████████████]  <──pointer──  read_buffer()
(zero-copy)                   (pre-filled)                  (no conversion)
```

## Step-by-Step Integration Plan

### Phase 1: Prepare Mojo Side (native.mojo)
```mojo
# Add new function to accept pre-filled buffer
@export
fn process_buffer(
    buffer_addr: Int,      # Memory address from FastBuffer
    num_vectors: Int,      # Number of vectors in buffer
    dimension: Int         # Vector dimension
) raises -> PythonObject:
    """Process vectors from shared memory buffer.
    
    This bypasses FFI conversion entirely by reading from
    pre-filled memory that Python populated with ctypes.memmove.
    """
    # Cast address to pointer (need to verify Mojo supports this)
    # If not, we need a workaround through Python C API
    var ptr = UnsafePointer[Float32]._from_address(buffer_addr)
    
    # Process vectors directly from shared memory
    var store = get_global_db()[]
    
    # Build batch data without copying
    var batch_ids = List[String]()
    var batch_vectors = List[List[Float32]]()
    
    for i in range(num_vectors):
        var offset = i * dimension
        var vector = List[Float32](capacity=dimension)
        
        # Read from shared memory (fast!)
        for j in range(dimension):
            vector.append(ptr[offset + j])
        
        var id = generate_uuid()
        batch_ids.append(id)
        batch_vectors.append(vector)
    
    # Use existing deferred indexing
    return store._process_batch_internal(batch_ids, batch_vectors)
```

### Phase 2: Modify Python API (api.py)
```python
from .fast_buffer import FastBuffer
import omendb._native as _native

class DB:
    def __init__(self, dimension: int = None):
        self.dimension = dimension
        self._fast_buffer = None
        self._buffer_threshold = 10000
    
    def _ensure_buffer(self, dimension: int):
        """Lazily create buffer when dimension is known."""
        if self._fast_buffer is None:
            self._fast_buffer = FastBuffer(
                capacity=self._buffer_threshold,
                dimension=dimension
            )
    
    def add(self, vectors, ids=None, metadata=None):
        """Unified add method with FastBuffer optimization."""
        
        # Normalize to batch format
        vectors, ids, metadata = self._normalize_input(vectors, ids, metadata)
        
        # Ensure dimension is set
        if self.dimension is None:
            self.dimension = len(vectors[0])
        
        # Initialize buffer if needed
        self._ensure_buffer(self.dimension)
        
        # Fast path: Use FastBuffer
        if isinstance(vectors, np.ndarray):
            # Zero-copy transfer to buffer
            self._fast_buffer.add_batch_fast(vectors)
            
            # Check if buffer needs flushing
            if self._fast_buffer.current_vectors >= self._buffer_threshold:
                self._flush_buffer()
            
            return ids
        
        # Fallback for lists (convert to numpy first)
        return self._add_fallback(vectors, ids, metadata)
    
    def _flush_buffer(self):
        """Send buffer to Mojo for processing."""
        if self._fast_buffer.current_vectors == 0:
            return
        
        # Get buffer memory address
        buffer_addr = self._fast_buffer.get_address()
        num_vectors = self._fast_buffer.current_vectors
        
        # Call new Mojo function with buffer address
        result = _native.process_buffer(
            buffer_addr,
            num_vectors, 
            self.dimension
        )
        
        # Clear buffer for next batch
        self._fast_buffer.clear()
        
        return result
```

### Phase 3: Handle Edge Cases

#### Problem: Mojo Can't Create Pointer from Address
If Mojo can't do `UnsafePointer._from_address()`, we need a workaround:

```python
# In Python, create a capsule object
import ctypes

def create_buffer_capsule(buffer):
    """Wrap buffer pointer in PyCapsule for Mojo."""
    ptr = ctypes.cast(buffer, ctypes.c_void_p)
    # Use Python C API to create capsule
    import _ctypes
    capsule = _ctypes.PyCapsule_New(ptr.value, None, None)
    return capsule
```

```mojo
# In Mojo, unwrap capsule
fn process_buffer_capsule(capsule: PythonObject) raises:
    # Use Python C API to extract pointer
    var ptr = extract_pointer_from_capsule(capsule)
    # Process as before
```

### Phase 4: Testing Plan

#### 1. Unit Test FastBuffer
```python
def test_fast_buffer():
    buffer = FastBuffer(capacity=1000, dimension=128)
    vectors = np.random.rand(100, 128).astype(np.float32)
    
    # Test add
    buffer.add_batch_fast(vectors)
    assert buffer.current_vectors == 100
    
    # Test retrieval
    retrieved = buffer.get_batch(0, 100)
    assert np.allclose(vectors, retrieved)
```

#### 2. Integration Test
```python
def test_integration():
    db = omendb.DB()
    vectors = np.random.rand(1000, 128).astype(np.float32)
    
    start = time.perf_counter()
    ids = db.add(vectors)
    elapsed = time.perf_counter() - start
    
    rate = 1000 / elapsed
    assert rate > 5000  # Must hit Phase 1 target
    
    # Verify data integrity
    for i, id in enumerate(ids[:10]):
        retrieved = db.get(id)
        assert np.allclose(retrieved, vectors[i])
```

#### 3. Performance Benchmark
```python
def benchmark_performance():
    """Compare before and after."""
    
    # Before (current implementation)
    db_old = omendb.DB()
    # ... benchmark current path: ~1,465 vec/s
    
    # After (with FastBuffer)
    db_new = omendb.DB()
    # ... benchmark new path: target 20,000+ vec/s
```

## Risk Mitigation

### Risk 1: Mojo Pointer Limitations
**Solution**: Use PyCapsule or pass through Python C API

### Risk 2: Memory Safety
**Solution**: Buffer has fixed size, bounds checking

### Risk 3: Concurrent Access
**Solution**: Single-threaded for now, add locks later

### Risk 4: Performance Regression
**Solution**: Keep fallback path, A/B test

## Success Criteria

1. **Performance**: Achieve 20,000+ vec/s (13.6x improvement)
2. **Compatibility**: Existing API still works
3. **Reliability**: No crashes or data corruption
4. **Testing**: All tests pass, including stress tests

## Implementation Order

1. **Test Mojo pointer creation** - Verify we can use addresses
2. **Implement process_buffer** in native.mojo
3. **Integrate FastBuffer** in api.py
4. **Add fallback paths** for edge cases
5. **Test thoroughly** with benchmarks
6. **Update documentation** with real numbers

## Files to Modify

```
/Users/nick/github/omendb/omendb/
├── omendb/
│   └── native.mojo              # Add process_buffer()
├── python/omendb/
│   ├── api.py                   # Integrate FastBuffer
│   └── fast_buffer.py           # Already created
└── benchmarks/
    └── test_integration.py      # New integration tests
```

## Next Immediate Step

Test if Mojo can create pointers from addresses:
```mojo
# Test this first!
fn test_pointer_from_address() raises:
    var addr: Int = 0x600000ab8040  # Example address
    var ptr = UnsafePointer[Float32]._from_address(addr)
    # If this works, we can proceed
    # If not, we need the PyCapsule workaround
```