# FFI Bottleneck Deep Dive
*Date: August 23, 2025*

## The Core Problem

We successfully integrated FastBuffer and got it working, but performance is still 1,500 vec/s. Here's why:

### What's Working
- ✅ Python side: FastBuffer fills memory with zero-copy (41M vec/s)
- ✅ Buffer reaches Mojo: We see "FastBuffer processing: X vectors"
- ✅ Hijacked function works: update_vector_batch successfully processes buffer

### What's Not Working
- ❌ Mojo still does element-by-element conversion (lines 2226-2230)
- ❌ Each `buffer[idx]` returns a PythonObject that must be converted
- ❌ `Float64(python.float(py_val))` then `Float32(float_val)` for each element

## The Fundamental Limitation

**Mojo cannot create a pointer from a memory address**

```mojo
# This doesn't exist in Mojo:
var ptr = UnsafePointer[Float32]._from_address(0x600000ab8040)

# So we're stuck with:
for j in range(dimension):
    var idx = offset + j  
    var py_val = buffer[idx]  # Returns PythonObject
    var float_val = Float64(python.float(py_val))  # Python → Float64
    vector.append(Float32(float_val))  # Float64 → Float32
```

## Why memcpy Doesn't Help

Even though Mojo has memcpy:
```mojo
from memory import memcpy
```

We can't use it because:
1. Source must be an UnsafePointer (can't create from address)
2. buffer[idx] returns PythonObject, not raw memory
3. No way to get raw memory pointer from Python buffer

## Performance Breakdown

For 10,000 vectors × 128 dimensions = 1,280,000 conversions:

| Step | Time | Operation |
|------|------|-----------|
| Python → Buffer | 0.24ms | memmove (41M vec/s) ✅ |
| Buffer → Mojo | 6,500ms | element-by-element ❌ |
| Total | 6,500ms | 1,538 vec/s |

**The bottleneck is 99.99% in Mojo's FFI conversion**

## Attempted Solutions That Failed

1. **PyCapsule**: Mojo doesn't support unwrapping PyCapsules
2. **Direct pointer**: Can't create pointer from address
3. **Shared memory**: Still need to read element-by-element
4. **New export function**: Wouldn't export (compiler limitation)
5. **Hijacked function**: Works but still has same conversion issue

## The Only Real Solutions

### Option 1: Wait for Mojo
- Native numpy support (planned but not available)
- Better FFI with zero-copy arrays
- Pointer from address capability

### Option 2: C Extension Bridge
```c
// C function that Mojo could call
void* get_numpy_data_ptr(PyArrayObject* arr) {
    return PyArray_DATA(arr);
}
```

### Option 3: Accept Current Performance
- 1,500 vec/s is the limit with current Mojo
- Document as known limitation
- Focus on other optimizations

## Conclusion

We've hit a fundamental Mojo limitation. The FastBuffer solution is correct and would give 20,000+ vec/s if Mojo could:
1. Accept numpy arrays natively, OR
2. Create pointers from addresses, OR  
3. Access Python buffer protocol directly

Until Mojo adds one of these capabilities, we're stuck at 1,500 vec/s for the FFI boundary.