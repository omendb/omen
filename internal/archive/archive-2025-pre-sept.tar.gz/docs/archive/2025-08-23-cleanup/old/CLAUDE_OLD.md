# OmenDB - Public Repository

**Working Directory**: `/Users/nick/github/omendb/omendb/`  
**Purpose**: Open-source embedded vector database in Mojo  
**Version**: v0.2.0 (December 2024)

## Quick Start

```python
import omendb
import numpy as np

# Initialize database
db = omendb.DB()

# Add vectors
vector = np.random.randn(128).astype(np.float32)
db.add("id_1", vector)

# Search
results = db.search(vector, limit=10)
for result in results:
    print(f"{result.id}: {result.score}")
```

## Building from Source

```bash
# Install dependencies
pixi install

# Build native module
pixi run mojo build omendb/native.mojo -o python/omendb/native.so --emit shared-lib

# Run tests
PYTHONPATH=python pixi run pytest tests/

# Quick performance test
PYTHONPATH=python python -c "
import omendb, numpy as np, time
db = omendb.DB()
vecs = np.random.randn(1000, 128).astype(np.float32)
t = time.perf_counter()
for i in range(1000):
    db.add(f'id_{i}', vecs[i])
print(f'{1000/(time.perf_counter()-t):.0f} vec/s')
"
```

## Project Structure

```
omendb/
├── omendb/              # Mojo source code
│   ├── native.mojo      # Main module
│   ├── algorithms/      # DiskANN implementation
│   └── core/            # Core components
├── python/              # Python bindings
├── tests/               # Test suites
├── examples/            # Usage examples
└── docs/                # Public documentation
```

## Features

- **Algorithm**: DiskANN (Microsoft Vamana) - No rebuilds, O(log n)
- **Performance**: Optimizing (target 50K+ vec/s)
- **Startup**: <1ms (fastest in industry)
- **Platform**: macOS/Linux (Windows via WSL2)

## Known Limitations

- Single database per process (by design, like SQLite)
- No native Windows support (Mojo limitation)
- Collections API disabled (language limitation)
- Always clear between tests (`db.clear()`)

## Mojo Development

```mojo
# Common patterns
- Use String() not str()
- Use Int() not int()
- Build with: pixi run mojo -I omendb
- No relative imports
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## Documentation

- [README.md](README.md) - Project overview
- [STATUS.md](STATUS.md) - Current status
- [BUILD.md](BUILD.md) - Build instructions
- [CHANGELOG.md](CHANGELOG.md) - Version history

## Support

- Issues: GitHub Issues
- License: Apache 2.0