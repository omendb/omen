# Documentation Reorganization Plan

## Goal
Optimize documentation for AI agent usage - token efficient, well-organized hierarchy.

## Current Issues
1. Internal docs in public repo (security/clarity issue)
2. Duplicate documentation across repos
3. Not optimized for AI agent context windows
4. Missing clear hierarchy

## New Structure

### Private Repo (omendb-cloud/)
```
omendb-cloud/
├── CLAUDE.md              # Primary context (always include)
├── STATUS.md              # Current sprint status
├── SPEC.md                # Technical specification
├── KNOWLEDGE_BASE.md      # Historical decisions & patterns
└── docs/
    ├── internal/          # Private implementation details
    │   ├── performance/   # Optimization results & analysis
    │   ├── architecture/  # Design decisions
    │   └── lessons/       # What we learned (failures & successes)
    └── business/          # Business strategy (keep private)
```

### Public Repo (omendb/)
```
omendb/
├── README.md              # Public introduction
├── CONTRIBUTING.md        # How to contribute
├── CHANGELOG.md          # User-facing changes
└── docs/
    ├── quickstart.md     # Getting started guide
    ├── api/              # API reference
    │   └── python.md     # Python API docs
    └── guides/           # User guides
        └── performance.md # Performance tuning
```

## Files to Move (Public → Private)

### High Priority (Internal/Sensitive)
- `docs/SESSION_SUMMARY.md` → Delete (outdated)
- `docs/REMAINING_CLEANUP.md` → `omendb-cloud/docs/internal/archive/`
- `docs/CLEANUP_COMPLETE.md` → Delete (task complete)
- `docs/KNOWN_ISSUES.md` → Integrate into STATUS.md
- `docs/MAINTENANCE_PLAN.md` → `omendb-cloud/docs/internal/`

### Development Docs (Should be Private)
- `docs/dev/PERFORMANCE_REGRESSION_SYSTEM.md` → `omendb-cloud/docs/internal/dev/`
- `docs/dev/TEST_COVERAGE_ANALYSIS.md` → `omendb-cloud/docs/internal/dev/`
- `docs/dev/optimization_plan.md` → Delete (outdated)
- `docs/dev/MOJO_COMMON_ERRORS.md` → Keep public (helps users)

### Keep Public (User-Facing)
- `docs/quickstart.md` ✅
- `docs/api/python.md` ✅
- `docs/guides/` ✅
- `docs/CONTRIBUTING.md` ✅

## AI Agent Optimization Rules

### 1. Token Efficiency
- Keep files under 500 lines
- Use tables over prose where possible
- Remove redundant information
- Archive outdated content

### 2. Hierarchy
```
Level 1: CLAUDE.md (200 lines) - Quick context
Level 2: STATUS.md, SPEC.md (300 lines each) - Current state
Level 3: Detailed docs (500 lines each) - Specific topics
```

### 3. Include Patterns
```python
# For any task:
@CLAUDE.md              # Always

# For feature work:
@STATUS.md              # Current sprint
@SPEC.md               # Technical spec

# For debugging:
@docs/internal/lessons/  # Past issues

# For performance:
@docs/internal/performance/  # Benchmarks
```

## Implementation Steps

1. **Create STATUS.md** ✅ - Current sprint status
2. **Create SPEC.md** - Technical specification
3. **Update CLAUDE.md** ✅ - Simplified, points to other docs
4. **Move internal docs** - Public → Private
5. **Delete outdated** - Remove old/redundant docs
6. **Update paths** - Fix all references

## Success Metrics

- [ ] No internal docs in public repo
- [ ] CLAUDE.md under 200 lines
- [ ] Clear 3-level hierarchy
- [ ] All docs have clear purpose
- [ ] No duplicate information

## Commands to Execute

```bash
# Move internal docs to private repo
mv /Users/nick/github/omendb/omendb/docs/SESSION_SUMMARY.md /Users/nick/github/omendb/omendb-cloud/docs/internal/archive/
mv /Users/nick/github/omendb/omendb/docs/REMAINING_CLEANUP.md /Users/nick/github/omendb/omendb-cloud/docs/internal/archive/
mv /Users/nick/github/omendb/omendb/docs/MAINTENANCE_PLAN.md /Users/nick/github/omendb/omendb-cloud/docs/internal/

# Delete outdated
rm /Users/nick/github/omendb/omendb/docs/CLEANUP_COMPLETE.md
rm /Users/nick/github/omendb/omendb/docs/dev/optimization_plan.md

# Move dev docs
mv /Users/nick/github/omendb/omendb/docs/dev/PERFORMANCE_REGRESSION_SYSTEM.md /Users/nick/github/omendb/omendb-cloud/docs/internal/dev/
mv /Users/nick/github/omendb/omendb/docs/dev/TEST_COVERAGE_ANALYSIS.md /Users/nick/github/omendb/omendb-cloud/docs/internal/dev/
```