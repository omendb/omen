# Storage Architecture Deep Dive: Finding the Optimal Approach

## The Storage Trilemma for Vector Databases

Vector databases face unique challenges that traditional databases don't:
1. **High dimensionality**: 128-4096 dimensions per vector
2. **Similarity search**: Need approximate nearest neighbors, not exact matches
3. **Mixed workloads**: Both streaming inserts and complex queries

## Storage Approach Comparison

### 1. Pure LSM Trees
```
Strengths:
✅ Excellent write throughput (append-only)
✅ Natural support for updates/deletes
✅ Proven scalability (RocksDB, Cassandra)
✅ Good compression ratios

Weaknesses:
❌ Multiple disk reads for queries (log(N) levels)
❌ No native similarity search support
❌ Space amplification from compaction
❌ Poor cache locality for vector operations

Best for: Write-heavy workloads with exact lookups
```

### 2. Pure Graph-Based (HNSW)
```
Strengths:
✅ Excellent query performance (log(N) complexity)
✅ High recall rates (>95%)
✅ Intuitive algorithm
✅ Good for fixed datasets

Weaknesses:
❌ Entire graph must fit in memory
❌ Expensive updates (graph reconstruction)
❌ No efficient deletes
❌ Memory overhead (16-64 bytes per edge)

Best for: Read-heavy workloads with stable data
```

### 3. Pure Learned Indexes
```
Strengths:
✅ Potentially O(1) lookups
✅ Extremely space efficient
✅ Can capture data distribution patterns
✅ Hardware acceleration friendly (GPU/TPU)

Weaknesses:
❌ High training cost
❌ Sensitive to distribution shifts
❌ Complex error handling
❌ Theoretical more than practical currently

Best for: Static datasets with predictable patterns
```

### 4. Inverted File (IVF) Indexes
```
Strengths:
✅ Good balance of speed/memory
✅ Natural sharding boundaries
✅ Supports updates reasonably well
✅ Proven at scale (Faiss)

Weaknesses:
❌ Requires training on representative data
❌ Recall drops with compression
❌ Cluster imbalance issues
❌ Query latency variance

Best for: Large-scale approximate search
```

## Why Hybrid is Optimal for OmenDB

### The Insight: Different Data Has Different Needs

```mojo
struct DataTemperature:
    """Not all vectors are accessed equally"""
    
    var hot_data: Float32 = 0.01    # 1% accessed 90% of time
    var warm_data: Float32 = 0.09   # 9% accessed 9% of time  
    var cold_data: Float32 = 0.90   # 90% accessed 1% of time
```

### Our Hybrid Architecture

```mojo
struct HybridVectorStorage:
    # Layer 1: Write-Optimized Ingestion
    var write_buffer: LSMMemTable        # Recent inserts (LSM-style)
    var update_log: AppendOnlyLog        # Updates/deletes tracking
    
    # Layer 2: Query-Optimized Indexes  
    var hot_index: CompactHNSW           # Top 1% vectors (memory)
    var warm_index: QuantizedIVF         # Next 9% (SSD)
    var cold_index: LearnedIndex         # Bottom 90% (disk/S3)
    
    # Layer 3: Adaptive Routing
    var router: MLRouter                 # Predicts which layer to query
    var stats: AccessStatistics          # Tracks temperature changes
    
    fn query(self, vector: Vector, k: Int) -> List[Result]:
        # 1. Check write buffer first (most recent)
        fresh_results = self.write_buffer.search(vector, k)
        
        # 2. Router predicts which indexes to search
        predicted_layers = self.router.predict(vector)
        
        # 3. Search predicted layers in parallel
        results = parallel_search(predicted_layers, vector, k)
        
        # 4. Merge and return top-k
        return merge_results(fresh_results, results, k)
    
    fn adaptive_migration(self):
        """Background process moving vectors between tiers"""
        # Hot → Warm: When access frequency drops
        # Warm → Cold: After time threshold
        # Cold → Warm: When access spikes
        # Automatic retraining of learned indexes
```

## Specific Design Decisions

### Q: Why LSM for writes but not reads?
**A**: LSM excels at sequential writes but requires multiple random reads. We use it only for the write buffer, then migrate to read-optimized structures.

### Q: Why not pure learned indexes?
**A**: Three reasons:
1. **Training cost**: Retraining on every update is expensive
2. **Distribution shift**: Real-world data changes over time
3. **Fallback complexity**: Need traditional index for mispredictions

### Q: Why keep HNSW for hot data?
**A**: HNSW provides:
- Predictable low latency (critical for hot data)
- No training required
- Natural incremental updates
- Proven 95%+ recall

### Q: Why IVF for warm data?
**A**: IVF offers:
- Good compression/performance trade-off
- Natural sharding for distribution
- Reasonable update performance
- Battle-tested at scale

### Q: Why learned indexes for cold data?
**A**: Cold data is perfect for learned indexes:
- Rarely updated (no retraining cost)
- Access patterns are predictable
- Space efficiency matters most
- Can afford occasional mispredictions

## Implementation Strategy

### Phase 1: Minimal Hybrid (0-6 months)
```mojo
struct Phase1Storage:
    var memory_buffer: VectorList     # Recent inserts
    var main_index: HNSW              # Primary storage
    var overflow_file: FlatFile       # When memory full
```

### Phase 2: Temperature-Aware (6-12 months)
```mojo
struct Phase2Storage:
    var hot_tier: MemoryHNSW         # 1% of vectors
    var warm_tier: SSDIVF            # 9% of vectors
    var cold_tier: DiskFlat          # 90% of vectors
    var migrator: TierMigrator       # Background process
```

### Phase 3: Fully Adaptive (12+ months)
```mojo
struct Phase3Storage:
    var write_lsm: LSMTree           # All writes
    var read_indexes: Dict[Tier, Index]  # Per-tier optimal
    var learned_router: NeuralRouter # Intelligent routing
    var auto_optimizer: IndexOptimizer # Continuous improvement
```

## Performance Projections

### Single-Node Scalability
```
Phase 1: 10M vectors, 1K QPS, <10ms P99
Phase 2: 100M vectors, 5K QPS, <20ms P99  
Phase 3: 1B vectors, 10K QPS, <50ms P99
```

### Distributed Scalability
```
10 nodes: 10B vectors, 100K QPS, <100ms P99
100 nodes: 100B vectors, 1M QPS, <200ms P99
1000 nodes: 1T vectors, 10M QPS, <500ms P99
```

## Conclusion: Hybrid Wins Through Adaptability

Pure approaches optimize for one workload pattern. Real-world vector databases need to handle:
- Streaming inserts AND complex queries
- Hot data AND cold archives  
- Exact filters AND approximate search
- Small embeddings AND large documents

Our hybrid architecture adapts to these varying needs, using the best tool for each part of the problem. This isn't complexity for its own sake - it's the minimum complexity needed to achieve optimal performance across diverse workloads.