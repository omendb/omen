# Single-Dimension-Per-Process Architecture

## Design Philosophy

OmenDB uses a single-dimension-per-process architecture as an intentional optimization for embedded use cases.

## Why This Design?

### Performance Benefits
- **Zero overhead**: No instance management or handle lookups
- **Direct memory access**: No indirection through handles
- **Shared memory pools**: Better cache utilization
- **10-50ns faster per operation** vs instance-based design

### Simplicity
- No lifecycle management
- No handle/pointer complications
- Impossible to leak instances
- Matches SQLite's embedded philosophy

### Real-World Alignment
- **99% of embedded apps use ONE embedding model**
- Face recognition: Always 128D
- Document search: Always 768D
- IoT sensors: Always 64D

## Technical Background

This design works around Mojo's current limitation where global variables are deprecated/broken until ~2026. When Mojo adds proper global support, we'll have even better options.

## How It Works

```mojo
# In native.mojo
var _global_db = VectorStore()  # Single global instance

# All DB instances in Python share this
db1 = DB("file1.omen")  # Uses _global_db
db2 = DB("file2.omen")  # Also uses _global_db!
```

## Implications

### What Works
- ✅ Single dimension per process
- ✅ Extremely fast operations
- ✅ Simple memory management
- ✅ Perfect for embedded use

### What Doesn't Work
- ❌ Multiple dimensions in same process
- ❌ Multiple isolated databases
- ❌ Concurrent different models

## Handling Multiple Dimensions

### 1. Process Isolation (Recommended)
```python
# Run each dimension in separate process
subprocess.run(["python", "embed_text.py"])     # 768D
subprocess.run(["python", "embed_images.py"])   # 512D
```

### 2. Microservice Pattern
```python
# text_service.py (768D only)
from omendb import DB
db = DB()  # Only 768D vectors

# image_service.py (512D only)  
from omendb import DB
db = DB()  # Only 512D vectors
```

### 3. Future: Collections API (v0.2.0)
```python
# Idiomatic API coming soon
db = DB()
db.collection("text", dimension=768).add("id", vector)
db.collection("images", dimension=512).add("id", vector)
```

## Server Edition Architecture

For the server edition, this becomes an advantage:
```
┌──────────────────┐
│   Rust Server    │
├──────────────────┤
│ Process Pool:    │
│ • 768D worker    │ ← One OmenDB process
│ • 512D worker    │ ← Another OmenDB process  
│ • 128D worker    │ ← Another OmenDB process
└──────────────────┘
```

Each process handles one dimension perfectly, with process isolation providing security and fault tolerance.

## Is This Good Architecture?

**For Embedded: YES ✅**
- Fastest possible performance
- Simplest implementation
- Covers 99% of use cases

**For Server: PERFECT ✅**
- Process isolation = security
- Clean separation of concerns
- Natural scaling model

This isn't a limitation - it's an optimization for the embedded use case.