# OmenDB Optimization Plan - Critical Issues

## 🚨 Critical Issues with Current Implementation

### 1. RoarGraph Rebuilds Entire Graph on Every Flush
**Problem**: `insert_batch()` calls `build_bipartite()` which reconstructs the entire graph from scratch
**Impact**: O(n²) complexity for incremental additions
**Solution**: Implement incremental graph updates

### 2. No Separation of Insertion and Indexing
**Problem**: Every flush triggers immediate graph rebuild
**Impact**: Write operations block on expensive indexing
**Solution**: Lazy indexing with background graph construction

### 3. Missing Incremental Updates for RoarGraph
**Problem**: RoarGraph only supports batch rebuilding
**Impact**: Cannot handle streaming/incremental data efficiently
**Solution**: Add incremental insertion or keep HNSW for incremental workloads

## 📋 Optimization Tasks

### Phase 1: Fix RoarGraph Incremental Performance
```mojo
# Current (BAD):
fn _flush_to_roargraph(mut self, ids, vectors):
    roar.batch_add(ids, vectors)  # Rebuilds entire graph!

# Proposed (GOOD):
fn _flush_to_roargraph(mut self, ids, vectors):
    if self.roar_needs_rebuild:
        roar.rebuild_graph()  # Periodic rebuild
    else:
        roar.append_vectors(ids, vectors)  # Just store, don't rebuild
```

### Phase 2: Implement Lazy Indexing
```python
# Separate insertion from indexing
db.add_batch(vectors)  # Fast: just appends to storage
db.build_index()        # Slow: builds/updates graph (can be async)
db.search(query)        # Uses latest built index + brute force recent
```

### Phase 3: Smart Algorithm Selection
```python
# Based on workload patterns
if incremental_pattern:
    use_hnsw()  # Has true incremental updates
elif batch_pattern:
    use_roargraph()  # Better for batch rebuilds
elif small_dataset:
    use_flat()  # No index needed
```

## 🏗️ Proposed Architecture

### Lazy Indexing Architecture
```
Writes → Storage (immediate)
           ↓
      Background Indexer (periodic/triggered)
           ↓
      Index (RoarGraph/HNSW)
           ↓
      Query → Merge(Index + Recent Unindexed)
```

### Storage Layer Separation
```mojo
struct VectorStore:
    var storage: VectorStorage      # Holds all vectors
    var index: Optional[Index]      # May be stale
    var unindexed: BruteForceIndex  # Recent additions
    var index_version: Int          # Track staleness
    
    fn add_vector(self, id, vector):
        self.storage.append(id, vector)
        self.unindexed.add(id, vector)
        # No index rebuild here!
    
    fn build_index(self):
        # Can be called async/periodically
        if self.algorithm == ROARGRAPH:
            self.index = RoarGraph.build_from(self.storage)
        else:
            self.index.add_batch(self.unindexed)
        self.unindexed.clear()
    
    fn search(self, query, k):
        # Search both index and unindexed
        results_indexed = self.index.search(query, k) if self.index
        results_unindexed = self.unindexed.search(query, k)
        return merge_results(results_indexed, results_unindexed, k)
```

## 🎯 Performance Targets After Optimization

| Operation | Current | Target | Method |
|-----------|---------|--------|--------|
| Single add | Rebuilds graph | O(1) append | Lazy indexing |
| Batch add | Rebuilds graph | O(n) append | Lazy indexing |
| Index build | On every flush | Periodic/async | Background thread |
| Query | Fast (if indexed) | Fast + merge | Dual search |

## ⚠️ Do NOT Make RoarGraph Default Until:

1. ✅ Lazy indexing implemented
2. ✅ Incremental updates work efficiently
3. ✅ Background indexing available
4. ✅ Performance validated for mixed workloads

## 📊 Algorithm Comparison (Reality)

| Algorithm | Batch Build | Incremental | Query | Memory | Status |
|-----------|------------|-------------|-------|--------|---------|
| RoarGraph | O(n) ✅ | O(n²) ❌ | O(log n) | High | Batch only |
| HNSW | O(n log n) | O(log n) ✅ | O(log n) | Medium | Balanced |
| Flat | N/A | O(1) ✅ | O(n) | Low | Small data |

## 🎯 Recommendation

**Keep THREE algorithms:**
1. **Flat** - Buffer and small datasets (<1K)
2. **HNSW** - Incremental/streaming workloads
3. **RoarGraph** - Large batch operations with lazy indexing

**Default Selection Logic:**
```python
if dataset_size < 1000:
    return 'flat'
elif incremental_workload:
    return 'hnsw'
elif batch_workload and lazy_indexing_enabled:
    return 'roargraph'
else:
    return 'hnsw'  # Safe default
```

## 🚧 Implementation Priority

1. **Implement lazy indexing** - Biggest impact
2. **Add background indexer** - Enables async updates
3. **Fix RoarGraph incremental** - Or document as batch-only
4. **Smart auto-selection** - Based on workload detection
5. **Benchmark all scenarios** - Validate improvements