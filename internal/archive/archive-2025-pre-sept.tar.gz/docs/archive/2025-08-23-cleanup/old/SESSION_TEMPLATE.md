# New Session Checklist

## 1. Test Current State
```bash
cd /Users/nick/github/omendb/omendb && python -c "
import omendb, numpy as np, time
db = omendb.DB()
db.clear()
vecs = np.random.randn(1000, 128).astype(np.float32)
t = time.perf_counter()
for i in range(1000):
    db.add(f'id_{i}', vecs[i])
rate = 1000/(time.perf_counter()-t)
print(f'Current: {rate:.0f} vec/s')
if rate > 40000:
    print('✅ FIXED!')
elif rate > 10000:
    print('🔧 Better but not there yet')
else:
    print('❌ Still broken')
"
```

## 2. Context Files to Include
```
@/Users/nick/github/omendb/omendb-cloud/KNOWLEDGE_BASE.md
@/Users/nick/github/omendb/omendb/omendb/native.mojo
@/Users/nick/github/omendb/omendb/omendb/algorithms/diskann.mojo
```

## 3. Current Tasks
- [ ] Replace BruteForceIndex with SimpleBuffer
- [ ] Add DiskANN.build() method
- [ ] Test performance (target: 50K+ vec/s)
- [ ] Implement segment swapping
- [ ] Remove in-place flush

## 4. Key Constraints
- Single DB per process (always db.clear() first)
- No Windows (Mojo limitation)
- Python FFI overhead (~0.3ms per call)

## 5. If Stuck
1. Check KNOWLEDGE_BASE.md for patterns
2. Test with pure Mojo (no Python) to isolate issue
3. Compare with ChromaDB approach
4. Simplify until it works

## 6. Before Committing
- Test performance meets target
- Update KNOWLEDGE_BASE.md with findings
- No Claude attribution in commits
- Keep internal docs in omendb-cloud/