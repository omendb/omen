# OmenDB Performance Fix Plan

## Critical Issues Identified

### 1. Double Search Penalty (Buffer + Main Index)
**Problem**: Always searching both buffer AND main index, then merging results
- Buffer search: 2,513 QPS
- DiskANN activated: 672 QPS (3.7x slower due to double search)
- **Solution**: Eliminate double search architecture

### 2. DiskANN Implementation Issues  
**Problems**:
- Using Dict for visited tracking (slow hash operations)
- Frequent sorting of candidates
- No SIMD in graph distance calculations
- Beam width too large (50 for k=10)
- **Solution**: Rewrite with arrays, reduce beam width, add SIMD

### 3. Even Flat is Slower than ChromaDB
- Our flat: 2,614 QPS
- ChromaDB: 3,446 QPS (1.3x faster)
- **Solution**: Better SIMD, remove overhead

## Immediate Fixes (Quick Wins)

### Fix 1: Automatic Algorithm Selection
```python
# In native.mojo __init__
if self.buffer_size < 50000:
    # For small datasets, use pure flat (no graph overhead)
    self.algorithm = AlgorithmType.FLAT
    self.main_index = None  # No DiskANN at all
else:
    # Only use DiskANN for large datasets where graph helps
    self.algorithm = AlgorithmType.DISKANN
```

### Fix 2: Eliminate Double Search for Flat
```python
# In search function
if self.algorithm == AlgorithmType.FLAT:
    # Only search buffer, no main index
    return self.write_buffer.search(query, k)
# Don't merge with empty main index results
```

### Fix 3: Optimize DiskANN Beam Search
```mojo
# In diskann.mojo _beam_search
# 1. Use array instead of Dict for visited
var visited = List[Bool](self.size)  # Pre-allocated array
for i in range(self.size):
    visited[i] = False

# 2. Reduce beam width adaptively
var beam_width = min(k * 2, 20)  # Max 20, not 50

# 3. Add SIMD distance calculations
@vectorize
fn compute_distances(i: Int):
    distances[i] = simd_cosine_distance(query, nodes[i].vector)
```

## Medium-Term Fixes (1-2 weeks)

### Fix 4: Single Index Architecture
Instead of buffer + main index, use ONE index:
- **Small datasets (<50K)**: Pure brute force with SIMD
- **Large datasets (>50K)**: Pure DiskANN (no buffer)
- Eliminates double search completely

### Fix 5: Better SIMD for Flat
```mojo
# Use AVX-512 when available
@parameter
if has_avx512():
    # Process 16 floats at once
    alias simd_width = 16
else:
    alias simd_width = 8

# Unroll loops for better pipelining
for i in range(0, size, simd_width * 4):
    # Process 4 SIMD vectors in parallel
```

### Fix 6: Cache-Optimized Layout
- Store vectors contiguously for better cache locality
- Align to cache lines (64 bytes)
- Prefetch next vectors during search

## Long-Term Fixes (1+ month)

### Fix 7: Alternative Algorithm
Replace DiskANN with simpler, faster algorithm for small-medium datasets:
- **IVF (Inverted File Index)**: Simple clustering, fast for <1M vectors
- **Annoy**: Tree-based, good balance
- **HNSW Fixed**: Fix our HNSW implementation properly

### Fix 8: GPU Acceleration
- Use Mojo's GPU support when stable
- Offload distance calculations to GPU
- Keep graph traversal on CPU

## Expected Performance After Fixes

| Fix | Current | Target | Improvement |
|-----|---------|--------|-------------|
| Eliminate double search | 672 QPS | 2,500 QPS | 3.7x |
| Optimize DiskANN | 672 QPS | 1,500 QPS | 2.2x |
| Better SIMD for flat | 2,614 QPS | 3,500 QPS | 1.3x |
| Auto algorithm selection | Manual config | Automatic | Better UX |

## Priority Implementation Order

1. **TODAY**: Auto algorithm selection (Fix 1)
2. **TODAY**: Eliminate double search for flat (Fix 2)
3. **This Week**: Optimize DiskANN beam search (Fix 3)
4. **Next Week**: Single index architecture (Fix 4)

## Code Changes Required

### native.mojo
```mojo
fn __init__(mut self, ...):
    # Auto-select algorithm based on expected size
    if buffer_size < 50000:
        self.algorithm = AlgorithmType.FLAT
        self.use_main_index = False
    else:
        self.algorithm = AlgorithmType.DISKANN
        self.use_main_index = True

fn search(mut self, query, k):
    if not self.use_main_index:
        # Fast path: only search buffer
        return self.write_buffer.search(query, k)
    # Rest of current logic
```

### diskann.mojo
```mojo
fn _beam_search(self, query, k):
    # Pre-allocate visited array (not Dict)
    var visited = List[Bool](self.size)
    
    # Adaptive beam width
    var beam_width = min(k * 2, 20)
    
    # SIMD distance batch computation
    var distances = self._batch_distances_simd(query, candidates)
```

## Success Metrics
- Match or exceed ChromaDB's 3,446 QPS for 5K vectors
- Achieve 5,000+ QPS for pure flat search
- Reduce DiskANN overhead to <2x vs flat
- Zero configuration required from users