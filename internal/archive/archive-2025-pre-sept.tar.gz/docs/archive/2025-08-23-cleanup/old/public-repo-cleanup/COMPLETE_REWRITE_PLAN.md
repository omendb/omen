# Complete OmenDB Rewrite Plan

## The Brutal Truth

**Our Current Architecture is Fundamentally Wrong:**
- Buffer + Main Index = Always searching 2 indexes = 3.7x slowdown
- DiskANN implementation uses Dict instead of arrays = 10x slower than it should be
- Even our "flat" is slower than ChromaDB because of overhead

**What Actually Works in Production:**
- ChromaDB: Single HNSW index with smart buffering INSIDE the index
- Faiss: Optimized brute force beats everything up to 100K vectors
- Qdrant: Single index with segments, no double search
- Weaviate: Single HNSW, period

## The Real Performance Targets

```
Dataset Size | ChromaDB | Our Current | What We Need
-------------|----------|-------------|-------------
5K vectors   | 3,446 QPS| 649 QPS     | 4,000+ QPS
10K vectors  | 3,000 QPS| 331 QPS     | 3,500+ QPS
100K vectors | 2,000 QPS| ???         | 2,500+ QPS
```

## Algorithm Reality Check

**Surprising Truth from Faiss Team:**
- Brute force with SIMD beats ALL algorithms up to ~50K vectors
- IVF beats graphs from 50K-500K vectors
- Graphs (HNSW/DiskANN) only win at 500K+ vectors

**Why?**
- Modern CPUs: 32 SIMD operations per cycle
- Brute force: Perfect memory access pattern, no random access
- Graphs: Random memory access kills cache

## The Complete Rewrite

### Step 1: Delete Everything Wrong
```mojo
# DELETE THIS:
struct DatabaseStore:
    var write_buffer: BruteForceIndex  # DELETE
    var main_index: Optional[Index]    # DELETE
    
# REPLACE WITH:
struct DatabaseStore:
    var index: VectorIndex  # ONE index, period
```

### Step 2: Implement One Index Right

**Option A: Optimized Brute Force (Simplest, Fastest for <100K)**
```mojo
struct OptimizedFlatIndex:
    var vectors: UnsafePointer[Float32]  # Contiguous memory
    var count: Int
    
    fn search(self, query: List[Float32], k: Int) -> List[Result]:
        # Full SIMD optimization
        @parameter
        fn compute_distances[simd_width: Int](idx: Int):
            # Process simd_width vectors at once
            var vecs = self.vectors + idx * self.dim
            var dists = simd_cosine_distance(query, vecs, simd_width)
            
        # Parallel processing
        parallelize[compute_distances](self.count, get_num_cores())
        
        # SIMD top-k selection
        return simd_top_k(distances, k)
```

**Option B: IVF (Best for 50K-1M)**
```mojo
struct IVFIndex:
    var centroids: List[Vector]  # Cluster centers
    var inverted_lists: List[List[Int]]  # Vector IDs per cluster
    var vectors: UnsafePointer[Float32]
    
    fn search(self, query: List[Float32], k: Int) -> List[Result]:
        # Find nearest centroids (SIMD)
        var nearest_clusters = find_nearest_centroids(query, n_probe=4)
        
        # Search within clusters (parallel)
        @parameter
        fn search_cluster(cluster_id: Int):
            var cluster_vecs = self.inverted_lists[cluster_id]
            return compute_distances_simd(query, cluster_vecs)
        
        # Merge results
        return merge_top_k(cluster_results, k)
```

**Option C: Fixed DiskANN (Only for >1M)**
```mojo
struct DiskANN:
    var nodes: UnsafePointer[Node]
    var visited: UnsafePointer[Bool]  # NOT Dict!
    
    fn search(self, query: List[Float32], k: Int) -> List[Result]:
        # Pre-allocate everything
        var visited = self.visited  # Reset bit vector
        var candidates = BoundedHeap(k * 2)  # Not 50!
        
        # SIMD batch distance
        @vectorize
        fn compute_neighbor_distances(neighbor_batch):
            return simd_distance_batch(query, neighbor_batch)
        
        # Beam search with early termination
        while candidates.size() > 0 and iterations < k * 5:
            ...
```

## Where to Use Mojo SIMD/Parallelize/Vectorize

### 1. Distance Calculations (BIGGEST WIN)
```mojo
@vectorize[simd_width=16]  # AVX-512
fn cosine_distance_batch(query: List[Float32], vectors: UnsafePointer[Float32]):
    # Process 16 distances at once
```

### 2. Top-K Selection (SIMD MIN/MAX)
```mojo
fn simd_top_k[simd_width: Int](distances: UnsafePointer[Float32], k: Int):
    # Use SIMD to find minimums in parallel
    var min_vals = simd[DType.float32, simd_width].load(distances)
```

### 3. Matrix Operations (BLAS INTEGRATION)
```mojo
fn batch_search(queries: Matrix, database: Matrix):
    # Use BLAS SGEMM for all queries at once
    blas_sgemm(queries.T, database, results)
```

### 4. Graph Building (PARALLELIZE)
```mojo
@parallelize
fn build_graph_parallel(vectors: List[Vector]):
    # Build graph connections in parallel
```

## Critical Decisions

### Q: Keep buffer architecture?
**A: NO!** It's the root cause of our performance problems. Delete it.

### Q: Keep both flat and DiskANN?
**A: NO!** Pick ONE algorithm and make it excellent:
- For v1.0: Optimized flat only (handles 99% of use cases)
- For v2.0: Add IVF for scale
- For v3.0: Maybe add graph algorithm if needed

### Q: Which algorithm is best?
**A: Optimized brute force for <100K, IVF for 100K-1M**
- Most users have <100K vectors
- Brute force with SIMD can achieve 10,000+ QPS
- Simpler = fewer bugs = faster development

## Implementation Plan (2 Weeks)

### Week 1: Core Rewrite
**Day 1-2: Delete buffer architecture**
- Remove write_buffer from DatabaseStore
- Remove main_index Optional wrapper
- Single index only

**Day 3-4: Implement optimized flat**
- Contiguous memory layout
- Full SIMD distance calculations
- Parallel query processing
- SIMD top-k selection

**Day 5: Benchmark against ChromaDB**
- Target: 4,000+ QPS at 5K vectors
- Must beat ChromaDB

### Week 2: Optimization
**Day 6-7: Memory optimization**
- Align vectors to cache lines (64 bytes)
- Prefetch next vectors during search
- Column-major for better SIMD

**Day 8-9: Add IVF for scale**
- Simple k-means clustering
- Inverted index structure
- Multi-probe search

**Day 10: Final benchmarks**
- Test against Faiss, ChromaDB, LanceDB
- Document performance

## What I Need From You

1. **Confirmation to delete buffer architecture entirely**
   - This is the biggest change but necessary

2. **Agreement to focus on optimized flat first**
   - Handles 99% of use cases
   - Can add complex algorithms later

3. **Understanding that DiskANN might not be needed**
   - It only helps at 1M+ vectors
   - IVF is simpler and works well at 100K-1M

## The Path to Best Vector Database

**1. Fastest for typical use (<100K vectors)**
- Optimized brute force with maximum SIMD
- No graph overhead
- 10,000+ QPS achievable

**2. Simple architecture**
- One index, no buffer confusion
- Clear code, easy to maintain
- No double search overhead

**3. Gradual complexity**
- Start with flat (simple, fast)
- Add IVF when needed (100K+)
- Consider graphs only at 1M+

**4. Benchmark everything**
- Test against ChromaDB/Faiss/LanceDB
- Publish honest numbers
- Optimize based on profiling

## Next Steps

1. **Delete buffer architecture** (I'll do this first)
2. **Implement optimized flat with full SIMD**
3. **Benchmark and profile**
4. **Add IVF if we have time**

The key insight: **We don't need complex algorithms**. We need simple algorithms implemented excellently with maximum SIMD optimization. Brute force at 10,000 QPS beats DiskANN at 1,000 QPS every time.