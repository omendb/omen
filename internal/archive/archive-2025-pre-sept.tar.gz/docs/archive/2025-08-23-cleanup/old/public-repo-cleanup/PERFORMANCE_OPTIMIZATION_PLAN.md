# Performance Optimization Plan for Server Mode

## Executive Summary

We **HAD** excellent performance (89K vec/s @1K, 65K vec/s @5K) with a buffer + main index architecture. We broke it by moving to single DiskANN index. Here's how to fix it and optimize for server-mode scale.

## 🔍 What Happened - Performance Regression Analysis

### Previous Architecture (FAST - 89K vec/s)
```
Write → Buffer (BruteForce, 10K capacity) → Main Index (HNSW/DiskANN)
         ↓                                      ↓
      Search ← ← ← ← ← ← ← ← ← ← ← ← ← ← Search (merged results)
```
- **Buffer**: Fast brute force for recent vectors
- **Main Index**: Scalable graph algorithm for bulk
- **Performance**: 89,136 vec/s @1K, 65,697 vec/s @5K

### Current Architecture (SLOW - 1.1K vec/s) 
```
Write → Single DiskANN Index
           ↓
        Search (broken graph traversal)
```
- **Single Index**: DiskANN only, but graph search broken
- **Issues**: No actual graph traversal, returns fixed order
- **Performance**: 1,133 vec/s (77x SLOWER!)

### Root Cause
1. We thought buffer + main was causing "double search overhead"
2. Removed buffer architecture entirely
3. Single DiskANN doesn't work - beam search broken
4. Lost ALL performance benefits

## ✅ Optimization Strategy - 3 Approaches

### Option 1: Restore Buffer + Index Architecture (RECOMMENDED)
**Time**: 1-2 days  
**Confidence**: High (was working before)

```python
class OptimizedDatabase:
    def __init__(self):
        self.buffer = FlatIndex(capacity=10000)  # Fast brute force
        self.main = DiskANNIndex()  # Or HNSW for proven performance
        self.buffer_size = 0
        
    def add(self, id, vector):
        self.buffer.add(id, vector)
        self.buffer_size += 1
        
        if self.buffer_size >= self.buffer.capacity:
            self._flush_buffer()
    
    def search(self, query, k):
        # Search both, merge by score
        buffer_results = self.buffer.search(query, k)
        main_results = self.main.search(query, k) if self.main.size > 0 else []
        return merge_results(buffer_results, main_results, k)
    
    def _flush_buffer(self):
        # Batch insert to main index
        vectors = self.buffer.get_all()
        self.main.add_batch(vectors)
        self.buffer.clear()
        self.buffer_size = 0
```

**Benefits**:
- Proven architecture (ChromaDB, Weaviate use this)
- Fast writes to buffer (O(1))
- Scalable reads from main index (O(log n))
- Can flush asynchronously in server mode

### Option 2: Fix DiskANN Beam Search
**Time**: 2-3 days  
**Confidence**: Medium (complex fixes needed)

Key fixes needed:
```mojo
fn _beam_search_optimized(...):
    # 1. Fix candidate exploration
    # Currently: Only explores entry point neighbors
    # Need: Proper greedy search with backtracking
    
    # 2. Fix distance calculations
    # Currently: Returns 0.0 or NaN for many vectors
    # Need: Proper cosine distance with normalization
    
    # 3. Fix result ranking
    # Currently: Returns fixed order (id_0, id_1, id_2)
    # Need: Actually sort by distance
    
    # 4. Fix graph connectivity
    # Currently: Too sparse, gets stuck
    # Need: Ensure minimum degree, better neighbor selection
```

### Option 3: Switch to Proven HNSW
**Time**: 2-3 days  
**Confidence**: High (well-documented algorithm)

Port from Faiss or HNSWLib:
- Well-tested implementation
- Known performance characteristics  
- Better documentation
- Proven at scale

## 🚀 Recommended Implementation Plan

### Phase 1: Restore Buffer Architecture (Day 1)
```mojo
struct NativeDatabase:
    var write_buffer: FlatIndex  # Fast writes
    var main_index: DiskANNIndex  # Scalable reads
    var buffer_size: Int
    var max_buffer_size: Int
    
    fn add(self, id: String, vector: List[Float32]):
        self.write_buffer.add(id, vector)
        self.buffer_size += 1
        
        if self.buffer_size >= self.max_buffer_size:
            self._flush_to_main()
    
    fn _flush_to_main(self):
        # Move buffer to main in batch
        var batch = self.write_buffer.get_all()
        self.main_index.add_batch(batch)
        self.write_buffer.clear()
        self.buffer_size = 0
```

### Phase 2: Optimize for Server Mode (Day 2)
```mojo
# Server-specific optimizations
struct ServerDatabase(NativeDatabase):
    var async_flush: Bool = True
    var compression: Bool = True
    var sharding: Bool = True
    
    fn add_async(self, id: String, vector: List[Float32]):
        # Add to buffer
        self.write_buffer.add(id, vector)
        
        # Trigger async flush if needed
        if self.should_flush():
            self.schedule_flush()  # Non-blocking
    
    fn search_distributed(self, query: List[Float32], k: Int):
        # Search across shards in parallel
        var shard_results = parallel_search_shards(query, k)
        return merge_shard_results(shard_results)
```

## 📊 Expected Performance After Optimization

### With Buffer + Index Architecture
- **1K vectors**: 85K+ vec/s (buffer only)
- **5K vectors**: 60K+ vec/s (mostly buffer)
- **10K vectors**: 45K+ vec/s (buffer + main)
- **100K vectors**: 30K+ vec/s (mostly main)
- **1M vectors**: 20K+ vec/s (main index)

### Server Mode Optimizations
- **Async flush**: +20% throughput
- **Batch operations**: +50% for bulk inserts
- **Parallel search**: 10K+ QPS with multiple cores
- **Sharding**: Linear scaling with nodes

## 🔧 Specific Optimizations

### 1. SIMD Distance Calculations
```mojo
@vectorize
fn cosine_distance_simd(a: DTypePointer[DType.float32], 
                        b: DTypePointer[DType.float32],
                        dim: Int) -> Float32:
    # Use AVX-512 on x86, NEON on ARM
    # 4-8x faster than scalar
```

### 2. Memory Pool for Allocations
```mojo
struct MemoryPool:
    var chunks: List[UnsafePointer[Float32]]
    var free_list: List[Int]
    
    fn allocate(self, size: Int) -> UnsafePointer[Float32]:
        # Reuse freed memory, avoid malloc overhead
```

### 3. Parallel Graph Construction
```mojo
fn build_graph_parallel(vectors: List[Vector], num_threads: Int):
    # Split vectors into chunks
    # Build sub-graphs in parallel
    # Merge with minimal edge updates
```

### 4. Adaptive Parameters
```python
def get_optimal_params(num_vectors):
    if num_vectors < 1000:
        return {"buffer_size": 1000, "algorithm": "flat"}
    elif num_vectors < 10000:
        return {"buffer_size": 5000, "algorithm": "hnsw", "M": 16}
    elif num_vectors < 100000:
        return {"buffer_size": 10000, "algorithm": "hnsw", "M": 32}
    else:
        return {"buffer_size": 50000, "algorithm": "diskann", "R": 64}
```

## 🎯 Implementation Priority

### Must Have (Day 1-2)
1. ✅ Restore buffer + main architecture
2. ✅ Fix search to actually merge results
3. ✅ Ensure buffer flushes properly
4. ✅ Verify performance recovery

### Should Have (Day 3-4)
5. ⚡ SIMD optimizations
6. ⚡ Async flush for server mode
7. ⚡ Batch operations API
8. ⚡ Memory pooling

### Nice to Have (Week 2)
9. 🔄 Fix DiskANN properly OR
10. 🔄 Switch to HNSW
11. 📊 Sharding support
12. 🔍 GPU acceleration

## 📈 Success Metrics

### Embedded Mode
- [ ] 80K+ vec/s for <5K vectors
- [ ] 40K+ vec/s for 10K vectors
- [ ] <1ms search latency
- [ ] <10MB memory overhead

### Server Mode
- [ ] 30K+ vec/s sustained insert
- [ ] 10K+ QPS search
- [ ] <10ms P99 latency
- [ ] Linear scaling with cores

## 🚨 Critical Path

**Day 1**: Restore buffer architecture, verify it works
**Day 2**: Optimize for performance, add async operations
**Day 3**: Benchmark against competitors
**Day 4**: Server-mode specific features
**Week 2**: Advanced optimizations or algorithm switch

## Summary

We know what broke (removed buffer architecture) and how to fix it (restore it). The buffer + main index pattern is proven by all major vector databases. For server mode at scale, we need:

1. **Buffer for fast writes** (brute force is fine <10K)
2. **Main index for scale** (HNSW or fixed DiskANN)
3. **Async operations** for throughput
4. **Sharding** for horizontal scale

This gets us back to competitive performance quickly while setting up for server-mode scale.