# API Design Document

**Date**: August 21, 2025
**Version**: v0.0.1-dev

## Current API vs Proposed API

### Current API (v0.0.1)
```python
db = DB()
db.add("id1", vector)
db.add_batch(vectors, ids)
results = db.search(query, limit=10)
```

### Proposed API (v0.1.0)
```python
db = DB()

# Core operations - Redis/memcached style
db.set("id1", vector)        # Single vector
db.set({"id1": v1, "id2": v2})  # Batch via dict
db.get("id1")                # Get single vector
db.get(["id1", "id2"])       # Get multiple

# Search remains clear
db.search(vector, k=10)      # k is more standard than limit

# Import/export with clear formats
db.from_numpy(array, ids)    # Not "import" (keyword)
db.from_pandas(df)           # DataFrame support
db.to_numpy()               # Export as numpy
db.to_pandas()              # Export as DataFrame
```

## Why These Names?

### set/get Pattern
- **Industry Standard**: Redis, Memcached, DynamoDB all use set/get
- **Clear Intent**: set = write, get = read
- **Batch Detection**: 
  - `set(dict)` = batch set
  - `get(list)` = batch get
  - Overloading is intuitive

### from_X/to_X Pattern
- **Pandas Convention**: `pd.from_csv()`, `df.to_json()`
- **Clear Direction**: from = import, to = export
- **Avoid Keywords**: "import" is Python keyword
- **Format Explicit**: No ambiguity about data format

### search() with k Parameter
- **ML Standard**: scikit-learn, FAISS use `k` 
- **Concise**: `k=10` cleaner than `limit=10`
- **Distinct**: Different from CRUD operations

## Implementation Plan

### Phase 1: Add New Methods (v0.0.2)
```python
# Add alongside existing API
def set(self, key_or_dict, value=None):
    if isinstance(key_or_dict, dict):
        return self.add_batch(...)
    return self.add(key_or_dict, value)

def get(self, key_or_list):
    if isinstance(key_or_list, list):
        return self.get_batch(...)
    return self.get_vector(key_or_list)
```

### Phase 2: Deprecate Old Methods (v0.1.0)
```python
@deprecated("Use set() instead")
def add(self, ...):
    warnings.warn("add() is deprecated, use set()")
    return self.set(...)
```

### Phase 3: Remove Old Methods (v1.0.0)
- Clean API with only set/get/search/from_X/to_X

## API Comparison with Competitors

| Database | Set Vector | Get Vector | Batch | Search |
|----------|------------|------------|-------|---------|
| **OmenDB (proposed)** | `set(id, vec)` | `get(id)` | `set(dict)` | `search(vec, k=10)` |
| Qdrant | `upsert(point)` | `retrieve(id)` | `upsert(points)` | `search(vec, limit=10)` |
| Weaviate | `add(obj)` | `get(id)` | `batch.add()` | `query(vec).limit(10)` |
| Pinecone | `upsert(vec)` | `fetch(id)` | `upsert(batch)` | `query(vec, top_k=10)` |
| FAISS | `add(vec)` | `reconstruct(i)` | `add(vecs)` | `search(vec, k)` |

## Benefits of Our Design

1. **Consistency**: Same verbs as key-value stores
2. **Simplicity**: No special batch API, just pass dict/list
3. **Pythonic**: Follows Python conventions (duck typing)
4. **Future-proof**: Easy to add new formats (from_json, from_arrow)
5. **Clear**: No ambiguity about operation intent

## Migration Guide

### For Users
```python
# Old way
db.add("id", vector)
db.add_batch(vectors, ids)

# New way  
db.set("id", vector)
db.set(dict(zip(ids, vectors)))

# Or use from_numpy for arrays
db.from_numpy(vectors, ids)
```

### For Internal Code
- Rename internal methods to match new API
- Keep compatibility layer during transition
- Update all tests and benchmarks
- Update documentation

## Open Questions

1. **Should get() return None or raise on missing key?**
   - Proposal: Return None (like dict.get())
   
2. **Should set() return the ID or success boolean?**
   - Proposal: Return ID (useful for auto-generated IDs)

3. **Should we support `db["id"] = vector` syntax?**
   - Proposal: Yes, via __setitem__/__getitem__

4. **Async API?**
   - Proposal: `await db.aset()`, `await db.aget()` in future