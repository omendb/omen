# OmenDB Testing Strategy & Best Practices

**Date**: August 11, 2025  
**Status**: Refactoring in progress

## 🎯 Current State Analysis

### Problems Identified
1. **Test sprawl**: 150+ test files with significant overlap
2. **Poor organization**: Many debug/experimental files mixed with production tests
3. **Unclear purpose**: Files like `test_hnsw_*` for algorithms we've removed
4. **Duplication**: Same tests in multiple places (performance/, debug/, diskann/)

## 📊 Vector Database Testing Requirements

### 1. **Correctness Tests**
- **CRUD operations**: add, search, delete, update, clear
- **Data integrity**: Vectors retrieved match vectors stored
- **Similarity accuracy**: Cosine similarity calculations correct
- **Edge cases**: Empty DB, single vector, duplicate IDs

### 2. **Performance Benchmarks**
- **Insertion throughput**: vectors/second at various scales
- **Query latency**: p50, p95, p99 percentiles
- **Scaling behavior**: 1K, 10K, 100K, 1M vectors
- **Memory efficiency**: RAM per vector stored

### 3. **Integration Tests**
- **NumPy compatibility**: Zero-copy array processing
- **Python API**: All methods work as documented
- **Persistence**: Save/load functionality
- **Error handling**: Graceful failures

### 4. **Regression Tests**
- **Performance baselines**: Alert on slowdowns
- **Bug prevention**: Tests for all fixed bugs
- **API stability**: No breaking changes

## 🏗️ Proposed Test Organization

```
test/
├── unit/                    # Fast, isolated component tests
│   ├── test_vector_ops.py   # Vector math operations
│   ├── test_distance.py     # Distance calculations
│   └── test_storage.py      # Storage engine tests
│
├── integration/             # Full system tests
│   ├── test_api.py          # Python API coverage
│   ├── test_numpy.py        # NumPy integration
│   └── test_persistence.py  # Save/load functionality
│
├── benchmarks/              # Performance measurements
│   ├── insertion.py         # Add vector throughput
│   ├── query.py            # Search latency
│   ├── memory.py           # Memory usage profiling
│   └── competitors/        # Comparison tests
│       ├── chromadb.py
│       ├── faiss.py
│       └── lancedb.py
│
├── regression/             # Prevent regressions
│   ├── bug_fixes.py       # Tests for fixed bugs
│   └── performance.py     # Performance baselines
│
└── fixtures/               # Test data
    ├── vectors/           # Sample vector sets
    └── datasets/          # Standard benchmarks (SIFT, GIST)
```

## 🔧 Testing Best Practices for Vector DBs

### 1. **Use Standard Datasets**
- SIFT1M: 1M 128-dimensional vectors
- GIST1M: 1M 960-dimensional vectors
- GloVe: Real word embeddings
- Random: Synthetic data for edge cases

### 2. **Measure What Matters**
```python
# Key metrics for vector databases
metrics = {
    "throughput": "vectors/second",
    "latency": "milliseconds",
    "recall": "% correct results",
    "memory": "bytes per vector",
    "index_time": "seconds to build",
}
```

### 3. **Competitor Comparison Framework**
```python
class VectorDBBenchmark:
    """Standardized benchmark for fair comparison."""
    
    def benchmark_insertion(self, vectors, batch_size=1000):
        """Measure insertion throughput."""
        
    def benchmark_query(self, queries, k=10):
        """Measure query latency and recall."""
        
    def benchmark_memory(self):
        """Measure memory consumption."""
```

### 4. **Profiling Requirements**
- **CPU profiling**: Identify hot paths
- **Memory profiling**: Find leaks and bloat
- **I/O profiling**: Disk access patterns
- **SIMD utilization**: Vectorization efficiency

## 🧹 Dead Code Removal Plan

### To Remove (Old Algorithms)
- `test/roargraph/` - Algorithm removed
- `test/migration/` - Migration strategy removed
- `test/debug/test_hnsw_*` - HNSW removed
- `test/debug/test_buffer_*` - Old buffer design

### To Consolidate
- Merge all performance tests into `benchmarks/`
- Combine API tests into single comprehensive suite
- Unify NumPy tests

### To Keep
- Core functionality tests
- Bug regression tests
- Current performance benchmarks
- Integration tests

## 📈 Benchmark Suite Design

### Insertion Benchmark
```python
def benchmark_insertion(db, num_vectors, dimension, batch_size):
    """Standard insertion benchmark."""
    vectors = generate_vectors(num_vectors, dimension)
    
    start = time.time()
    for i in range(0, num_vectors, batch_size):
        batch = vectors[i:i+batch_size]
        db.add_batch(batch)
    elapsed = time.time() - start
    
    return {
        "throughput": num_vectors / elapsed,
        "total_time": elapsed,
        "vectors": num_vectors
    }
```

### Query Benchmark
```python
def benchmark_query(db, num_queries, k=10):
    """Standard query benchmark."""
    queries = generate_queries(num_queries)
    latencies = []
    
    for query in queries:
        start = time.time()
        results = db.search(query, limit=k)
        latencies.append(time.time() - start)
    
    return {
        "p50": np.percentile(latencies, 50) * 1000,
        "p95": np.percentile(latencies, 95) * 1000,
        "p99": np.percentile(latencies, 99) * 1000,
    }
```

## 🔄 API Review

### Current Issues
1. **Inconsistent naming**: `add` vs `add_batch`
2. **Missing methods**: No `update()` method
3. **Unclear semantics**: What does `clear()` do exactly?

### Proposed API Improvements
```python
class DB:
    # Core operations
    def add(id: str, vector: np.ndarray) -> bool
    def add_many(vectors: np.ndarray, ids: List[str]) -> List[str]
    def search(vector: np.ndarray, k: int = 10) -> List[Result]
    def delete(id: str) -> bool
    def update(id: str, vector: np.ndarray) -> bool
    
    # Batch operations
    def delete_many(ids: List[str]) -> List[str]
    def update_many(vectors: np.ndarray, ids: List[str]) -> List[str]
    
    # Management
    def count() -> int
    def clear() -> None
    def compact() -> None  # Optimize index
    
    # Persistence
    def save(path: str) -> None
    def load(path: str) -> None
```

## 🚀 Next Steps

1. **Clean up test directory** - Remove dead tests
2. **Create benchmark suite** - Standardized comparisons
3. **Set up profiling** - CPU, memory, I/O
4. **API consistency** - Fix naming and semantics
5. **Documentation** - Clear testing guidelines

## 📊 Competitive Benchmarking

### Key Comparisons
- **ChromaDB**: Most similar API, direct competitor
- **Faiss**: Performance baseline for HNSW
- **LanceDB**: Rust-based, similar architecture
- **Qdrant**: Production features comparison

### Benchmark Matrix
| Metric | OmenDB | ChromaDB | Faiss | LanceDB |
|--------|--------|----------|-------|---------|
| 10K insert/s | 96K | 4.7K | 150K | 12K |
| Query latency | 2.7ms | 5ms | 0.5ms | 3ms |
| Memory/vector | 512B | 1KB | 256B | 768B |
| Startup time | 0.001ms | 41ms | 10ms | 25ms |

## 🔍 Profiling Strategy

### Tools
- **py-spy**: Python profiling without overhead
- **memory_profiler**: Line-by-line memory usage
- **cProfile**: Built-in Python profiler
- **perf**: Linux system profiler

### Key Areas
1. **Hot paths**: Vector operations, distance calculations
2. **Memory allocation**: Buffer management, resizing
3. **I/O patterns**: Disk persistence, checkpointing
4. **SIMD usage**: Vectorization efficiency

### Example Profiling Script
```python
import cProfile
import pstats
from memory_profiler import profile

@profile
def profile_insertion():
    db = omendb.DB()
    vectors = generate_vectors(10000, 128)
    db.add_many(vectors, generate_ids(10000))

# CPU profiling
cProfile.run('profile_insertion()', 'stats.prof')
stats = pstats.Stats('stats.prof')
stats.sort_stats('cumulative')
stats.print_stats(20)
```