# Language Comparison for Storage Layer

**Date**: August 22, 2025
**Purpose**: Choose best language for Mojo FFI gap-filling

## Performance Comparison

| Language | Relative Speed | Zero-Copy | mmap | Thread Safety | FFI to Mojo |
|----------|---------------|-----------|------|---------------|-------------|
| **C** | 1.0x (baseline) | ✅ Easy | ✅ Native | ⚠️ Manual | ✅ Best |
| **C++** | 0.98x | ✅ Easy | ✅ Native | ✅ std::mutex | ✅ Good |
| **Rust** | 0.95-1.0x | ✅ Safe | ✅ memmap2 | ✅ Arc/Mutex | ⚠️ C ABI |
| **Zig** | 0.98-1.0x | ✅ Easy | ✅ Native | ✅ std.Thread | ✅ C ABI |
| **Go** | 0.7-0.8x | ❌ GC | ✅ syscall | ✅ channels | ❌ Hard |
| **Nim** | 0.95x | ✅ Easy | ✅ Native | ✅ locks | ✅ C ABI |

## Code Example: mmap Implementation

### C (Simplest, fastest)
```c
void* mmap_file(const char* path, size_t size) {
    int fd = open(path, O_RDWR | O_CREAT, 0644);
    ftruncate(fd, size);
    void* ptr = mmap(NULL, size, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    return ptr;
}
```

### Rust (Safest)
```rust
use memmap2::{MmapMut, MmapOptions};
use std::fs::OpenOptions;

pub fn mmap_file(path: &str, size: usize) -> MmapMut {
    let file = OpenOptions::new()
        .read(true).write(true).create(true)
        .open(path).unwrap();
    file.set_len(size as u64).unwrap();
    unsafe { MmapOptions::new().map_mut(&file).unwrap() }
}
```

### Zig (Modern C replacement)
```zig
pub fn mmap_file(path: []const u8, size: usize) ![]u8 {
    const fd = try std.os.open(path, .{ .ACCMODE = .RDWR, .CREAT = true }, 0o644);
    defer std.os.close(fd);
    try std.os.ftruncate(fd, size);
    return try std.os.mmap(null, size, std.os.PROT.READ | std.os.PROT.WRITE,
                           std.os.MAP.SHARED, fd, 0);
}
```

### C++ (With RAII)
```cpp
class MmapFile {
    void* data_;
    size_t size_;
public:
    MmapFile(const char* path, size_t size) : size_(size) {
        int fd = open(path, O_RDWR | O_CREAT, 0644);
        ftruncate(fd, size);
        data_ = mmap(nullptr, size, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
        close(fd);
    }
    ~MmapFile() { munmap(data_, size_); }
    void* data() { return data_; }
};
```

## Decision Criteria

### 1. Performance (30%)
- **C**: Perfect, zero overhead
- **Zig**: Near-perfect, comptime optimizations
- **Rust**: 95-100%, LLVM optimized
- **C++**: Template bloat possible

### 2. Safety (25%)
- **Rust**: Best - ownership, no segfaults
- **Zig**: Good - defer, error unions
- **C++**: OK - RAII helps
- **C**: Worst - manual everything

### 3. FFI to Mojo (25%)
- **C**: Best - Mojo designed for C FFI
- **Zig**: Great - exports C ABI naturally
- **C++**: Good - extern "C" works
- **Rust**: OK - needs #[no_mangle] extern "C"

### 4. Developer Experience (20%)
- **Rust**: Great tooling (cargo), slow compile
- **Zig**: Fast compile, simple language
- **C++**: Complex, many footguns
- **C**: Simple but primitive

## Recommendation: **C with Zig backup**

### Primary Choice: C
```c
// storage.h - Simple C interface for Mojo FFI
typedef struct Storage Storage;

Storage* storage_create(const char* path, size_t size);
void storage_destroy(Storage* s);
float* storage_get_vector(Storage* s, size_t idx, size_t dim);
void storage_sync(Storage* s);
```

**Why C?**
- ✅ **Zero friction** with Mojo FFI
- ✅ **Fastest possible** performance
- ✅ **Simplest** to debug FFI issues
- ✅ **Tiny binary** (few KB)
- ⚠️ Manual memory management (but small codebase)

### Backup Choice: Zig
```zig
// If C becomes too complex, Zig offers:
// - Memory safety features (defer, error handling)
// - Modern syntax
// - Still exports C ABI perfectly
// - Comptime for zero-cost abstractions
```

### Why Not Rust?
- **Complexity**: `#[no_mangle]`, `extern "C"`, `Box::into_raw()`
- **Binary size**: 100KB+ even for simple libs
- **Compile time**: Slower iteration
- **Overkill**: We just need mmap + thread pool

### Why Not C++?
- **ABI issues**: Name mangling complications
- **Complexity**: Templates, exceptions, RTTI
- **Binary bloat**: STL pulls in lots
- **No benefit**: We don't need OOP here

## Implementation Plan

### Week 1: C Storage Library
```bash
storage/
├── storage.h       # C header for Mojo
├── storage.c       # mmap, thread pool
├── Makefile       # Simple build
└── test.c         # Basic tests
```

### Core Functions (200 lines total)
1. `storage_create()` - mmap file
2. `storage_resize()` - mremap/realloc
3. `storage_get_ptr()` - return pointer
4. `storage_sync()` - msync
5. `pool_alloc()` - thread-safe allocator

### Mojo Integration
```mojo
# Simple FFI declarations
@external
fn storage_create(path: StringRef, size: Int) -> UnsafePointer[NoneType]

@external  
fn storage_get_vector(storage: UnsafePointer[NoneType], idx: Int) -> UnsafePointer[Float32]

# Use from Mojo
var storage = storage_create("/tmp/vectors.bin", 1_000_000)
var vec_ptr = storage_get_vector(storage, 42)
```

## Conclusion

**Use C for storage layer**:
- Minimal, fast, simple
- Perfect Mojo FFI compatibility
- 1 week implementation
- Easy to replace later when Mojo matures

**Avoid Rust/C++** for now:
- Unnecessary complexity
- FFI friction
- Larger binaries
- Longer development time