# Distribution Strategy for PyPI

**Status**: Technical solution identified  
**Goal**: `pip install omendb` gives users working native acceleration

## 🔍 **Current Situation Analysis**

### **What We Have ✅**
- Compiled Mojo shared libraries: `omendb/__mojocache__/*.so` (343KB-710KB each)
- Modular runtime dependencies: `~1.7MB total` (.pixi/envs/default/lib/)
- Working Python API that loads native modules

### **The Problem**
```bash
# User experience:
pip install omendb
python -c "from omendb import DB; DB().add('test', [1,2,3])"
# Result: ❌ "Production native module not available" (stub mode)
```

### **Root Cause**
Native libraries depend on Modular runtime libraries:
- `libKGENCompilerRTShared.dylib` (514KB)
- `libAsyncRTMojoBindings.dylib` (420KB) 
- `libAsyncRTRuntimeGlobals.dylib` (425KB)
- `libMSupportGlobals.dylib` (143KB)

## 🛠️ **Solution Options**

### **Option 1: Bundle Runtime Libraries (RECOMMENDED)**
**Approach**: Include Modular runtime in Python wheel
```
omendb/
├── __init__.py
├── api.py
├── native/
│   ├── working_native.so          # Our compiled Mojo code
│   └── runtime/                   # Bundled Modular runtime
│       ├── libKGENCompilerRTShared.dylib
│       ├── libAsyncRTMojoBindings.dylib
│       ├── libAsyncRTRuntimeGlobals.dylib
│       └── libMSupportGlobals.dylib
```

**Pros**: 
- Single `pip install omendb` just works
- No user setup required
- Standard Python packaging

**Cons**: 
- Larger wheel size (~3-4MB vs 100KB)
- Need platform-specific wheels (macOS ARM64, Intel, Linux x64, Linux ARM64)
- License compliance with Modular runtime

### **Option 2: Conda-First Distribution**
**Approach**: Distribute via conda-forge, document pixi setup
```bash
# User installation:
conda install -c conda-forge omendb
# or
pixi add omendb
```

**Pros**:
- Leverages existing Modular conda packages
- No license/bundling issues
- Simpler build process

**Cons**:
- Not pip-installable
- Smaller user base (conda vs pip)
- More complex user setup

### **Option 3: Hybrid Approach**
**Approach**: Pure Python fallback + optional native acceleration
```python
try:
    from omendb.native import NativeDB as DB  # Fast native version
except ImportError:
    from omendb.fallback import PythonDB as DB  # Pure Python fallback
```

**Pros**:
- Works for all users via pip
- Graceful degradation
- Optional performance boost

**Cons**:
- Need to maintain two implementations
- Users might not realize they're missing acceleration
- Performance gap could be significant

## 🎯 **Recommended Solution: Bundle Runtime Libraries**

### **Implementation Plan**

#### **Phase 1: Single Platform Proof-of-Concept**
1. **Copy runtime libraries** to `python/omendb/native/runtime/`
2. **Update Python module** to set `DYLD_LIBRARY_PATH` before loading native module
3. **Test local installation** with bundled libraries
4. **Validate performance** matches development environment

#### **Phase 2: Multi-Platform Wheels**
1. **Build wheels for each platform**:
   - macOS ARM64 (current working)
   - macOS Intel (x86_64)
   - Linux x86_64
   - Linux ARM64
2. **Configure hatchling** to include platform-specific binaries
3. **Test installation** on each platform

#### **Phase 3: PyPI Publication**
1. **Legal review** of Modular runtime bundling
2. **Upload to TestPyPI** for validation
3. **Production PyPI** publication

### **Technical Implementation**

#### **Update pyproject.toml**
```toml
[tool.hatch.build.targets.wheel.include]
"python/omendb/*.so" = "omendb/"
"python/omendb/native/runtime/*.dylib" = "omendb/native/runtime/"
```

#### **Update Python module loading**
```python
import os
import sys
from pathlib import Path

def _setup_native_path():
    """Set up library path for bundled Modular runtime"""
    package_dir = Path(__file__).parent
    runtime_dir = package_dir / "native" / "runtime"
    
    if runtime_dir.exists():
        if sys.platform == "darwin":
            os.environ["DYLD_LIBRARY_PATH"] = f"{runtime_dir}:{os.environ.get('DYLD_LIBRARY_PATH', '')}"
        else:  # Linux
            os.environ["LD_LIBRARY_PATH"] = f"{runtime_dir}:{os.environ.get('LD_LIBRARY_PATH', '')}"

_setup_native_path()
```

## 📊 **Validation Plan**

### **Test Matrix**
| Platform | Python | Test Scenario |
|----------|--------|---------------|
| macOS ARM64 | 3.9-3.12 | Fresh pip install + basic operations |
| macOS Intel | 3.9-3.12 | Fresh pip install + basic operations |
| Linux x86_64 | 3.9-3.12 | Fresh pip install + basic operations |
| Linux ARM64 | 3.9-3.12 | Fresh pip install + basic operations |

### **Success Criteria**
```bash
# After pip install omendb:
python -c "
from omendb import DB
db = DB('test.omen')
db.add('test', [1.0, 2.0, 3.0])
results = db.query([1.0, 2.0, 3.0], top_k=1)
assert len(results) == 1
assert results[0].similarity > 0.9
print('✅ Native acceleration working')
"
```

## 🚨 **Risks & Mitigations**

### **Legal/Licensing Risk**
**Risk**: Modular runtime bundling may violate license terms
**Mitigation**: 
- Review Modular license agreement
- Contact Modular for explicit permission
- Fallback to conda-first distribution

### **Platform Complexity Risk**
**Risk**: Cross-platform compilation becomes complex
**Mitigation**:
- Start with single platform (macOS ARM64)
- Add platforms incrementally
- Use GitHub Actions for automated builds

### **Size/Performance Risk**
**Risk**: Bundled runtime affects download/startup time
**Mitigation**:
- Monitor wheel size (target <10MB)
- Lazy load runtime libraries
- Profile startup performance

## 🎯 **Next Actions**

1. **Legal clearance**: Verify Modular runtime bundling is allowed
2. **Proof of concept**: Bundle runtime for macOS ARM64
3. **Local testing**: Validate bundled distribution works
4. **Multi-platform**: Extend to other platforms
5. **PyPI testing**: Validate on TestPyPI

**Success metric**: `pip install omendb` → working native vector database