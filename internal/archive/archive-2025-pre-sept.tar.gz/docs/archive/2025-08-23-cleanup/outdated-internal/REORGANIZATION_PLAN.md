# OmenDB Project Reorganization Plan

**Date**: August 11, 2025  
**Status**: Ready for execution

## 📊 Current Issues

### Directory Structure Problems
- **233 Python files** scattered across 5 directories
- **32 benchmark files** with many duplicates
- **test/** instead of standard **tests/**
- **profiling/** directory with only 1 file
- **Mixed content** in scripts/ (build, cleanup, dev tools)

### Specific Issues Found
1. **Duplicate benchmarks**: `benchmark.py`, `benchmark_suite.py`, `competitive_benchmark.py`
2. **Old algorithm files**: `benchmark_hnsw.py` (HNSW removed months ago)
3. **Test files in examples**: Should only have user-facing examples
4. **Mojo examples**: 10 .mojo files when focusing on Python API
5. **Non-standard naming**: Using `test/` instead of Python standard `tests/`

## ✅ Proposed Changes (45 actions)

### 1. Benchmark Consolidation (18 files)
**Move to `tests/benchmarks/`:**
- `benchmark_diskann.py` → `tests/benchmarks/test_diskann.py`
- `benchmark_suite.py` → `tests/benchmarks/test_suite.py` 
- `batch_optimization.py` → `tests/benchmarks/test_batch_performance.py`
- `test_numpy_optimization.py` → `tests/benchmarks/test_numpy_performance.py`
- `test_startup_time.py` → `tests/benchmarks/test_startup.py`

**Move to `tests/benchmarks/competitive/`:**
- `test_vs_chromadb.py` → `tests/benchmarks/competitive/test_vs_chromadb.py`
- `test_vs_lancedb.py` → `tests/benchmarks/competitive/test_vs_lancedb.py`
- `competitive_benchmark.py` → `tests/benchmarks/competitive/test_comparison.py`

**Remove duplicates:**
- `benchmark.py` (functionality in test_suite.py)
- `benchmark_hnsw.py` (HNSW removed)
- `benchmark_isolated.py` (redundant)

### 2. Test Directory Reorganization
- **Rename**: `test/` → `tests/` (Python standard)
- **Create structure**:
  ```
  tests/
  ├── __init__.py
  ├── conftest.py       # pytest configuration
  ├── unit/             # Fast tests
  ├── integration/      # System tests
  ├── benchmarks/       # Performance tests
  └── fixtures/         # Test data
  ```

### 3. Tools Directory Creation
**New structure:**
```
tools/
├── profiling/
│   └── profile_suite.py    # From profiling/
├── analysis/
│   └── clean_native.py     # From scripts/
└── benchmarking/
    └── compare_benchmarks.py  # From ci/
```

### 4. Examples Cleanup (10 files)
**Remove:**
- All `.mojo` files (focusing on Python API)
- Test-like files (`test_*.py`, `debug_*.py`)

### 5. Configuration Updates
- Update `.gitignore` with new paths
- Update GitHub Actions workflows (5 files)
- Create `tests/conftest.py` for pytest

## 🎯 Benefits

### Immediate Benefits
1. **Standard Python layout** - follows PEP 8 conventions
2. **Clear organization** - easy to find files
3. **No duplicates** - reduced from 32 to ~10 benchmark files
4. **CI-friendly** - standard paths for test discovery

### Long-term Benefits
1. **Maintainable** - clear where new files go
2. **Professional** - matches popular Python projects
3. **Scalable** - room for growth without sprawl
4. **Discoverable** - new contributors can navigate easily

## 📋 Execution Plan

### Step 1: Backup (5 min)
```bash
git status  # Ensure clean state
git branch backup-before-reorg
```

### Step 2: Run Reorganization (10 min)
```bash
python reorganize_project.py --execute
```

### Step 3: Update Imports (20 min)
- Fix any broken imports in Python files
- Update relative imports to match new structure

### Step 4: Test Everything (15 min)
```bash
pytest tests/  # Run all tests
python tools/benchmarking/benchmark_suite.py  # Test benchmarks
```

### Step 5: Commit (5 min)
```bash
git add -A
git commit -m "refactor: Reorganize project to idiomatic Python structure

- Rename test/ to tests/ (Python standard)
- Consolidate 32 benchmark files to 10
- Create tools/ directory for dev utilities
- Clean examples/ (remove test/mojo files)
- Update CI/CD paths and .gitignore"
```

## 🚀 Command to Execute

```bash
# Dry run first (already done)
python reorganize_project.py

# Execute the reorganization
python reorganize_project.py --execute

# Verify everything works
pytest tests/
```

## ⚠️ Risk Assessment

### Low Risk
- All changes are file moves/renames
- Dry run shows exactly what will happen
- Easy to revert with git

### Mitigation
- Script creates `reorganization_log.json` for rollback
- Git branch created before changes
- Can revert with: `git reset --hard HEAD~1`

## 📊 Comparison with Popular Projects

| Project | Structure | Our Plan |
|---------|-----------|----------|
| **pytest** | `testing/` dir, integrated benchmarks | ✅ Similar |
| **Django** | `tests/` dir, organized subdirs | ✅ Matching |
| **FastAPI** | `tests/` with unit/integration split | ✅ Matching |
| **NumPy** | `numpy/tests/`, separate `benchmarks/` | ✅ Similar |

## ✅ Decision: Proceed with Reorganization

**Rationale:**
1. Current structure has 233 files with poor organization
2. Reorganization reduces to cleaner structure
3. Follows Python community standards
4. Makes project more maintainable
5. Low risk, high reward

**Next Action**: Execute `python reorganize_project.py --execute`