# Performance Regression Tracking System

**A simple, reliable system for tracking OmenDB performance over commits**

## Overview

Track performance metrics in a single append-only JSONL file with commit info, enabling easy regression detection and historical analysis.

## Design Principles

1. **Simple**: One file, one format (JSONL)
2. **Reliable**: Append-only, no corruption risk
3. **Traceable**: Every result tied to exact commit
4. **Automated**: No manual tracking needed
5. **Git-friendly**: Text format, diffable, grepable

## File Structure

```
benchmarks/
├── performance_history.jsonl    # All historical data
├── track_performance.py         # Core tracking module
├── analyze_regression.py        # Analysis tools
└── baselines.json              # Expected performance ranges
```

## Data Format

Each line in `performance_history.jsonl` is a complete record:

```json
{
  "timestamp": "2025-08-04T14:30:00Z",
  "commit": "b78ac03",
  "commit_full": "b78ac03d4f5e6789...",
  "branch": "main",
  "dirty": false,
  "test": "brute_force_batch",
  "platform": "Darwin",
  "cpu_count": 16,
  "dimension": 128,
  "batch_size": 1000,
  "vec_per_sec": 71609,
  "query_latency_ms": 0.660,
  "memory_mb": 45.2
}
```

## Core Implementation

```python
# benchmarks/track_performance.py

import json
import subprocess
import datetime
import platform
import os

def get_git_info():
    """Get current git state"""
    try:
        commit = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
        branch = subprocess.check_output(['git', 'branch', '--show-current']).decode().strip()
        dirty = subprocess.call(['git', 'diff-index', '--quiet', 'HEAD']) != 0
        
        if dirty:
            print("⚠️  WARNING: Working directory has uncommitted changes")
            
        return {
            "commit": commit[:8],
            "commit_full": commit,
            "branch": branch,
            "dirty": dirty
        }
    except:
        return {
            "commit": "unknown",
            "commit_full": "unknown",
            "branch": "unknown", 
            "dirty": True
        }

def record_benchmark(test_name, metrics):
    """Record benchmark result to JSONL file"""
    git_info = get_git_info()
    
    result = {
        "timestamp": datetime.datetime.now().isoformat() + "Z",
        **git_info,
        "test": test_name,
        "platform": platform.system(),
        "cpu_count": os.cpu_count(),
        **metrics
    }
    
    # Ensure benchmarks directory exists
    os.makedirs("benchmarks", exist_ok=True)
    
    # Append to history file
    with open("benchmarks/performance_history.jsonl", "a") as f:
        f.write(json.dumps(result) + "\n")
    
    print(f"📊 Recorded: {test_name} - {metrics.get('vec_per_sec', 'N/A')} vec/s @ commit {result['commit']}")
    
    return result
```

## Usage in Benchmarks

```python
# In any benchmark script
from track_performance import record_benchmark

# Run your benchmark
results = run_benchmark()

# Record results
record_benchmark("brute_force_batch", {
    "dimension": 128,
    "batch_size": 1000,
    "vec_per_sec": results["throughput"],
    "query_latency_ms": results["latency"],
    "memory_mb": results["memory"]
})
```

## Analysis Tools

```python
# benchmarks/analyze_regression.py

def get_recent_results(test_name, n=10):
    """Get last N results for a test"""
    results = []
    with open("benchmarks/performance_history.jsonl", "r") as f:
        for line in f:
            record = json.loads(line)
            if record["test"] == test_name:
                results.append(record)
    return results[-n:]

def check_regression(test_name, current_value, metric="vec_per_sec"):
    """Check if current value is a regression"""
    history = get_recent_results(test_name, n=5)
    if not history:
        return False, "No history"
    
    baseline = statistics.median([h[metric] for h in history])
    threshold = 0.9  # 10% regression threshold
    
    if current_value < baseline * threshold:
        return True, f"REGRESSION: {current_value} vs {baseline} baseline"
    return False, f"OK: {current_value} vs {baseline} baseline"
```

## Baselines Configuration

```json
{
  "brute_force_batch": {
    "vec_per_sec": {
      "minimum": 4000,
      "expected": 70000,
      "warn_below": 60000
    },
    "query_latency_ms": {
      "maximum": 1.0,
      "expected": 0.66,
      "warn_above": 0.8
    }
  }
}
```

## Query Examples

```bash
# Last 10 results for brute force
grep "brute_force_batch" benchmarks/performance_history.jsonl | tail -10

# All results for specific commit
grep "b78ac03" benchmarks/performance_history.jsonl

# Extract just vec/s values
grep "brute_force" benchmarks/performance_history.jsonl | jq '.vec_per_sec'

# Results from clean commits only
grep '"dirty": false' benchmarks/performance_history.jsonl

# Linux vs macOS comparison
grep "Linux" benchmarks/performance_history.jsonl | jq '.vec_per_sec' | stats
grep "Darwin" benchmarks/performance_history.jsonl | jq '.vec_per_sec' | stats
```

## Integration with CI/CD

```yaml
# .github/workflows/benchmark.yml
- name: Run Performance Tests
  run: |
    python benchmarks/run_all_benchmarks.py
    
- name: Check for Regression
  run: |
    python benchmarks/analyze_regression.py --fail-on-regression
```

## Visualization

```python
# Generate performance trend graph
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_json("benchmarks/performance_history.jsonl", lines=True)
df['timestamp'] = pd.to_datetime(df['timestamp'])

# Plot performance over time
plt.figure(figsize=(12, 6))
for test in df['test'].unique():
    test_data = df[df['test'] == test]
    plt.plot(test_data['timestamp'], test_data['vec_per_sec'], label=test, marker='o')

plt.xlabel('Date')
plt.ylabel('Vectors/Second')
plt.title('OmenDB Performance Over Time')
plt.legend()
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('benchmarks/performance_trend.png')
```

## Migration from Current System

1. Run historical benchmarks and record results
2. Import any existing CSV/JSON data
3. Set baselines from recent clean runs
4. Add recording calls to all benchmark scripts

## Benefits

1. **No phantom numbers**: Every claim traceable to specific test
2. **Easy regression detection**: Compare with recent history
3. **Cross-platform analysis**: Filter by platform easily
4. **Git integration**: See exactly what code produced what performance
5. **Simple tooling**: Just grep, jq, and basic Python

## Future Enhancements

1. **Auto-commit dirty state**: Option to create commits for benchmarks
2. **Statistical analysis**: Confidence intervals, outlier detection
3. **Automated reports**: Weekly performance summaries
4. **Hardware fingerprinting**: Detect when hardware changes
5. **Test suite integration**: Run subset of benchmarks on every commit