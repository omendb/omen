# Mojo Style Guide for OmenDB

**Based on**: OmenDB codebase patterns and Modular examples  
**Purpose**: Consistent, performant, idiomatic Mojo code

## 🎯 Core Principles

1. **Performance First**: Leverage Mojo's compile-time optimizations
2. **Safety by Default**: Use value semantics and explicit ownership
3. **Hardware Adaptive**: Write code that optimizes for target platform
4. **Zero-Cost Abstractions**: Compile-time parameters over runtime checks

## 📝 Naming Conventions

### Types and Structs
```mojo
# ✅ PascalCase for types
struct VectorDatabase:
    pass

struct HNSWIndex[dtype: DType]:
    pass
```

### Functions and Variables
```mojo
# ✅ snake_case for functions and variables
fn calculate_distance(a: Vector, b: Vector) -> Float32:
    var squared_diff = 0.0
    var temp_result = compute_similarity(a, b)
    return temp_result

# ✅ Leading underscore for private
fn _internal_helper(self) -> Int:
    return self._private_field
```

### Constants and Aliases
```mojo
# ✅ UPPER_CASE for compile-time constants
alias MAX_DIMENSION = 2048
alias SIMD_WIDTH = simdwidthof[DType.float32]()
alias DEFAULT_M = 16
```

## 🏗️ Struct Design

### Traits and Initialization
```mojo
# ✅ Explicit trait conformance
struct HNSWIndex[dtype: DType](Copyable, Movable):
    var dimension: Int
    var nodes: List[Node[dtype]]
    
    # ✅ 'out' convention for constructors
    fn __init__(out self, dim: Int):
        self.dimension = dim
        self.nodes = List[Node[dtype]]()
    
    # ✅ Explicit copy semantics
    fn __copyinit__(out self, other: Self):
        self.dimension = other.dimension
        self.nodes = other.nodes
    
    # ✅ Explicit move semantics
    fn __moveinit__(out self, owned other: Self):
        self.dimension = other.dimension
        self.nodes = other.nodes^  # Transfer ownership
```

### Memory Management
```mojo
# ✅ RAII pattern for resources
struct FileHandle:
    var fd: Int
    
    fn __init__(out self, path: String):
        self.fd = open(path)
    
    fn __del__(owned self):
        if self.fd >= 0:
            close(self.fd)
```

## ⚡ Performance Patterns

### SIMD Operations
```mojo
# ✅ Hardware-adaptive SIMD width
alias simd_width = simdwidthof[dtype]()

fn process_vectors[dtype: DType](vectors: List[Scalar[dtype]]):
    @parameter
    fn simd_operation[width: Int](idx: Int):
        var chunk = SIMD[dtype, width]()
        for i in range(width):
            if idx + i < len(vectors):
                chunk[i] = vectors[idx + i]
        # Process SIMD chunk
    
    vectorize[simd_operation, simd_width](len(vectors))
```

### Parallel Processing
```mojo
# ✅ Use parallelize for independent work
from algorithm import parallelize

fn process_batch(items: List[Item]):
    @parameter
    fn process_item(idx: Int):
        # Process single item
        items[idx].process()
    
    parallelize[process_item](len(items), num_workers())
```

### Memory Optimization
```mojo
# ✅ Pre-allocate when size is known
var buffer = List[Float32]()
buffer.reserve(expected_size)

# ✅ Use InlineArray for small, fixed-size data
var small_buffer = InlineArray[Float32, 128](0.0)

# ✅ Stack allocation preferred over heap
var local_data = Stack[Float32, 256]()
```

## 🔧 Function Design

### Parameter Conventions
```mojo
# ✅ Use references to avoid copies
fn query(self, vector: List[Float32], k: Int) -> List[Result]:
    # self is borrowed by default
    pass

# ✅ Mark mutating methods
fn add(mut self, item: T):
    self.items.append(item)

# ✅ Transfer ownership with 'owned'
fn consume(owned data: List[Float32]):
    # Takes ownership of data
    process(data^)
```

### Error Handling
```mojo
# ✅ Return Bool/Optional for expected failures
fn try_add(mut self, id: String, vec: List[Float32]) -> Bool:
    if self.contains(id):
        return False
    self._add_internal(id, vec)
    return True

# ✅ Use raises for exceptional cases
fn get_vector(self, id: String) raises -> List[Float32]:
    if id not in self.data:
        raise Error("Vector not found: " + id)
    return self.data[id]

# ✅ Assertions for invariants
debug_assert(index < self.size, "Index out of bounds")
```

## 📦 Module Organization

### Import Style
```mojo
# ✅ Explicit imports
from algorithm import vectorize, parallelize
from memory import UnsafePointer
from sys.info import simdwidthof

# ❌ Avoid wildcard imports
from module import *  # Not idiomatic
```

### File Structure
```mojo
"""Module docstring describing purpose."""

# Imports
from standard.library import needed_types

# Aliases and constants
alias MAX_SIZE = 1024

# Helper functions
fn _internal_helper() -> Int:
    pass

# Main types
struct MainType:
    pass

# Public API functions
fn public_function():
    pass
```

## 📝 Documentation

### Function Documentation
```mojo
fn calculate_similarity(a: Vector, b: Vector) -> Float32:
    """Calculate cosine similarity between vectors.
    
    Uses SIMD operations for performance.
    Handles zero vectors gracefully.
    
    Args:
        a: First vector (must be normalized).
        b: Second vector (must be normalized).
    
    Returns:
        Similarity score in range [0, 1].
    """
    pass
```

### Inline Comments
```mojo
# ✅ Explain why, not what
var batch_size = 256  # Optimal for cache line efficiency

# ❌ Avoid obvious comments
var count = 0  # Initialize count to zero
```

## 🚀 Optimization Guidelines

### Compile-Time vs Runtime
```mojo
# ✅ Prefer compile-time parameters
fn process[size: Int](data: InlineArray[Float32, size]):
    # Size known at compile time
    pass

# ✅ Use @parameter for compile-time execution
@parameter
if simd_width > 8:
    # Wide SIMD path
else:
    # Narrow SIMD path
```

### Avoid Allocations
```mojo
# ✅ Reuse buffers
struct Processor:
    var buffer: List[Float32]
    
    fn process(mut self, data: List[Float32]):
        self.buffer.clear()  # Reuse existing allocation
        # Process using buffer

# ✅ Use object pools
var pool = MemoryPool[ProcessingBuffer](initial_size=16)
var buffer = pool.acquire()
# Use buffer
pool.release(buffer)
```

## ❌ Anti-Patterns to Avoid

```mojo
# ❌ Don't use raw pointers unless necessary
var ptr = UnsafePointer[Float32].alloc(size)  # Avoid

# ❌ Don't ignore ownership
fn bad_transfer(data: List[Float32]):  # Should be 'owned'
    other_func(data^)  # Error: can't transfer borrowed

# ❌ Don't skip error handling
var result = dangerous_operation()  # Should check return

# ❌ Don't use magic numbers
if vector.size > 128:  # Should be alias/constant
    pass
```

## 🎓 Best Practices Summary

1. **Think Compile-Time**: Use parameters, aliases, and @parameter
2. **Manage Memory**: Pre-allocate, reuse, use RAII
3. **Embrace SIMD**: Write vectorizable code by default
4. **Be Explicit**: About ownership, mutations, and errors
5. **Document Intent**: Why, not what
6. **Profile First**: Measure before optimizing

This guide ensures OmenDB's Mojo code is:
- **Fast**: Leverages all Mojo performance features
- **Safe**: Explicit ownership and error handling
- **Maintainable**: Consistent patterns and clear intent