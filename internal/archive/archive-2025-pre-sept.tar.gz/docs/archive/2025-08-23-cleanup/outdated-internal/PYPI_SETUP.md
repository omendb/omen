# PyPI Publication Setup

## 🚀 Publishing OmenDB to PyPI

### **Prerequisites**
1. **PyPI Account**: Register at [pypi.org](https://pypi.org) 
2. **TestPyPI Account**: Register at [test.pypi.org](https://test.pypi.org)
3. **API Tokens**: Generate tokens for both PyPI and TestPyPI

### **Build Configuration**
Following external/modular patterns, we use:
- **Build System**: hatchling (modern, Modular-standard)
- **Package Structure**: Single `python/omendb/` package
- **Native Libraries**: Automatically included (*.so, *.dylib, *.dll)

### **Publishing Commands**

#### **1. Clean and Build**
```bash
pixi run clean
pixi run build-wheel
```

#### **2. Check Package**
```bash
pixi run check-package
```

#### **3. Test Publication (TestPyPI)**
```bash
# Configure TestPyPI token
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-...your-test-token...

pixi run publish-test
```

#### **4. Production Publication**
```bash
# Configure PyPI token  
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-...your-production-token...

pixi run publish
```

### **Package Validation**

#### **Local Install Test**
```bash
# After test publication
pip install --index-url https://test.pypi.org/simple/ omendb

# Test functionality
python -c "from omendb import DB; print('✅ Package works')"
```

#### **Production Install Test**
```bash
# After production publication
pip install omendb

# Test functionality  
python -c "from omendb import DB; db = DB(); print('✅ Production ready')"
```

### **Version Management**
- **Current**: 0.1.0 (initial release)
- **Next**: Update `__version__` in `python/omendb/__init__.py`
- **Semantic Versioning**: MAJOR.MINOR.PATCH

### **Release Checklist**
- [ ] All tests passing: `pixi run test`
- [ ] API documentation updated
- [ ] Examples working with new API
- [ ] Native libraries built for all platforms
- [ ] Version number incremented
- [ ] Changelog updated
- [ ] Build succeeds: `pixi run build-wheel`
- [ ] Package validation: `pixi run check-package`

### **Platform Support**
- **macOS**: Apple Silicon (arm64) + Intel (x86_64)
- **Linux**: x86_64 + aarch64
- **Windows**: x86_64 (future)

### **Dependencies**
- **Core**: No external dependencies (embedded database)
- **Build**: hatchling, setuptools
- **Development**: build, twine, pytest

### **API Design Alignment**
✅ Matches industry standards:
- **ChromaDB**: `collection.add(embeddings=vectors, ids=ids)`
- **Pinecone**: `index.query(vector=vector, top_k=10)`
- **OmenDB**: `db.add(id, vector)` and `db.query(vector, top_k=10)`

Ready for professional PyPI distribution!