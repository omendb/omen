# OmenDB Documentation Style Guide

## Writing Principles

### Tone & Voice
- **Confident but approachable**: We have real advantages (RoarGraph, instant startup)
- **Technical accuracy**: Always use measured performance data
- **Developer-first**: Focus on practical examples and clear APIs
- **Concise**: Respect developer time with scannable content

### Target Audience
- **Primary**: Python developers building AI applications
- **Secondary**: ML engineers, data scientists, researchers
- **Use cases**: RAG systems, recommendation engines, semantic search

## Content Structure

### Documentation Hierarchy
```
README.md                    # Marketing introduction + quick start
├── docs/
│   ├── user/
│   │   ├── quickstart.md    # 2-minute getting started
│   │   ├── api-reference.md # Complete method documentation
│   │   └── examples/        # Real-world use cases
│   ├── performance/
│   │   ├── benchmarks.md    # Current measured baselines
│   │   └── optimization.md  # Performance tuning guide
│   └── internals/
│       ├── architecture.md  # Design decisions
│       └── roargraph.md     # Algorithm explanation
```

### Page Template
```markdown
# Page Title

Brief description of what this covers.

## Quick Example

```python
# Working code example that demonstrates the concept
from omendb import DB
db = DB()
# ... practical example
```

## Core Concepts

### Concept 1
Clear explanation with code examples.

### Concept 2  
Another concept with examples.

## Common Patterns

Real-world usage patterns developers actually need.

## Troubleshooting

Common issues and solutions.
```

## Code Examples

### Requirements
- **All examples must work** with the current API
- **Copy-paste ready** with imports and setup
- **Real-world context** not toy examples
- **Multiple frameworks** when relevant (NumPy, PyTorch, etc.)

### Example Format
```python
# Context: What this example demonstrates
from omendb import DB
import numpy as np  # Include all imports

# Step 1: Setup (always show this)
db = DB()

# Step 2: Demonstrate the concept
vectors = np.random.rand(1000, 128).astype(np.float32)
for i, vector in enumerate(vectors):
    db.add(f"doc_{i}", vector.tolist())

# Step 3: Show the result
query = np.random.rand(128).tolist()
results = db.search(query, limit=5)
print(f"Found {len(results)} similar vectors")
```

### Framework Integration Examples
```python
# PyTorch tensors
import torch
tensor = torch.randn(256)
db.add("pytorch_doc", tensor)  # Auto-converts

# TensorFlow tensors  
import tensorflow as tf
tensor = tf.random.normal([256])
db.add("tensorflow_doc", tensor)  # Auto-converts

# NumPy arrays
import numpy as np
array = np.random.rand(256)
db.add("numpy_doc", array)
```

## Performance Documentation

### Benchmark Presentation
- **Always include hardware specs**: "Intel CPU, Linux, 128D vectors"
- **Use real measured data**: From `benchmarks/CURRENT_BASELINES.md`
- **Show scaling characteristics**: Small, medium, large datasets
- **Include comparison context**: vs alternatives when fair

### Performance Claims Format
```markdown
## Performance (Measured July 2025)

**Test Environment**: Intel CPU, Linux

| Vectors | Insertion | Query | Startup |
|---------|-----------|-------|---------|
| 1,000   | 1,323/s   | 0.21ms | 0.001ms |
| 10,000  | 12,408/s  | 0.19ms | 0.001ms |
| 50,000  | 13,150/s  | 0.14ms | 0.001ms |

**RoarGraph Advantage**: 5-10x faster construction than HNSW
```

## API Documentation

### Method Documentation Format
```python
def query(self, vector: List[float], top_k: int = 10) -> List[SearchResult]:
    """Search for similar vectors.
    
    Args:
        vector: Query vector as list of floats
        top_k: Maximum number of results to return (default: 10)
        
    Returns:
        List of SearchResult objects with id, similarity, and metadata
        
    Raises:
        ValidationError: If vector dimension doesn't match database
        
    Example:
        >>> results = db.query([0.1, 0.2, 0.3], top_k=5)
        >>> for result in results:
        ...     print(f"{result.id}: {result.similarity}")
    """
```

### Error Documentation
```python
# Show both the error and the fix
try:
    db.add("vec1", [1.0, 2.0, 3.0])  # 3D vector
    db.query([1.0, 2.0], top_k=10)   # 2D query - dimension mismatch!
except ValidationError as e:
    print(f"Error: {e}")
    # Fix: Use same dimension
    results = db.query([1.0, 2.0, 3.0], top_k=10)  # ✅ Correct
```

## Architecture Documentation

### Design Decision Format
```markdown
## Decision: Single Dimension Per Process

**Context**: Vector databases need to handle multiple embedding models.

**Decision**: One dimension per database instance.

**Rationale**:
- 99% of applications use single embedding model
- Optimal performance for common case
- Server edition handles multiple dimensions
- Clear error messages for mismatches

**Consequences**:
- ✅ Optimal performance for single model
- ✅ Simple API design
- ❌ Requires multiple instances for multiple models
```

## Language and Style

### Technical Terms
- **Vector database** (not "vectorDB" or "vector DB")
- **RoarGraph algorithm** (proper capitalization)
- **Instant startup** (our differentiator)
- **Production ready** (not "production-ready")

### Avoid
- Marketing fluff ("blazing fast", "revolutionary")
- Unsubstantiated claims without measurements
- Complex jargon without explanation
- Outdated performance numbers

### Prefer
- Specific measurements ("0.001ms startup")
- Clear explanations ("RoarGraph algorithm advantage")
- Practical examples (real-world use cases)
- Honest limitations ("single dimension per process")

## Visual Elements

### Code Blocks
- Always specify language: `python`, `bash`, `yaml`
- Include comments explaining non-obvious parts
- Use realistic variable names and data
- Show both success and error cases

### Callouts
```markdown
> **Performance Note**: Use batches ≥5 vectors for optimal throughput.

> **Important**: All vectors must have the same dimension.

> **Tip**: Check `db.stats()` to see current performance metrics.
```

### Links
- Always use descriptive link text
- Link to specific sections: `[API Reference](docs/user/api-reference.md#query-method)`
- External links open in new tab for reference docs

## Maintenance

### Content Updates
- Update performance numbers when new benchmarks available
- Test all code examples with each release
- Review for outdated information quarterly
- Keep examples working with latest API

### Quality Checklist
- [ ] All code examples tested and working
- [ ] Performance claims backed by current data
- [ ] Links functional and pointing to correct sections
- [ ] Language consistent with style guide
- [ ] Examples show realistic use cases
- [ ] Error handling demonstrated where relevant

---

**Goal**: Documentation so clear that developers succeed in 2 minutes, not 2 hours.