# OmenDB Technical Architecture

**Last Updated**: August 5, 2025  
**Consolidated technical reference for all platform components**

## 🏗️ System Architecture

### Embedded Database (../omendb/)
- **Engine**: Pure Mojo with HNSW algorithm
- **Performance**: 99,261 vec/s @128D verified
- **Storage**: Single-file embedded database
- **Interface**: Python FFI with zero-copy NumPy

### Server Platform (server/)
- **Framework**: Rust with Axum/Tonic
- **APIs**: HTTP REST + gRPC
- **Authentication**: JWT + API keys with multi-tenant RBAC
- **Deployment**: Kubernetes with HPA, monitoring

### Admin Dashboard (admin/)
- **Backend**: FastAPI (planned v0.3.0)
- **Frontend**: SolidJS
- **Features**: Customer management, usage analytics, billing

## 📡 API Specification

### Core Operations
```python
# Embedded API
db = omendb.DB()
db.add(id, vector, metadata)
db.search(vector, limit=10)
db.delete(id)
db.clear()

# Server API (REST)
POST /v1/vectors
GET /v1/search?vector=[...]&limit=10
DELETE /v1/vectors/{id}
```

### FFI Bridge Design
- **Approach**: Python FFI (not C FFI) for type safety
- **Overhead**: <0.2ms per operation
- **Zero-copy**: Direct NumPy array access

### Protocol Evolution (Server Mode)
- **v0.1.0**: JSON over HTTP (current, 33K vec/s)
- **v0.2.0**: Binary protocol (MessagePack/ProtoBuf, target 60K vec/s)
  - 50-60% reduction in serialization overhead
  - Maintain HTTP for compatibility
  - gRPC for high-performance clients
- **v0.3.0**: Shared memory for local deployments (target 100K+ vec/s)
  - Zero serialization for same-machine clients
  - Unix domain sockets for IPC
  - Direct memory mapping for bulk operations

## 🚀 Scaling Architecture

### Horizontal Scaling
- **Sharding**: Consistent hashing by vector ID
- **Replication**: 3x with quorum reads
- **Load Balancing**: Round-robin with health checks

### Performance Targets
- **Throughput**: 10K+ QPS per cluster
- **Latency**: P99 <10ms
- **Availability**: 99.9% SLA

## 💾 Storage Design

### Tiered Storage
- **Hot**: In-memory HNSW graph (<1GB)
- **Warm**: Memory-mapped files (1-100GB)
- **Cold**: Object storage (100GB+)

### Data Format
- **Vectors**: Columnar storage, SIMD-aligned
- **Metadata**: MessagePack serialization
- **Indexes**: Custom binary format

## 🔧 Key Technical Decisions

1. **Mojo over Rust/C++**: Leverage MLIR for SIMD optimization
2. **Python FFI over C FFI**: Better type safety, easier maintenance
3. **Rust server over Python**: Performance and memory safety
4. **Single DB per process**: Simplicity and performance (like SQLite)

## 📚 References

- Detailed server design: See RUST_SERVER_DESIGN.md in archive
- Storage internals: See STORAGE_SPEC.md in archive
- API details: See API_SPEC.md in archive