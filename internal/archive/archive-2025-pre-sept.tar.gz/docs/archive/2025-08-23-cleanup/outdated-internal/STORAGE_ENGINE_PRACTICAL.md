# OmenDB Storage Engine - Practical Implementation

**Date**: August 9, 2025  
**Version**: 3.0 - State-of-art adapted for OmenDB  
**Status**: Ready for implementation

## 🎯 **Core Philosophy**

After analyzing RocksDB, FoundationDB, Qdrant, and others, here's what actually matters:

1. **Reliability > Features** - Simple and correct beats complex and fast
2. **Embedded-first** - This is our differentiator, don't dilute it
3. **Pluggable storage** - Core engine has interfaces, implementations are swappable
4. **Progressive enhancement** - Start simple, add complexity only when proven necessary

## 📊 **State of the Art Analysis**

### What Works (Industry Consensus)
- **WAL for durability** - Every serious database uses it (Postgres, MySQL, SQLite, Qdrant)
- **Memory-mapped files** - Flexible RAM usage (Qdrant, LMDB, SQLite)
- **Segment architecture** - Better than monolithic files (Elasticsearch, Qdrant)
- **Deterministic testing** - FoundationDB's secret weapon (but complex)

### What's Overengineered
- **Tiered storage** - Most users won't need it, adds complexity
- **LSM trees** - Great for write-heavy KV, overkill for vectors
- **Distributed consensus** - Server problem, not embedded problem

## 🏗️ **Practical Architecture**

### Storage Trait (Core Interface)
```mojo
trait StorageEngine:
    """Minimal interface that core engine depends on."""
    
    fn save_vector(self, id: String, vector: List[Float32], metadata: Dict) raises -> Bool
    fn load_vector(self, id: String) raises -> Optional[List[Float32]]
    fn delete_vector(self, id: String) raises -> Bool
    fn iterate_vectors(self) raises -> Iterator[Tuple[String, List[Float32]]]
    fn checkpoint(self) raises -> Bool  # Force persistence
    fn recover(self) raises -> Stats     # Load from disk
```

### Implementation 1: InMemoryStorage (Current)
```mojo
struct InMemoryStorage(StorageEngine):
    """No persistence - for testing and benchmarks."""
    var vectors: Dict[String, List[Float32]]
    
    fn checkpoint(self) -> Bool:
        return True  # No-op
    
    fn recover(self) -> Stats:
        return Stats(recovered=0)  # Nothing to recover
```

### Implementation 2: SnapshotStorage (Embedded Mode)
```mojo
struct SnapshotStorage(StorageEngine):
    """SQLite-style single file persistence."""
    var path: String
    var dirty_count: Int = 0
    var checkpoint_interval: Int = 10000
    
    fn save_vector(self, id: String, vector: List[Float32], metadata: Dict) -> Bool:
        # Write to memory
        self.vectors[id] = vector
        self.dirty_count += 1
        
        # Auto-checkpoint if needed
        if self.dirty_count >= self.checkpoint_interval:
            self.checkpoint()
        
        return True
    
    fn checkpoint(self) raises -> Bool:
        """Atomic snapshot write."""
        # Write to temp file
        var temp_path = self.path + ".tmp"
        var file = open(temp_path, "wb")
        
        # Simple format: count, then vectors
        file.write_u64(len(self.vectors))
        for id, vector in self.vectors:
            file.write_string(id)
            file.write_vector(vector)
        
        file.close()
        
        # Atomic rename
        rename(temp_path, self.path)
        self.dirty_count = 0
        return True
    
    fn recover(self) raises -> Stats:
        """Fast recovery via mmap."""
        if not exists(self.path):
            return Stats(recovered=0)
        
        # Memory-map the file
        var mmap = mmap_file(self.path)
        var count = mmap.read_u64()
        
        # Load vectors
        for _ in range(count):
            var id = mmap.read_string()
            var vector = mmap.read_vector()
            self.vectors[id] = vector
        
        return Stats(recovered=count)
```

### Implementation 3: WALStorage (Server Mode)
```mojo
struct WALStorage(StorageEngine):
    """Write-ahead log for durability."""
    var wal_dir: String
    var segment_dir: String
    var wal: WriteAheadLog
    var segments: List[Segment]
    
    fn save_vector(self, id: String, vector: List[Float32], metadata: Dict) -> Bool:
        # Write to WAL first (durability)
        var op = Operation.Insert(id, vector, metadata)
        var seq = self.wal.append(op)
        
        # Then to memory
        self.vectors[id] = vector
        
        # Background flush to segments
        if self.wal.size() > WAL_THRESHOLD:
            self.flush_to_segment()
        
        return True
    
    fn recover(self) raises -> Stats:
        """Recover from WAL + segments."""
        var recovered = 0
        
        # Load segments first
        for segment in list_segments(self.segment_dir):
            recovered += self.load_segment(segment)
        
        # Replay WAL for recent operations
        for op in self.wal.replay():
            self.apply_operation(op)
            recovered += 1
        
        return Stats(recovered=recovered)
```

## 🔧 **Implementation Strategy**

### Phase 1: Minimal Viable Persistence (THIS WEEK)
```python
# Just add checkpoint/recover to existing code
db = omendb.DB(persist="snapshot.omen")
# Auto-saves every 10K operations
# Recovers on startup
```

Implementation steps:
1. Add StorageEngine trait to native.mojo
2. Refactor current code to use trait
3. Implement SnapshotStorage
4. Add checkpoint() to Python API
5. Test crash recovery

### Phase 2: Production Persistence (NEXT WEEK)
```python
# Add WAL for durability
db = omendb.DB(
    persist="wal",
    wal_dir="/var/omendb/wal",
    checkpoint_interval=10000
)
```

Implementation steps:
1. Implement simple WAL (append-only file)
2. Add background checkpointing
3. Test crash recovery with WAL
4. Benchmark overhead (<5% target)

### Phase 3: Advanced Features (LATER)
Only if proven necessary:
- Memory-mapped segments
- Compression (zstd)
- Async I/O (io_uring)
- Tiered storage

## 📋 **File Formats**

### Snapshot Format (.omen)
```
[Magic: "OMEN"]      4 bytes
[Version: 1]         4 bytes  
[Vector Count]       8 bytes
[Dimension]          4 bytes
[Reserved]          12 bytes
[Vectors...]         Variable
  [ID Length]        4 bytes
  [ID]               Variable
  [Vector]           dimension * 4 bytes
```

### WAL Format (.wal)
```
[Magic: "OLOG"]      4 bytes
[Sequence]           8 bytes
[Operation Type]     1 byte
[Timestamp]          8 bytes
[Payload Length]     4 bytes
[Payload]           Variable
[CRC32]             4 bytes
```

## 🎯 **Success Metrics**

| Metric | Target | Priority |
|--------|--------|----------|
| Data durability | Zero loss | P0 |
| Checkpoint overhead | <5% | P0 |
| Recovery time | <1s for 1M vectors | P1 |
| File size | <1.1x raw vectors | P1 |
| Concurrent readers | Unlimited | P2 |

## 🚀 **Why This Approach**

1. **Proven patterns** - WAL and snapshots are battle-tested
2. **Simple to implement** - Can ship in days, not months
3. **Pluggable** - Can swap implementations without changing core
4. **Progressive** - Start simple, enhance based on real needs
5. **Embedded-friendly** - Single file like SQLite is perfect for embedded

## 📝 **Marketing Position**

**Keep "embedded" as primary identity:**
- "The SQLite of vector databases"
- "Embedded-first, server-capable"
- "Zero-dependency vector storage"

**Why embedded matters:**
- Edge AI is growing (phones, IoT, browsers)
- Simplicity is valuable (no ops overhead)
- Local-first is a trend (privacy, latency)
- Unique position (most competitors are server-only)

## 🔄 **Migration from Current Code**

```mojo
# Current (in native.mojo)
struct VectorStore:
    var write_buffer: BruteForceIndex
    var main_index: HNSWIndex
    
# New (minimal change)
struct VectorStore:
    var write_buffer: BruteForceIndex
    var main_index: HNSWIndex
    var storage: StorageEngine  # Added
    
    fn __init__(mut self, ...):
        # Default to in-memory
        self.storage = InMemoryStorage()
    
    fn add_vector(mut self, ...):
        # Same logic, plus:
        self.storage.save_vector(id, vector, metadata)
```

## ✅ **Next Actions**

1. **TODAY**: Implement StorageEngine trait in native.mojo
2. **TOMORROW**: Add SnapshotStorage implementation
3. **THIS WEEK**: Ship v0.2.0 with basic persistence
4. **NEXT WEEK**: Add WAL for server mode

## 📚 **References**

This document supersedes:
- STORAGE_ENGINE_DESIGN_2025.md (overengineered)
- All archived storage docs

Based on:
- SQLite's simplicity (single file, embedded)
- Qdrant's architecture (WAL + segments)
- FoundationDB's testing (future goal)
- RocksDB's proven LSM design (inspiration only)