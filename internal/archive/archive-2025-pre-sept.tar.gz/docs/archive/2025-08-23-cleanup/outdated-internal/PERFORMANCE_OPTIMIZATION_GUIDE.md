# OmenDB Performance Optimization Guide

**Version**: 0.1.2  
**Last Updated**: August 8, 2025

## 🚀 Quick Start: Optimal Performance

### For Small Datasets (<5K vectors)
```python
# Best performance for small datasets
db = omendb.DB(expected_size=1000)  # Auto-selects brute force
```

### For Large Datasets (>5K vectors)
```python
# Avoid migration overhead for large datasets
db = omendb.DB(expected_size=100000)  # Auto-selects HNSW from start
```

### For High-Dimensional Vectors (768D+)
```python
# Force HNSW for standard embeddings
db = omendb.DB(force_algorithm='hnsw')
```

## 📊 Performance Characteristics

### Default Behavior
- **<5,000 vectors**: Uses brute force (perfect accuracy, fastest for small datasets)
- **≥5,000 vectors**: Migrates to HNSW (approximate, scalable)
- **Migration overhead**: Can cause 150x slowdown during transition

### Optimized Behavior
- **With `expected_size`**: Avoids migration, selects optimal algorithm upfront
- **With `force_algorithm`**: Complete control over algorithm selection
- **Smart batching**: Automatically chunks large batches into 5K segments

## 🎯 Common Use Cases

### 1. RAG Applications (10K-100K documents)
```python
# Optimal for typical RAG systems
db = omendb.DB(expected_size=50000)

# Add embeddings efficiently
db.add_batch(
    vectors=embeddings,  # Use NumPy arrays for best performance
    ids=document_ids
)
```

### 2. Semantic Search (1M+ vectors)
```python
# Large-scale semantic search
db = omendb.DB(
    expected_size=1000000,
    migration_threshold=10000000  # Never migrate
)
```

### 3. Real-time Applications (<1K vectors)
```python
# Ultra-fast for small, frequently updated datasets
db = omendb.DB(
    expected_size=500,
    force_algorithm='brute_force'
)
```

### 4. Benchmarking/Testing
```python
# Consistent performance for benchmarks
db = omendb.DB(
    force_algorithm='hnsw',  # No migration surprises
    migration_threshold=10000000
)
```

## 📈 Performance Numbers

### Insertion Performance
| Configuration | Vectors/Second | Use Case |
|--------------|---------------|----------|
| Brute force (<5K) | 80-100K | Small datasets |
| HNSW (no migration) | 80-100K | Large datasets |
| Default (with migration) | 500-1K | Avoid this! |

### Query Performance
| Algorithm | Latency | Accuracy |
|-----------|---------|----------|
| Brute force | 0.5-2ms | 100% |
| HNSW | 0.8-3ms | 95-99% |

### Memory Usage
| Vectors | Brute Force | HNSW |
|---------|------------|------|
| 1K | ~4MB | ~6MB |
| 10K | ~40MB | ~60MB |
| 100K | ~400MB | ~600MB |
| 1M | ~4GB | ~6GB |

## 🔧 Advanced Optimization

### NumPy Arrays (Recommended)
```python
import numpy as np

# Best performance with NumPy arrays
vectors = np.random.rand(10000, 768).astype(np.float32)
db.add_batch(vectors=vectors)  # 95K+ vec/s
```

### Batch Operations
```python
# Add many vectors at once (automatically chunked)
db.add_batch(vectors=large_array)  # Handles millions of vectors

# Better than:
for vec in vectors:  # Slow!
    db.add(vec)
```

### Dimension-Specific Tips
```python
# Low dimensions (128D)
db = omendb.DB()  # Default is fine

# Standard embeddings (768D)
db = omendb.DB(expected_size=10000)  # Specify size

# High dimensions (1536D+)
db = omendb.DB(force_algorithm='hnsw')  # Force HNSW
```

## ⚠️ Common Pitfalls

### 1. Migration Overhead
**Problem**: Performance drops 150x when crossing 5K vectors  
**Solution**: Use `expected_size` parameter

### 2. Using Lists Instead of NumPy
**Problem**: 30% slower with Python lists  
**Solution**: Convert to NumPy arrays first

### 3. Single Vector Insertions
**Problem**: 100x slower than batch operations  
**Solution**: Collect vectors and use `add_batch()`

### 4. Not Specifying Expected Size
**Problem**: Suboptimal algorithm selection  
**Solution**: Always provide `expected_size` when known

## 🏗️ Migration Strategies

### From ChromaDB
```python
# ChromaDB style
import chromadb
client = chromadb.Client()
collection = client.create_collection("test")

# OmenDB equivalent (faster)
import omendb
db = omendb.DB(expected_size=10000)
```

### From Faiss
```python
# Faiss style
import faiss
index = faiss.IndexFlatL2(768)

# OmenDB equivalent (simpler)
import omendb
db = omendb.DB(expected_size=10000)
```

## 📊 Benchmarking

### Measure Performance
```python
import time
import numpy as np

# Generate test data
vectors = np.random.rand(10000, 768).astype(np.float32)
query = vectors[0]

# Measure insertion
start = time.time()
db.add_batch(vectors)
print(f"Insertion: {10000/(time.time()-start):.0f} vec/s")

# Measure query
start = time.time()
results = db.search(query, limit=10)
print(f"Query: {(time.time()-start)*1000:.2f}ms")
```

## 🆘 Troubleshooting

### Slow Performance?
1. Check if migration is occurring (watch for 5K threshold)
2. Verify using NumPy arrays, not lists
3. Use batch operations, not single insertions
4. Set `expected_size` or `force_algorithm`

### Memory Issues?
1. Large batches are automatically chunked (5K vectors)
2. Consider using HNSW for datasets >100K vectors
3. Monitor memory usage during migration

### Accuracy Concerns?
1. Brute force: 100% accuracy (use for <5K vectors)
2. HNSW: 95-99% accuracy (tunable with parameters)
3. Use `force_algorithm='brute_force'` for perfect recall

## 🎯 Summary

**For optimal performance:**
1. **Always specify `expected_size`** when known
2. **Use NumPy arrays** for vector data
3. **Batch operations** whenever possible
4. **Force HNSW** for high-dimensional data (768D+)
5. **Avoid migration** by choosing algorithm upfront

**Remember**: OmenDB's instant startup (0.033ms) is its superpower. Configure it right, and you'll get blazing-fast performance that rivals or beats specialized vector databases.