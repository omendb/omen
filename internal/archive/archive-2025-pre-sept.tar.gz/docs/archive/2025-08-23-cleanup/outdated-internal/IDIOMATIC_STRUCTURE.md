# Idiomatic Python Project Structure for OmenDB

**Date**: August 11, 2025  
**Status**: Proposed reorganization

## 📊 Current Structure Analysis

### Current File Distribution
- `benchmarks/`: 32 Python files (many duplicates)
- `profiling/`: 1 file (profile_suite.py)
- `test/`: 149 Python files
- `scripts/`: 21 Python files
- `examples/`: 30 Python files
- **Total**: 233 Python files across 5 directories

### Issues with Current Structure
1. **Benchmarks scattered**: Performance tests in both `benchmarks/` and `test/benchmarks/`
2. **Profiling isolated**: Single file in its own directory
3. **Scripts mixed**: Build scripts, cleanup scripts, dev tools all together
4. **Duplicate files**: Multiple versions of same benchmarks
5. **Non-standard naming**: Using `test/` instead of `tests/`

## 🎯 Idiomatic Python Structure

### Standard Python Project Layout
```
omendb/
├── omendb/              # Source code (keep as is)
│   ├── __init__.py
│   ├── api.py
│   └── ...
├── tests/               # All tests (renamed from test/)
│   ├── unit/            # Fast, isolated tests
│   ├── integration/     # System tests
│   ├── benchmarks/      # Performance tests (consolidated)
│   └── fixtures/        # Test data and helpers
├── examples/            # User-facing examples only
│   ├── quickstart.py
│   ├── advanced/
│   └── README.md
├── scripts/             # Development tools only
│   ├── build.sh
│   └── release.py
├── docs/                # Documentation
├── ci/                  # CI/CD specific files
└── tools/               # Development utilities
    ├── profiling/       # Profiling tools
    └── analysis/        # Code analysis tools
```

## 📁 Detailed Reorganization Plan

### 1. Tests Directory (`tests/` not `test/`)
**Rationale**: `tests/` is the Python standard (pytest, Django, Flask)

```
tests/
├── __init__.py
├── conftest.py          # pytest configuration
├── unit/                # Fast tests (<1s each)
│   ├── test_api.py
│   ├── test_distance.py
│   └── test_storage.py
├── integration/         # Slower tests (>1s)
│   ├── test_end_to_end.py
│   ├── test_persistence.py
│   └── test_large_scale.py
├── benchmarks/          # Performance tests
│   ├── __init__.py
│   ├── conftest.py      # Benchmark fixtures
│   ├── test_insertion.py
│   ├── test_query.py
│   ├── test_memory.py
│   └── competitive/     # vs other databases
│       ├── test_vs_chromadb.py
│       ├── test_vs_faiss.py
│       └── test_vs_lancedb.py
└── fixtures/            # Shared test data
    ├── vectors.py
    └── datasets.py
```

### 2. Examples Directory (Simplified)
**Rationale**: Only user-facing examples, no test code

```
examples/
├── README.md            # Index of examples
├── quickstart.py        # Simple getting started
├── batch_operations.py  # Batch processing
├── persistence.py       # Using persistence
├── advanced/
│   ├── high_dimensions.py
│   ├── custom_distance.py
│   └── production_setup.py
└── integrations/
    ├── pytorch_example.py
    ├── tensorflow_example.py
    └── langchain_example.py
```

### 3. Tools Directory (New)
**Rationale**: Separate development tools from scripts

```
tools/
├── profiling/
│   ├── profile_suite.py    # Main profiler
│   ├── memory_profiler.py
│   └── cpu_profiler.py
├── analysis/
│   ├── audit_project.py
│   ├── cleanup_project.py
│   └── code_quality.py
└── benchmarking/
    ├── benchmark_suite.py   # Main benchmark runner
    └── compare_results.py
```

### 4. Scripts Directory (Minimal)
**Rationale**: Only essential build/release scripts

```
scripts/
├── build.sh             # Build native module
├── test.sh              # Run all tests
├── release.py           # Release automation
└── setup_dev.sh         # Dev environment setup
```

### 5. CI Directory
**Rationale**: CI-specific files separate from scripts

```
ci/
├── run_tests.py
├── benchmark.py
├── compare_benchmarks.py
└── requirements-ci.txt
```

## 🔄 Migration Steps

### Phase 1: Consolidate Benchmarks (1 hour)
1. Move all benchmark files to `tests/benchmarks/`
2. Remove duplicates (keep best version)
3. Standardize naming: `test_*.py`
4. Update imports

### Phase 2: Reorganize Tests (30 min)
1. Rename `test/` to `tests/`
2. Ensure proper `__init__.py` files
3. Add `conftest.py` for pytest
4. Update CI paths

### Phase 3: Create Tools Directory (30 min)
1. Move `profiling/profile_suite.py` to `tools/profiling/`
2. Move development utilities from `scripts/`
3. Move analysis tools to `tools/analysis/`

### Phase 4: Clean Examples (30 min)
1. Remove test code from examples
2. Keep only user-facing examples
3. Organize by complexity
4. Update README with index

### Phase 5: Update Configuration (30 min)
1. Update `.gitignore`
2. Update `pyproject.toml` test paths
3. Update GitHub Actions
4. Update documentation

## 📝 Files to Consolidate/Remove

### Benchmark Duplicates to Merge
- `benchmark.py`, `benchmark_suite.py` → `tests/benchmarks/test_performance.py`
- `competitive_benchmark.py` + others → `tests/benchmarks/competitive/`
- `benchmark_*.py` files → Merge into topic-specific test files

### Scripts to Move to Tools
- Profiling scripts → `tools/profiling/`
- Cleanup scripts → `tools/analysis/`
- Development utilities → `tools/`

### Examples to Simplify
- Remove `.mojo` examples (if Python-focused)
- Consolidate similar examples
- Move test-like examples to `tests/`

## ✅ Benefits of This Structure

1. **Standard Python Layout**: Follows PEP 8 and community conventions
2. **Clear Separation**: Tests, examples, tools clearly separated
3. **No Duplication**: Single location for each type of file
4. **Discoverable**: Easy to find what you need
5. **CI-Friendly**: Standard paths for test discovery
6. **Maintainable**: Clear where new files should go

## 🎯 Decision Points

### Option A: Full Reorganization (Recommended)
- **Pros**: Clean, idiomatic, maintainable
- **Cons**: 3-hour effort, breaks existing paths
- **When**: Before next release

### Option B: Minimal Changes
- Just consolidate benchmarks into `tests/benchmarks/`
- Move profiling to `tests/profiling/`
- **Pros**: Quick (30 min)
- **Cons**: Not fully idiomatic

### Option C: Gradual Migration
- Start with Option B
- Move to Option A over time
- **Pros**: Less disruptive
- **Cons**: Inconsistent during transition

## 📊 Comparison with Popular Projects

| Project | Tests Dir | Benchmarks Location | Tools Location |
|---------|-----------|-------------------|----------------|
| pytest | `testing/` | `testing/` | `scripts/` |
| Django | `tests/` | `tests/benchmarks/` | `scripts/` |
| FastAPI | `tests/` | `tests/` | `scripts/` |
| NumPy | `numpy/tests/` | `benchmarks/` | `tools/` |
| Pandas | `pandas/tests/` | `asv_bench/` | `scripts/` |
| **OmenDB (proposed)** | `tests/` | `tests/benchmarks/` | `tools/` |

## 🚀 Immediate Actions

1. **Consolidate duplicate benchmarks** (highest ROI)
2. **Move profiling under tests or tools**
3. **Clean up examples** (remove test code)
4. **Update .gitignore**
5. **Document the structure in README**

## 📋 Checklist for Implementation

- [ ] Get approval on structure
- [ ] Create migration script
- [ ] Backup current structure
- [ ] Execute reorganization
- [ ] Update all imports
- [ ] Update CI/CD paths
- [ ] Update documentation
- [ ] Run full test suite
- [ ] Update .gitignore
- [ ] Commit with clear message

---

**Recommendation**: Go with Option A (Full Reorganization) as it will save time in the long run and make the project more professional and maintainable.