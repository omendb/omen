# Storage Engine Architecture Decision

**Date**: December 2024  
**Decision**: Keep integrated, vector-optimized storage engine  
**Review**: After v1.0 when we understand requirements better

## 🤔 The Question

Should we build a separate, general-purpose storage engine library in Mojo, or keep it integrated and vector-specific?

## 📊 Analysis

### Option 1: Separate General-Purpose Storage Engine

**Pros:**
- Could become its own product (like RocksDB, LMDB)
- Reusable for other Mojo projects
- Clear separation of concerns
- Easier to test in isolation
- Could attract specialized contributors
- Marketing value: "Built on MojoDB" 

**Cons:**
- **Complexity overhead** for solo developer
- **Another repository** to maintain
- **Generalization penalty** - can't optimize for vectors
- **API design burden** - need stable public API
- **Documentation overhead** - two projects to document
- **Slower iteration** - changes need coordination

### Option 2: Integrated Vector-Optimized Storage (CHOSEN ✅)

**Pros:**
- **Vector-specific optimizations** possible:
  - Fixed-size records (all vectors same dimension)
  - Batch operations optimized (common pattern)
  - Graph storage for DiskANN index
  - SIMD-aligned memory layouts
  - Dimension-aware compression
- **Faster development** - no API boundaries
- **Single repository** - easier for solo dev
- **Co-evolution** - storage and algorithm evolve together
- **Performance** - no abstraction overhead

**Cons:**
- Not reusable for other projects
- Tightly coupled to OmenDB
- Less modular architecture

## 🎯 Decision: Vector-Optimized, Integrated

### Why This Makes Sense

1. **Solo Developer Reality**
   - Limited bandwidth for maintaining multiple projects
   - Need to focus on core product, not infrastructure
   - Can always extract later if successful

2. **Vector-Specific Optimizations Critical**
   ```mojo
   struct VectorStorage:
       # Vector-specific design
       var dimension: Int              # Fixed per database
       var vector_size: Int            # Precomputed: dimension * sizeof(Float32)
       var vectors_per_page: Int       # Aligned for SIMD
       var graph_pages: GraphStorage   # DiskANN graph structure
       
       # NOT general KV store patterns
       # No variable-length values
       # No arbitrary key types
       # No schema flexibility
   ```

3. **Performance Advantages**
   - **Memory layout**: Vectors packed for cache efficiency
   - **SIMD alignment**: Pages aligned for vector operations  
   - **Batch operations**: Optimized for vector batches
   - **Graph locality**: DiskANN nodes stored near vectors
   - **Compression**: Dimension-aware quantization

4. **Architectural Clarity**
   ```
   OmenDB Application Layer
          ↓
   DiskANN Algorithm
          ↓
   Vector Storage Engine (integrated)
          ↓
   WAL + Memory-Mapped Segments
   ```

### Future Modularization Path

**If we succeed and want to extract later:**

1. **Clean interfaces already** - Design with extraction in mind
   ```mojo
   trait StorageEngine:
       fn save_vector(...)
       fn load_vector(...)
       fn save_graph_node(...)  # Vector-specific but clean
   ```

2. **Version 2.0 consideration** - After understanding patterns
3. **Community contribution** - If others want general storage

## 🏗️ Current Storage Architecture

### Components That Stay Integrated

```mojo
struct VectorStorageEngine:
    # Core Components (tightly integrated)
    var wal: WriteAheadLog           # Durability
    var buffer: VectorBuffer         # Write optimization
    var segments: List[VectorSegment] # Memory-mapped data
    var graph_storage: GraphStorage   # DiskANN index
    
    # Vector-Specific Optimizations
    fn batch_insert(vectors: List[Vector]):
        # Optimized for vector batches
        # SIMD-aligned writes
        # Graph update coordination
    
    fn similarity_scan(query: Vector, k: Int):
        # Storage-aware search
        # Graph traversal with vector fetches
        # Locality optimizations
```

### What Could Be Modular (But Isn't Yet)

```mojo
# These could be separate modules within OmenDB:
- Distance functions (already somewhat modular)
- SIMD operations (could be mojo-simd lib)
- Compression algorithms (quantization)
```

## 📋 Implementation Plan

### Phase 1: Integrated Development (Current)
- Build storage engine within OmenDB
- Optimize specifically for vectors
- No abstraction overhead
- Fast iteration

### Phase 2: Clean Interfaces (Next)
- Define clear internal interfaces
- Separate concerns within codebase
- Prepare for potential extraction

### Phase 3: Evaluate Extraction (Post v1.0)
- If successful, consider extraction
- If community wants it
- If we have bandwidth

## 🎨 Design Principles for Storage

### Vector-First Design
```mojo
# Everything optimized for vectors:
- Page size = multiple of vector size
- Compression = dimension-aware
- Indices = similarity-optimized
- Caching = vector-granular
```

### Enterprise Features
```mojo
# What we DO implement:
- WAL for durability
- Memory-mapped segments
- Concurrent reads
- Fast recovery
- Compression

# What we DON'T implement:
- Transactions (not needed)
- SQL (wrong abstraction)
- Schemas (fixed dimension)
- Multi-table (single-purpose)
```

## 🚀 Benefits of This Approach

1. **Faster Time to Market**
   - No abstraction design paralysis
   - Direct optimization possible
   - Single codebase to manage

2. **Better Performance**
   - Vector-specific optimizations
   - No generalization overhead
   - Tight algorithm integration

3. **Clearer Value Proposition**
   - "Purpose-built for vectors"
   - Not another general database
   - Optimized for AI/ML workloads

4. **Future Flexibility**
   - Can extract if needed
   - Clean interfaces enable this
   - Not locked in

## 📊 Comparison with Competitors

| Database | Storage Approach | Result |
|----------|-----------------|--------|
| Pinecone | Proprietary, vector-specific | Best performance |
| Weaviate | LSM-based, adapted for vectors | Good balance |
| Qdrant | Custom, vector-optimized | Excellent performance |
| ChromaDB | SQLite for metadata, custom for vectors | Simple but limited |
| **OmenDB** | **Integrated, vector-optimized** | **Best of both worlds** |

## ✅ Decision Summary

**Keep storage engine integrated and vector-optimized because:**
1. Solo developer bandwidth is limited
2. Vector-specific optimizations are critical  
3. Can achieve better performance this way
4. Can always extract later if needed
5. Competitors with best performance do the same

**Design with clean interfaces** to enable future extraction if needed, but don't pay the abstraction cost now.

**Focus on building the best vector database**, not the most modular one. Performance and correctness over architectural purity.

## 🔄 Review Triggers

Re-evaluate this decision if:
- We have multiple developers
- Community wants general storage
- We hit performance limits
- Clear use cases for general storage emerge
- We achieve product-market fit and have bandwidth

Until then: **Integrated, optimized, focused.**