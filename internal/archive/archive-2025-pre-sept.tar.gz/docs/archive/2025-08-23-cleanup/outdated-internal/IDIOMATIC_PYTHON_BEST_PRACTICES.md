# Idiomatic Python Project Best Practices

**For OmenDB and similar Python projects**

## 📁 Directory Structure

### ✅ Do This (Idiomatic)
```
project/
├── src/project/         # OR just project/ (source code)
├── tests/               # All tests (not "test")
├── docs/                # Documentation
├── examples/            # User examples only
├── scripts/             # Build/release scripts
├── tools/               # Dev tools (optional)
└── ci/                  # CI-specific files
```

### ❌ Don't Do This
```
project/
├── test/                # Should be "tests"
├── benchmarks/          # Should be under tests/
├── profiling/           # Should be under tools/ or tests/
├── debug_*.py           # Should be in tools/ or tests/
├── test_*.py in root    # Should be in tests/
└── mixed content dirs   # Keep directories focused
```

## 🧪 Test Organization

### Standard Structure
```
tests/
├── __init__.py          # Makes it a package
├── conftest.py          # pytest configuration
├── unit/                # Fast, isolated tests
│   ├── test_api.py
│   └── test_core.py
├── integration/         # Slower, system tests
│   ├── test_e2e.py
│   └── test_persistence.py
├── benchmarks/          # Performance tests
│   ├── test_insertion.py
│   └── test_query.py
└── fixtures/            # Shared test data
    └── sample_data.py
```

### Naming Conventions
- Test files: `test_*.py` or `*_test.py`
- Test classes: `TestClassName`
- Test methods: `test_method_name`
- Fixtures: descriptive names in `conftest.py`

## 📦 Package Structure

### For Libraries
```
omendb/
├── omendb/              # Package directory
│   ├── __init__.py      # Package initialization
│   ├── api.py           # Public API
│   ├── core/            # Internal modules
│   │   ├── __init__.py
│   │   └── engine.py
│   └── utils/           # Utilities
│       ├── __init__.py
│       └── helpers.py
├── tests/               # Tests outside package
├── pyproject.toml       # Modern config (PEP 517)
└── README.md
```

### For Applications
```
app/
├── src/                 # Source code
│   └── app/
│       ├── __main__.py  # Entry point
│       └── main.py
├── tests/
├── requirements.txt     # Or pyproject.toml
└── README.md
```

## 📊 Benchmarks & Profiling

### Where They Belong
- **Benchmarks**: `tests/benchmarks/` (they're a type of test)
- **Profiling tools**: `tools/profiling/` or `tests/profiling/`
- **NOT** in root directory
- **NOT** in separate top-level directories

### Organization
```
tests/benchmarks/
├── __init__.py
├── conftest.py          # Benchmark fixtures
├── test_performance.py  # Main benchmarks
└── competitive/         # vs other solutions
    ├── test_vs_x.py
    └── test_vs_y.py
```

## 📚 Examples

### Good Examples Directory
```
examples/
├── README.md            # Index of examples
├── quickstart.py        # Simple, runnable
├── advanced_usage.py    # More complex
└── integrations/        # Framework-specific
    └── django_example.py
```

### Rules for Examples
1. **User-facing only** - not for testing
2. **Self-contained** - run without setup
3. **Well-commented** - educational purpose
4. **No test files** - those go in tests/

## 🛠️ Scripts vs Tools

### Scripts Directory
For **essential** scripts only:
```
scripts/
├── build.sh            # Build the project
├── release.py          # Release automation
└── setup_dev.sh        # Dev environment
```

### Tools Directory
For **development** utilities:
```
tools/
├── profiling/          # Performance analysis
├── analysis/           # Code analysis
├── benchmarking/       # Benchmark runners
└── debugging/          # Debug utilities
```

## 📝 Configuration Files

### Root Level Files
Keep these at root:
- `pyproject.toml` - Modern Python config
- `setup.py` - If still needed
- `setup.cfg` - If still needed
- `requirements.txt` - Dependencies
- `.gitignore` - Git ignore rules
- `README.md` - Project description
- `LICENSE` - License file
- `CHANGELOG.md` - Version history

### Don't Put at Root
- Test files (`test_*.py`)
- Debug scripts (`debug_*.py`)
- Benchmark results (`*.json`)
- Temporary files

## 🏷️ Naming Conventions

### Files
- **Modules**: `lowercase_with_underscores.py`
- **Tests**: `test_*.py` or `*_test.py`
- **Scripts**: `action_noun.py` (e.g., `run_tests.py`)

### Directories
- **Packages**: `lowercase` (no underscores)
- **Non-packages**: `lowercase_with_underscores`

## ✅ Benefits of Idiomatic Structure

1. **Discoverability**: Developers know where to look
2. **Tool Support**: IDEs and tools expect standard layout
3. **CI/CD**: Test runners find tests automatically
4. **Onboarding**: New contributors understand quickly
5. **Maintenance**: Clear where new code belongs

## 🚀 Migration Checklist

When reorganizing an existing project:

- [ ] Rename `test/` to `tests/`
- [ ] Move benchmarks to `tests/benchmarks/`
- [ ] Move profiling to `tools/` or `tests/`
- [ ] Clean root directory of test files
- [ ] Add `__init__.py` to test directories
- [ ] Create `conftest.py` for pytest
- [ ] Update `.gitignore`
- [ ] Update CI/CD paths
- [ ] Update documentation
- [ ] Run full test suite

## 📖 References

- [PEP 8](https://pep8.org/) - Python style guide
- [pytest Good Practices](https://docs.pytest.org/en/stable/explanation/goodpractices.html)
- [Python Packaging Guide](https://packaging.python.org/)
- [Hitchhiker's Guide](https://docs.python-guide.org/writing/structure/)

---

**Remember**: Consistency is more important than perfection. Pick a structure and stick to it!