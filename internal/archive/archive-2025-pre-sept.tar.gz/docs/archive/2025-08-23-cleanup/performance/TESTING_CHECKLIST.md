# Performance Optimization Testing Checklist

**Goal**: Safely enable optimizations with comprehensive verification  
**Strategy**: Enable one optimization at a time, verify, then combine

## 🧪 Test Files to Create

### FFI Optimization Tests
```bash
# Location: /Users/nick/github/omendb/omendb/test/performance/
test_ffi_numpy_formats.py       # All numpy array types
test_ffi_zero_copy_verify.py    # Memory address verification
test_ffi_performance.py         # 20%+ improvement verification
test_ffi_error_handling.py      # Edge cases and error paths
```

### Parallel Processing Tests  
```bash
# Location: /Users/nick/github/omendb/omendb/test/concurrency/
test_thread_safety.py           # Concurrent batch operations
test_core_scaling.py            # Performance vs core count
test_memory_corruption.py       # Race condition detection
test_parallel_stress.py         # Long-running stability
```

### Integration Tests
```bash
# Location: /Users/nick/github/omendb/omendb/test/integration/
test_combined_optimizations.py  # Both enabled together
test_large_dataset_stability.py # 1M+ vectors
test_accuracy_regression.py     # Ensure 100% accuracy maintained
```

## ✅ FFI Optimization Testing Protocol

### Step 1: Enable FFI Optimization
```bash
# Edit native.mojo
var __use_optimized_ffi: Bool = True  # Change from False
```

### Step 2: Comprehensive Format Testing
```python
#!/usr/bin/env python3
# test_ffi_numpy_formats.py

import numpy as np
import omendb

def test_all_numpy_formats():
    """Test all numpy array formats for compatibility."""
    formats = [
        # Standard cases  
        {"dtype": np.float32, "order": "C", "readonly": False},
        {"dtype": np.float64, "order": "C", "readonly": False},
        
        # Memory layout variants
        {"dtype": np.float32, "order": "F", "readonly": False},  # Fortran order
        
        # Edge cases
        {"dtype": np.float32, "order": "C", "readonly": True},   # Read-only
        {"dtype": np.int32, "order": "C", "readonly": False},   # Wrong type
    ]
    
    for fmt in formats:
        vectors = np.random.randn(100, 128).astype(fmt["dtype"], order=fmt["order"])
        if fmt["readonly"]:
            vectors.flags.writeable = False
            
        db = omendb.DB()
        db.clear()
        
        try:
            result = db.add_batch(vectors, [f"id_{i}" for i in range(100)])
            print(f"✅ {fmt}: Success ({len(result)} vectors)")
        except Exception as e:
            print(f"⚠️  {fmt}: {e}")

if __name__ == "__main__":
    test_all_numpy_formats()
```

### Step 3: Zero-Copy Verification
```python
#!/usr/bin/env python3
# test_ffi_zero_copy_verify.py

import numpy as np
import omendb

def verify_zero_copy():
    """Verify that numpy arrays are accessed without copying."""
    
    # Create array with known memory address
    vectors = np.random.randn(1000, 128).astype(np.float32)
    original_address = vectors.__array_interface__["data"][0]
    
    print(f"Original array address: 0x{original_address:x}")
    
    # Monitor memory usage
    import psutil
    process = psutil.Process()
    mem_before = process.memory_info().rss / 1024 / 1024  # MB
    
    db = omendb.DB()
    db.clear()
    result = db.add_batch(vectors, [f"id_{i}" for i in range(1000)])
    
    mem_after = process.memory_info().rss / 1024 / 1024  # MB
    mem_increase = mem_after - mem_before
    
    print(f"Memory before: {mem_before:.1f} MB")  
    print(f"Memory after: {mem_after:.1f} MB")
    print(f"Memory increase: {mem_increase:.1f} MB")
    
    # Zero-copy should have minimal memory increase
    # Array is ~500KB, so <1MB increase expected
    if mem_increase < 1.0:
        print("✅ Zero-copy verified (minimal memory increase)")
    else:
        print(f"❌ Possible memory copy detected ({mem_increase:.1f}MB increase)")

if __name__ == "__main__":
    verify_zero_copy()
```

## ✅ Parallel Processing Testing Protocol

### Step 1: Thread Safety Verification
```bash
# Enable ThreadSanitizer during build
export TSAN_OPTIONS="halt_on_error=1:abort_on_error=1:report_bugs=1"

# Rebuild with thread safety checking
pixi run mojo build omendb/native.mojo -o python/omendb/native.so --emit shared-lib

# Run concurrent test
python test/concurrency/test_thread_safety.py
```

### Step 2: Core Scaling Analysis  
```python
#!/usr/bin/env python3
# test_core_scaling.py

import time
import numpy as np
import omendb
from concurrent.futures import ThreadPoolExecutor

def test_core_scaling():
    """Test performance scaling with different core counts."""
    
    # Large batch to see parallel benefits
    vectors = np.random.randn(10000, 128).astype(np.float32)
    ids = [f"id_{i}" for i in range(10000)]
    
    # Test different thread scenarios
    for num_workers in [1, 2, 4, 8, 16]:
        db = omendb.DB()
        db.clear()
        
        # Split batch across workers
        chunk_size = len(vectors) // num_workers
        chunks = [
            (vectors[i:i+chunk_size], ids[i:i+chunk_size]) 
            for i in range(0, len(vectors), chunk_size)
        ]
        
        start_time = time.perf_counter()
        
        if num_workers == 1:
            # Single-threaded baseline
            db.add_batch(vectors, ids)
        else:
            # Multi-threaded
            def add_chunk(chunk):
                chunk_vectors, chunk_ids = chunk
                return db.add_batch(chunk_vectors, chunk_ids)
            
            with ThreadPoolExecutor(max_workers=num_workers) as executor:
                results = list(executor.map(add_chunk, chunks))
        
        elapsed = time.perf_counter() - start_time
        throughput = len(vectors) / elapsed
        
        print(f"Workers: {num_workers:2d}, Time: {elapsed:.2f}s, Throughput: {throughput:.0f} vec/s")

if __name__ == "__main__":
    test_core_scaling()
```

## 📊 Performance Regression Detection

### Automated Benchmark Comparison
```python
#!/usr/bin/env python3  
# test_performance_regression.py

import time
import numpy as np
import omendb

def benchmark_configuration(config_name, use_optimized_ffi=False, use_parallel=False):
    """Benchmark a specific configuration."""
    
    # Configure optimizations (would need native module support)
    # For now, measure current performance
    
    db = omendb.DB()
    db.clear()
    
    # Standard test vectors
    vectors = np.random.randn(5000, 128).astype(np.float32) 
    ids = [f"id_{i}" for i in range(5000)]
    
    # Measure batch add performance
    start = time.perf_counter()
    db.add_batch(vectors, ids)
    batch_time = time.perf_counter() - start
    batch_throughput = len(vectors) / batch_time
    
    # Measure search performance
    queries = vectors[:100]
    start = time.perf_counter()
    for query in queries:
        results = db.search(query, 10)
    search_time = time.perf_counter() - start
    search_throughput = 100 / search_time
    
    # Measure accuracy
    correct = 0
    for i in range(100):
        results = db.search(vectors[i], 1)
        if results and results[0].id == ids[i]:
            correct += 1
    
    accuracy = correct / 100.0
    
    return {
        "config": config_name,
        "batch_throughput": batch_throughput,
        "search_throughput": search_throughput,
        "accuracy": accuracy
    }

# Baseline measurements for comparison
BASELINE = {
    "batch_throughput": 84305,  # Current performance
    "search_throughput": 1375,
    "accuracy": 1.0
}

def check_regression(results):
    """Check for performance regression."""
    issues = []
    
    if results["batch_throughput"] < BASELINE["batch_throughput"] * 0.95:  # 5% tolerance
        issues.append(f"Batch throughput regression: {results['batch_throughput']:.0f} < {BASELINE['batch_throughput']:.0f}")
    
    if results["search_throughput"] < BASELINE["search_throughput"] * 0.95:
        issues.append(f"Search throughput regression: {results['search_throughput']:.0f} < {BASELINE['search_throughput']:.0f}")
    
    if results["accuracy"] < 0.99:
        issues.append(f"Accuracy regression: {results['accuracy']:.2f} < 0.99")
    
    return issues

if __name__ == "__main__":
    # Test current configuration
    current = benchmark_configuration("current")
    print(f"Current performance: {current}")
    
    issues = check_regression(current)
    if issues:
        print("❌ Regressions detected:")
        for issue in issues:
            print(f"  - {issue}")
    else:
        print("✅ No performance regressions")
```

## 🎯 Success Criteria

### FFI Optimization
- [ ] All numpy formats handled correctly
- [ ] Zero-copy verified (memory usage <1MB increase)  
- [ ] 20%+ performance improvement on batch operations
- [ ] No accuracy regression
- [ ] Graceful fallback on conversion errors

### Parallel Processing  
- [ ] ThreadSanitizer reports no data races
- [ ] 2x+ speedup on 4+ core systems
- [ ] Graceful degradation on single-core systems
- [ ] No memory corruption under concurrent load
- [ ] 100% accuracy maintained

### Combined Optimizations
- [ ] Both can be enabled simultaneously
- [ ] Expected 5-7x total performance improvement achieved
- [ ] No stability issues under extended load
- [ ] All edge cases handled correctly

This testing protocol ensures we can safely enable optimizations with confidence in stability and performance.