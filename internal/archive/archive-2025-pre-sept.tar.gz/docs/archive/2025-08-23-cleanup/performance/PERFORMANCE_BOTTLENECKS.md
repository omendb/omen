# OmenDB Performance Bottlenecks - Internal Technical Analysis

**Date**: December 2024  
**Current Performance**: 3.1K → 24K vec/s (with auto-batching)

## Measured Bottlenecks (Not Speculation)

### 1. Python-Mojo FFI Boundary (PRIMARY - 79% of time)

**Measured Cost**: 0.298ms per native call
- Fixed overhead: ~0.05ms (system/marshaling)
- Vector processing: 0.248ms @ 128D

**Evidence**:
```
Dim   1:  27,643 vec/s (0.036ms) - minimal vector overhead
Dim 128:   3,044 vec/s (0.329ms) - typical workload
Dim 256:   1,653 vec/s (0.605ms) - scales linearly
```

**Reliable Fix**: Batch operations (proven 8.8x speedup)

### 2. Vector Processing (SECONDARY - O(dimension))

**Measured Scaling**:
- 128D: 0.284ms processing time
- 256D: 0.616ms processing time
- **Linear scaling**: 2.2μs per dimension

**Location**: `omendb/algorithms/diskann.mojo:_cosine_distance()`

**Reliable Fix**: SIMD vectorization (not yet implemented)

### 3. Buffer Flush Operations (TERTIARY)

**Observed Gap**:
- Pure batch: 26,451 vec/s
- Auto-batch: 24,029 vec/s
- **Difference**: 2,422 vec/s (9% overhead)

**Location**: `_flush_buffer_to_main()` in `native.mojo:397-436`

**Components**:
1. DiskANN.build() from buffer data
2. Segment merging (currently replaces)
3. ID mapping updates

## Profiling Targets

### Must Profile (High Impact)

1. **FFI Serialization**
   - Python list → Mojo List[Float32] conversion
   - Memory allocation per vector
   - String ID handling

2. **DiskANN.build() Performance**
   - Graph construction time vs vector count
   - Memory allocation patterns
   - Edge pruning overhead

3. **Distance Calculations**
   - Current: No SIMD (scalar loops)
   - Measure: Time per distance calculation
   - Compare: numpy.dot() vs our implementation

### Nice to Profile (Lower Impact)

4. **Memory Allocation**
   - No pooling currently
   - Allocates per operation
   - GC pressure unknown

5. **Metadata Operations**
   - Dictionary lookups
   - String operations
   - JSON serialization

## Reliable Performance Improvements

### 1. Larger Batch Sizes (PROVEN)
**Current**: Optimal at 500 vectors
**Test**: 1000, 2000, 5000 vectors
**Expected**: 10-20% additional improvement

### 2. SIMD Distance Calculations
**Current**: Scalar loop in Mojo
**Implement**: `@vectorize` with SIMD width
**Expected**: 2-4x faster distance calculations

### 3. Zero-Copy Buffer Operations
**Current**: Copy from SimpleBuffer to DiskANN
**Implement**: Direct pointer passing
**Expected**: 5-10% improvement on flush

### 4. Pre-allocated Memory Pools
**Current**: Allocate per vector
**Implement**: Pool of pre-allocated buffers
**Expected**: 10-15% reduction in overhead

## Profiling Code Needed

### 1. FFI Breakdown
```python
# Profile individual components:
- Python list creation time
- Native call overhead
- Result unmarshaling
```

### 2. Flush Timing
```python
# Measure:
- Buffer accumulation time
- DiskANN.build() time
- Segment merge time
- Total flush duration
```

### 3. Distance Calculation
```mojo
# Benchmark:
- Scalar implementation (current)
- SIMD implementation (proposed)
- Batch distance calculations
```

## Next Steps (Prioritized)

1. **Write flush profiling code** - Understand the 9% gap
2. **Implement SIMD distances** - Should be 2-4x faster
3. **Test larger batches** - Easy win, no code changes
4. **Memory pool prototype** - More complex, defer

## Key Insights

- **Batching works** - 8.8x proven speedup
- **FFI dominates** - Must batch to amortize
- **Linear scaling** - O(dimension) is fundamental
- **Architecture correct** - Implementation needs optimization

## DO NOT PURSUE

❌ Algorithm changes (DiskANN works, 97% accuracy)
❌ New features (performance is priority)
❌ Micro-optimizations (<5% impact)
❌ Speculation without measurement

---

*"Measure twice, optimize once"*