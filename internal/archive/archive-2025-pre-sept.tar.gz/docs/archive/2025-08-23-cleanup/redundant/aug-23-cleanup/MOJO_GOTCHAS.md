# Mojo Common Gotchas and Solutions
*Last Updated: August 23, 2025*

## Type Conversions (Most Common Errors)

### ❌ WRONG - Python-style conversions
```mojo
# These will cause compilation errors!
var my_int = int(some_value)        # ERROR: use of unknown declaration 'int'
var my_str = str(some_value)        # ERROR: use of unknown declaration 'str'
var my_float = float(some_value)    # ERROR: use of unknown declaration 'float'
```

### ✅ CORRECT - Mojo-style conversions
```mojo
# Use capital constructors
var my_int = Int(some_value)        # Correct
var my_str = String(some_value)     # Correct
var my_float = Float32(some_value)  # Correct (or Float64)

# From PythonObject
var py_int = Int(python_obj)
var py_str = String(python.str(python_obj))
var py_float = Float64(python.float(python_obj))
```

## Float32 vs Float64 Issues

### ❌ WRONG - Type mismatch
```mojo
var vector = List[Float32]()
var py_val = python.float(something)  # Returns Float64
vector.append(py_val)  # ERROR: cannot convert Float64 to Float32
```

### ✅ CORRECT - Explicit conversion
```mojo
var vector = List[Float32]()
var py_val = python.float(something)
var float64_val = Float64(py_val)
vector.append(Float32(float64_val))  # Explicit conversion
```

## Print Statement Gotchas

### ❌ WRONG - Mixed types
```mojo
var count = 10
print("Count:", count)  # ERROR: could not deduce parameter 'Ts'
```

### ✅ CORRECT - String concatenation
```mojo
var count = 10
print("Count: " + String(count))  # Convert to string first
```

## Tuple Access

### ❌ WRONG - Method-style access
```mojo
var my_tuple = (id_str, vector, metadata)
var id = my_tuple.get[0, String]()  # ERROR: no attribute 'get'
```

### ✅ CORRECT - Index access
```mojo
var my_tuple = (id_str, vector, metadata)
var id = my_tuple[0]  # Direct index access
```

## Exception Handling

### ❌ WRONG - Python-style
```mojo
except e:
    print("Error:", str(e))  # ERROR: unknown declaration 'str'
```

### ✅ CORRECT - Mojo-style
```mojo
except e:
    print("Error: " + String(e))
```

## Range Issues

### ❌ WRONG - Untyped range
```mojo
var num_vectors = int(some_value)  # Wrong conversion
for i in range(num_vectors):  # ERROR: failed to infer parameter
```

### ✅ CORRECT - Properly typed
```mojo
var num_vectors = Int(some_value)  # Correct conversion
for i in range(num_vectors):  # Works!
```

## UUID Generation

### ❌ WRONG - No built-in UUID
```mojo
var id = generate_uuid()  # ERROR: unknown declaration
```

### ✅ CORRECT - Use Python's uuid
```mojo
var uuid_module = Python.import_module("uuid")
var id_str = String(python.str(uuid_module.uuid4()))
```

## Memory and Pointers

### ❌ WRONG - Can't create pointer from address
```mojo
var address = 0x600000ab8040
var ptr = UnsafePointer[Float32]._from_address(address)  # Doesn't exist
```

### ✅ CORRECT - Workarounds
```mojo
# Option 1: Use PyCapsule from Python
# Option 2: Pass buffer directly from Python
# Option 3: Use shared memory mechanisms
```

## Common Patterns to Remember

1. **Always use capital constructors**: `Int()`, `String()`, `Float32()`, `Float64()`
2. **Explicit float conversions**: Python returns Float64, vectors usually need Float32
3. **String concatenation for print**: Convert all values to String first
4. **Import Python modules**: Use `Python.import_module()` for Python functionality
5. **Check Mojo limitations**: Not all Python patterns have direct Mojo equivalents

## Quick Reference Table

| Python | Mojo | Notes |
|--------|------|-------|
| `int()` | `Int()` | Capital I |
| `str()` | `String()` | Full name |
| `float()` | `Float32()` or `Float64()` | Specify precision |
| `print(x, y)` | `print(String(x) + " " + String(y))` | Concatenate strings |
| `except e:` | `except e:` | Same syntax |
| `str(e)` | `String(e)` | In exception handling |
| `uuid.uuid4()` | `String(python.str(uuid_module.uuid4()))` | Via Python module |

## Global State Issues (CRITICAL for Testing)

### ❌ WRONG - Tests failing due to shared global state
```python
# This pattern causes test contamination:
def test_empty_database():
    db = omendb.DB()  # Creates new DB instance
    results = db.search(query, limit=10)
    assert len(results) == 0  # FAILS: gets results from previous tests!

def test_auto_batching():  
    db = omendb.DB()  # "New" DB instance
    # Add 5 vectors...
    assert db.count() == 5  # FAILS: gets 1123 (accumulates from all tests!)
```

### ✅ CORRECT - Reset global state between tests
```python
import omendb.native as native

def test_empty_database():
    native.clear_database()  # Clear global state first
    db = omendb.DB()
    results = db.search(query, limit=10) 
    assert len(results) == 0  # Now passes!
```

### Root Cause
**FFI Layer Global Store**: All `omendb.DB()` instances share the same underlying global `__global_store` in `ffi_exports.mojo:15`. Creating a "new" database just overwrites the pointer but retains all previous vectors.

**Impact**: Tests fail unpredictably because:
- "Empty" databases contain vectors from previous tests
- Vector counts accumulate across test runs  
- Search results include vectors that shouldn't exist

**Solution**: Always reset global state between tests or use proper instance isolation.

## When You Hit These Errors

If you see these compilation errors, check this file first:
- `use of unknown declaration 'int'` → Use `Int()`
- `use of unknown declaration 'str'` → Use `String()`
- `could not deduce parameter 'Ts'` → Convert to String for print
- `cannot convert Float64 to Float32` → Explicit conversion needed
- `no attribute 'get'` → Use index access for tuples