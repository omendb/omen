# Documentation Structure for AI Agents
*Optimized for minimal context usage and maximum clarity*

## Essential Files Only (For AI Agents)

### Core Navigation (Always Include)
1. **`CLAUDE.md`** - Entry point with navigation map (50 lines)
2. **`STATUS.md`** - Current state and active work (85 lines)

### Task-Specific Includes
**For Performance Work:**
- `docs/PERFORMANCE_ROADMAP.md` - 4-phase optimization plan
- `docs/TODO.md` - Specific action items

**For Architecture Questions:**
- `docs/TECH_SPEC.md` - Technical specification

**For Competitive Analysis:**
- `docs/COMPETITIVE_ANALYSIS.md` - Why competitors are faster

## Why This Structure Works

### Token Efficiency
- **5 core files** instead of 102
- **~500 total lines** for complete context
- **No redundancy** - each file has unique purpose
- **Clear hierarchy** - know exactly what to include

### Navigation Pattern
```
CLAUDE.md (start here)
  ├→ STATUS.md (current state)
  ├→ docs/TODO.md (action items)
  └→ docs/PERFORMANCE_ROADMAP.md (optimization guide)
```

### What We Archived
- 60+ outdated optimization reports
- Multiple conflicting architecture docs
- Historical implementation summaries
- Old roadmaps and plans

## Best Practices for AI Agents

### 1. Start Minimal
```python
# Always include
@CLAUDE.md
@STATUS.md

# Add based on task
@docs/PERFORMANCE_ROADMAP.md  # For optimization
@docs/TECH_SPEC.md            # For architecture
```

### 2. Use File References
Instead of copying content, reference specific sections:
- `native.mojo:2009-2038` - FFI bottleneck
- `native.mojo:595-640` - Deferred indexing

### 3. Avoid These Files
- Anything in `docs/archive/` - outdated
- `docs/internal/` subdirectories - too detailed
- Historical reports - no longer accurate

## Quick Reference

| Task | Include These Files |
|------|-------------------|
| Performance optimization | CLAUDE.md, STATUS.md, PERFORMANCE_ROADMAP.md |
| Bug fixing | CLAUDE.md, STATUS.md, TODO.md |
| Architecture review | CLAUDE.md, TECH_SPEC.md |
| Competitive analysis | CLAUDE.md, COMPETITIVE_ANALYSIS.md |
| General work | CLAUDE.md, STATUS.md |

## File Sizes (for context planning)

```
CLAUDE.md              - 50 lines  (2KB)
STATUS.md              - 85 lines  (3KB)
docs/TODO.md           - 150 lines (4KB)
docs/TECH_SPEC.md      - 245 lines (8KB)
docs/PERFORMANCE_ROADMAP.md - 200 lines (7KB)
---
Total for all core:    ~730 lines (24KB)
```

## Update Frequency

- **STATUS.md** - Update after each session
- **TODO.md** - Update as tasks complete
- **CLAUDE.md** - Update only if structure changes
- **Others** - Update only when architecture changes