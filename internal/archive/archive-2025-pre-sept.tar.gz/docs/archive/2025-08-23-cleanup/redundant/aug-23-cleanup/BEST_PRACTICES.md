# OmenDB Best Practices Guide
*Based on Modular/Mojo standards and competitor analysis*  
*Last Updated: August 23, 2025*

## Mojo Performance Best Practices

### 1. Memory Management (From Modular MAX Kernels)

```mojo
# ✅ GOOD: Pre-allocate and reuse memory
var buffer = UnsafePointer[Float32].alloc(batch_size * dimension)
# ... use buffer ...
buffer.free()

# ❌ BAD: Allocate in hot loop
for i in range(batch_size):
    var vec = List[Float32]()  # Allocation every iteration!
```

### 2. SIMD Vectorization (From MAX Kernels)

```mojo
# ✅ GOOD: Use SIMD for distance calculations
@always_inline
fn distance_simd[width: Int = 8](
    a: UnsafePointer[Float32], 
    b: UnsafePointer[Float32], 
    dim: Int
) -> Float32:
    var sum = SIMD[DType.float32, width](0)
    
    @parameter
    for i in range(0, dim, width):
        var va = (a + i).load[width=width]()
        var vb = (b + i).load[width=width]()
        var diff = va - vb
        sum += diff * diff
    
    return sum.reduce_add().sqrt()

# ❌ BAD: Scalar operations
fn distance_slow(a: List[Float32], b: List[Float32]) -> Float32:
    var sum: Float32 = 0
    for i in range(len(a)):
        var diff = a[i] - b[i]
        sum += diff * diff
    return sqrt(sum)
```

### 3. FFI Optimization (Critical for OmenDB)

```mojo
# ✅ GOOD: Bulk operations with memcpy
fn add_numpy_batch_fast(
    numpy_ptr: UnsafePointer[Float32],
    count: Int,
    dim: Int
) -> None:
    var total_size = count * dim * sizeof[Float32]()
    memcpy(self.storage, numpy_ptr, total_size)

# ❌ BAD: Element-by-element conversion
fn add_numpy_batch_slow(vectors: PythonObject) -> None:
    for i in range(len(vectors)):
        for j in range(len(vectors[i])):
            self.storage[i][j] = Float32(vectors[i][j])
```

### 4. Alignment and Cache Optimization

```mojo
# ✅ GOOD: Aligned allocation for SIMD
@always_inline
fn allocate_aligned[T: DType, alignment: Int = 32](
    size: Int
) -> UnsafePointer[Scalar[T]]:
    # Ensure alignment for AVX2/AVX512
    var ptr = UnsafePointer[Scalar[T]].aligned_alloc(alignment, size)
    return ptr

# ✅ GOOD: Structure-of-Arrays for cache efficiency
struct VectorStorageSOA:
    var x_coords: UnsafePointer[Float32]  # All X values contiguous
    var y_coords: UnsafePointer[Float32]  # All Y values contiguous
    # Better cache utilization for component-wise operations
```

## Competitor Architecture Patterns

### 1. Deferred Indexing (Qdrant/Weaviate Pattern)

```mojo
# ✅ GOOD: Buffer writes, build index periodically
struct OptimizedStore:
    var buffer: VectorBuffer          # Fast writes go here
    var index: DiskANNIndex           # Built periodically
    var buffer_threshold: Int = 10000
    
    fn add_batch(self, vectors: List[List[Float32]]) -> None:
        self.buffer.append(vectors)
        
        if self.buffer.size >= self.buffer_threshold:
            self.build_index_from_buffer()
```

### 2. Segment Architecture (LanceDB/Qdrant)

```mojo
# ✅ GOOD: Multiple segments for scalability
struct SegmentedStore:
    var active_segment: Segment       # Current writes
    var sealed_segments: List[Segment] # Read-only, optimized
    var segment_size: Int = 100000
    
    fn search(self, query: List[Float32], k: Int) -> Results:
        # Search all segments in parallel
        var results = parallel_map(
            self.sealed_segments,
            lambda seg: seg.search(query, k)
        )
        return merge_results(results)
```

### 3. Memory-Mapped Storage (LanceDB Pattern)

```mojo
# ✅ GOOD: Zero-copy persistence
struct MmapStorage:
    var mmap_ptr: UnsafePointer[UInt8]
    var file_size: Int
    
    fn get_vector(self, idx: Int) -> UnsafePointer[Float32]:
        # Direct pointer into mmap'd file - no copy!
        var offset = idx * self.dimension * sizeof[Float32]()
        return self.mmap_ptr.offset(offset).bitcast[Float32]()
```

## Code Quality Standards

### 1. Error Handling

```mojo
# ✅ GOOD: Explicit error handling
fn add_vector(self, vector: List[Float32]) raises -> String:
    if len(vector) != self.dimension:
        raise Error("Dimension mismatch: expected " + 
                   str(self.dimension) + " got " + str(len(vector)))
    # ... rest of implementation
    return vector_id

# ❌ BAD: Silent failures
fn add_vector_bad(self, vector: List[Float32]) -> Bool:
    if len(vector) != self.dimension:
        return False  # Caller doesn't know why it failed
```

### 2. Documentation

```mojo
# ✅ GOOD: Clear docstrings (Modular style)
fn add_batch(
    self,
    vectors: List[List[Float32]],
    ids: Optional[List[String]] = None
) raises -> List[String]:
    """Add multiple vectors to the index.
    
    Args:
        vectors: 2D list of vectors to add.
        ids: Optional vector IDs. Generated if not provided.
        
    Returns:
        List of IDs for the added vectors.
        
    Raises:
        Error: If dimensions don't match or batch is empty.
        
    Note:
        Uses deferred indexing for batches > 1000 vectors.
    """
```

### 3. Testing Patterns

```mojo
# ✅ GOOD: Comprehensive test with clear assertions
fn test_batch_performance() raises:
    """Test that batch operations are faster than single ops."""
    var db = VectorStore(dimension=128)
    var vectors = generate_random_vectors(1000, 128)
    
    # Test batch performance
    var start = now()
    db.add_batch(vectors)
    var batch_time = now() - start
    
    # Test single performance
    var db2 = VectorStore(dimension=128)
    start = now()
    for v in vectors:
        db2.add_single(v)
    var single_time = now() - start
    
    # Batch MUST be faster
    assert_true(batch_time < single_time * 0.5,
                "Batch should be >2x faster than single ops")
```

## Performance Testing Protocol

### 1. Always Test with Development Version

```bash
# ✅ GOOD: Use development version
PYTHONPATH=/Users/nick/github/omendb/omendb/python:$PYTHONPATH \
    python benchmark.py

# ❌ BAD: Test installed version (may be outdated)
python benchmark.py
```

### 2. Verify Real Implementation

```python
# ✅ GOOD: Verify batch is actually optimized
numpy_time = benchmark_numpy_batch(vectors)
list_time = benchmark_list_batch(vectors)

assert numpy_time < list_time * 0.5, "NumPy should use zero-copy!"
assert batch_time < single_time * 0.5, "Batch should be optimized!"
```

### 3. Profile Before Optimizing

```bash
# ✅ GOOD: Profile to find actual bottlenecks
py-spy record -o profile.svg -- python benchmark.py
# Analyze the flamegraph to see where time is spent
```

## Common Pitfalls to Avoid

### 1. Debug Output in Production

```mojo
# ❌ BAD: Print statements in hot path
fn add_vector(self, vector: List[Float32]) -> None:
    print("Adding vector:", vector[0], vector[1])  # KILLS PERFORMANCE!
    self.storage.append(vector)

# ✅ GOOD: Conditional debug output
@parameter
if debug_enabled:
    print_no_newline(".")  # Minimal overhead when needed
```

### 2. Fake Implementations

```mojo
# ❌ BAD: Batch that's not really batch
fn add_batch_fake(self, vectors: List[List[Float32]]) -> None:
    for v in vectors:
        self.add_single(v)  # No batch optimization!

# ✅ GOOD: Real batch optimization
fn add_batch_real(self, vectors: List[List[Float32]]) -> None:
    # Flatten all vectors into single allocation
    var flat = UnsafePointer[Float32].alloc(len(vectors) * self.dim)
    # Single memcpy or bulk operation
    # Build index once at end
```

### 3. Premature Abstractions

```mojo
# ❌ BAD: Over-engineered for current needs
trait StorageEngine:
    fn store() raises -> None
    fn retrieve() raises -> None
    # 20 more methods...

struct PostgresStorage(StorageEngine): ...
struct RedisStorage(StorageEngine): ...
struct S3Storage(StorageEngine): ...

# ✅ GOOD: Simple and working
struct VectorStorage:
    var data: UnsafePointer[Float32]
    fn store(self, vector: List[Float32]) -> None: ...
```

## Build and Development Workflow

### 1. Build Commands (Following Modular patterns)

```bash
# Build
pixi run mojo build omendb/native.mojo -o python/omendb/native.so --emit shared-lib

# Test
pixi run test

# Format
pixi run mojo format ./

# Benchmark
pixi run benchmark
```

### 2. Testing Strategy

```bash
# Unit tests (fast, focused)
pytest tests/unit/ -v

# Integration tests (end-to-end)
pytest tests/integration/ -v

# Performance regression tests
python test_performance_regression.py --baseline baseline.json
```

### 3. CI/CD Requirements

- All tests must pass
- No performance regressions > 5%
- Code formatted with `mojo format`
- No debug prints in production code
- Documentation updated for API changes

## References

- [Modular MAX Kernels](../external/modular/max/kernels/) - SIMD patterns
- [Mojo stdlib](../external/modular/mojo/stdlib/) - Memory management
- [DiskANN](../external/diskann/) - Graph index implementation
- [LanceDB](../external/lancedb/) - Columnar storage patterns
- [Qdrant Architecture](https://qdrant.tech/documentation/concepts/storage/) - Segment design