# Search Bug Investigation - Root Cause Found

*Date: August 23, 2025*  
*Status: Root cause identified, solution planned*

## 🎯 **Root Cause Identified**

**Two separate issues discovered:**

### **Issue 1: Auto-batching Confusion ✅ SOLVED**
- **Symptom**: `add()` returns `True` but `count()` shows 0
- **Cause**: Auto-batching is enabled by default - vectors go to `_pending_batch`, not database
- **Solution**: Call `flush()` after `add()` or disable auto-batching with `db._auto_batch_enabled = False`
- **Test Results**: After `flush()`, count correctly shows 1

### **Issue 2: Search Segmentation Fault ❌ CRITICAL**
- **Symptom**: Search crashes with segfault even when vectors exist (`count()` = 1)  
- **Location**: `api.py:807` → `_native.search_vectors()` → `get_global_db()[].search_with_metadata_filter()`
- **Cause**: Memory corruption in global database state
- **Evidence**: Known issue mentioned in code comments about "Collections corruption crash"

## 📊 **Test Results Summary**

### ✅ **What Works**
- **Batch operations**: `add_batch()` - 64K+ vec/s performance maintained
- **Individual add with flush**: Works after calling `db.flush()`  
- **Count after flush**: Correctly reports vector count
- **Database initialization**: Global database initializes properly

### ❌ **What's Broken**
- **Search functionality**: Segfaults in native code during search operations
- **Memory corruption**: Global database state becomes corrupted during search

## 🔍 **Technical Analysis**

### **Search Call Stack**
```
Python: db.search() 
  → api.py:807: _native.search_vectors()
  → native.mojo:1644: get_global_db()[].search_with_metadata_filter()
  → SEGFAULT in DiskANN search operations
```

### **Memory Corruption Evidence**
1. **Safety handling exists**: Code has try/catch for "Collections corruption crash"
2. **Inconsistent state**: Vectors can be added but not searched
3. **Global database issue**: Problem is with `get_global_db()` state management

### **Suspected Root Cause**
The global database (`VectorStore`) becomes corrupted when:
- Vectors are added via different code paths (individual vs batch)
- Index building happens asynchronously  
- Memory management between Python/Mojo FFI boundary has issues

## 🚨 **Priority Actions**

### **Immediate (High Priority)**
1. **Debug global database state**: Check if `VectorStore` is properly initialized
2. **Test search without metadata filter**: Try simpler search to isolate the issue
3. **Investigate index state**: Check if DiskANN index is corrupted during add operations
4. **Memory safety audit**: Review global variable management in native.mojo

### **Short-term Solutions**
1. **Workaround**: Implement search fallback that doesn't crash
2. **State validation**: Add debugging to check database state before search
3. **Memory isolation**: Ensure proper memory management between add/search operations

### **Long-term Fix**
1. **Architecture review**: Consider removing global state dependencies
2. **Thread safety**: Ensure all operations are thread-safe
3. **Error handling**: Improve crash recovery and state consistency

## 💡 **Key Insights**

1. **Performance is excellent**: 64K+ vec/s proves FFI optimization works
2. **Add operations work**: Both individual (with flush) and batch succeed  
3. **Search is architecture issue**: Not related to our recent SIMD optimization attempts
4. **Memory corruption**: Core issue is with global state management in Mojo

## 📝 **Next Investigation Steps**

1. **Test search immediately after batch add**: Does batch add leave database in better state?
2. **Simplify search call**: Bypass metadata filtering to isolate the crash
3. **Check index building**: Ensure DiskANN index is properly constructed
4. **Memory debugging**: Add debug prints to track global database state

## 🎯 **Success Criteria**

- **Phase 1**: Search returns results without crashing (any results, even wrong ones)
- **Phase 2**: Search returns correct results for exact matches
- **Phase 3**: Search accuracy matches expected behavior
- **Phase 4**: Re-implement SIMD optimizations with working search

**Bottom Line**: We have excellent performance (64K+ vec/s) but critical functionality bug in search. The auto-batching confusion was a red herring - the real issue is memory corruption in the global database during search operations.