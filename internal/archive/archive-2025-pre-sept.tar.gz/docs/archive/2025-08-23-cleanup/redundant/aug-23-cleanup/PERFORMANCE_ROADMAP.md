# OmenDB Performance Optimization Roadmap
*Last Updated: August 23, 2025*  
*Current Performance: 1,465 vec/s | Target: 20,000+ vec/s*

## Executive Summary

**Current State**: 13x slower than target due to FFI bottleneck  
**Primary Bottleneck**: 0.66ms per vector conversion (should be 0.05ms)  
**Solution**: 4-phase optimization plan prioritizing highest-impact fixes

## Performance Analysis

### Current Bottlenecks (Measured)
```
FFI Conversion:     0.66ms/vector  (13x too slow)
Memory Allocation:  0.15ms/vector  (3x too slow)  
Distance Calc:      0.08ms/vector  (1.6x too slow)
Graph Building:     0.12ms/vector  (2.4x too slow)
---
Total:             1.01ms/vector = 990 vec/s theoretical
Actual:            0.68ms/vector = 1,465 vec/s (with deferred indexing)
```

### Target Performance
```
Batch Insert:  20,000+ vec/s (0.05ms per vector)
Search:        <1ms for k=10 in 1M vectors
Memory:        <2GB for 1M 128d vectors
```

## 4-Phase Optimization Plan

### PHASE 1: FFI OPTIMIZATION ⚡ 
**Impact**: 13x speedup potential | **Timeline**: 1 week | **Target**: 5,000+ vec/s

#### Problem
- Element-by-element Python→Mojo conversion in hot path
- Fake zero-copy implementation (numpy = lists performance)
- Creating List[Float32] for every vector

#### Solution
```mojo
# Current (SLOW): Element-by-element
for j in range(vec_len):
    var elem = vector_list[j]  
    var float_val = Float64(python.float(elem))
    vector.append(Float32(float_val))

# Target (FAST): True zero-copy with buffer protocol
var numpy_ptr = numpy_array.__array_interface__["data"][0]
memcpy(dest_ptr, numpy_ptr, batch_size * dimension * 4)
```

#### Implementation Steps
1. Fix numpy buffer protocol usage in `native.mojo`
2. Implement bulk memcpy for entire batch
3. Remove Python loops from add_vector_batch
4. Use ctypes for proper pointer handling

#### Verification
```python
# Test: numpy should be 10x+ faster than lists
numpy_batch: 5,000+ vec/s
list_batch:    500 vec/s  
```

---

### PHASE 2: MEMORY OPTIMIZATION
**Impact**: 2-3x speedup | **Timeline**: 1 week | **Target**: 10,000+ vec/s

#### Problem  
- Creating List[Float32] per vector (allocation overhead)
- No memory pooling (malloc/free thrashing)
- Misaligned memory (no SIMD optimization)

#### Solution
```mojo
# Flat vector storage - single allocation
struct FlatVectorStorage:
    var data: UnsafePointer[Float32]  # All vectors contiguous
    var count: Int
    var dimension: Int
    
    fn get_vector(self, idx: Int) -> UnsafePointer[Float32]:
        return self.data + (idx * self.dimension)
```

#### Implementation Steps
1. Replace Dict[String, List[Float32]] with flat storage
2. Implement memory pool with 16MB chunks
3. Ensure 32-byte alignment for AVX2
4. Pre-allocate based on expected batch size

---

### PHASE 3: ALGORITHM OPTIMIZATION  
**Impact**: 1.5-2x speedup | **Timeline**: 1 week | **Target**: 20,000+ vec/s

#### Problem
- Scalar distance calculations
- Building graph on every batch
- Suboptimal DiskANN parameters
- Debug prints in hot paths

#### Solution
```mojo
# SIMD vectorized distance (8x faster)
@always_inline
fn distance_simd(a: UnsafePointer[Float32], b: UnsafePointer[Float32], 
                 dim: Int) -> Float32:
    var sum = SIMD[DType.float32, 8](0)
    for i in range(0, dim, 8):
        var va = (a + i).load[width=8]()
        var vb = (b + i).load[width=8]()
        var diff = va - vb
        sum += diff * diff
    return sum.reduce_add().sqrt()
```

#### Implementation Steps
1. Vectorize all distance calculations
2. Tune DiskANN parameters (R=24, L=48 for batch)
3. Remove ALL debug prints
4. Implement pruned graph building

---

### PHASE 4: HYBRID ARCHITECTURE (If Needed)
**Impact**: 5-10x speedup | **Timeline**: 2 weeks | **Target**: 50,000+ vec/s

#### Problem
- Mojo FFI fundamental limitations  
- Can't achieve true zero-copy from Python
- Memory management overhead

#### Solution  
```c
// C backend for critical paths
void* omendb_batch_add(float* vectors, int count, int dim) {
    // Direct memory operations, no Python overhead
    memcpy(storage + offset, vectors, count * dim * sizeof(float));
    return handle;
}
```

#### Implementation Steps
1. C/Rust backend for vector storage
2. Memory-mapped files for persistence
3. Lock-free data structures
4. Async pipeline with io_uring

---

## Competitor Benchmarks (Target)

| Database | Batch Insert | Architecture Secret |
|----------|-------------|-------------------|
| LanceDB | 50,000 vec/s | Rust + Arrow columnar |
| Qdrant | 40,000 vec/s | Rust + segments + mmap |
| Weaviate | 25,000 vec/s | Go + LSM tree |
| ChromaDB | 5,000 vec/s | Python + SQLite |
| **OmenDB (current)** | **1,465 vec/s** | **Mojo + FFI bottleneck** |
| **OmenDB (Phase 1)** | **5,000 vec/s** | **Fix FFI** |
| **OmenDB (Phase 2)** | **10,000 vec/s** | **Memory pool** |
| **OmenDB (Phase 3)** | **20,000 vec/s** | **SIMD + tuning** |
| **OmenDB (Phase 4)** | **50,000 vec/s** | **C/Rust hybrid** |

## Success Metrics

### Phase 1 Complete
- [ ] numpy 10x faster than lists
- [ ] Batch insert: 5,000+ vec/s
- [ ] Zero Python loops in hot path

### Phase 2 Complete  
- [ ] Memory usage: <2KB per vector
- [ ] Batch insert: 10,000+ vec/s
- [ ] No malloc in hot path

### Phase 3 Complete
- [ ] SIMD distance calc working
- [ ] Batch insert: 20,000+ vec/s  
- [ ] Search: <1ms for k=10

### Phase 4 Complete
- [ ] C/Rust backend integrated
- [ ] Batch insert: 50,000+ vec/s
- [ ] Memory-mapped storage

## Implementation Priority

**DO FIRST**: Phase 1 - FFI is 90% of the problem  
**THEN**: Phase 2 - Memory efficiency enables scale  
**THEN**: Phase 3 - Algorithm tuning for final push  
**IF NEEDED**: Phase 4 - Only if pure Mojo can't hit 20K

## Testing Protocol

```python
# Standard benchmark for each phase
import omendb
import numpy as np
import time

db = omendb.DB()
vectors = np.random.rand(10000, 128).astype(np.float32)

start = time.perf_counter()
db.add_batch(vectors)
elapsed = time.perf_counter() - start

print(f"Performance: {len(vectors)/elapsed:,.0f} vec/s")
assert len(vectors)/elapsed > TARGET_FOR_PHASE
```

## Common Pitfalls to Avoid

1. **Testing wrong version** - Always use `PYTHONPATH=/Users/nick/github/omendb/omendb/python:$PYTHONPATH`
2. **Fake implementations** - Verify batch is actually faster than single
3. **Debug prints** - Remove ALL prints from hot paths
4. **Wrong benchmarks** - Test with numpy arrays, not lists
5. **Premature optimization** - Fix FFI first, it's 90% of the issue

## References

- [Qdrant Architecture](../external/qdrant) - Segments + mmap strategy
- [LanceDB Design](../external/lancedb) - Arrow columnar approach  
- [Weaviate Internals](../external/weaviate) - LSM tree design
- [DiskANN Paper](https://www.microsoft.com/en-us/research/publication/diskann-fast-accurate-billion-point-nearest-neighbor-search-on-a-single-node/) - Algorithm details