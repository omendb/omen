# Documentation Reorganization Plan
*Date: August 23, 2025*

## Current Disaster State

**102 markdown files** scattered across:
- 23 files in `/docs/internal/performance/` (mostly outdated)
- 25 files in `/docs/internal/archive/` (should be deleted)
- 15 files in `/docs/internal/dev/` (mix of useful/outdated)
- 12 files in `/docs/internal/business/` (YC stuff)
- 27 other random files in `/docs/internal/`

## Target Clean Structure

Based on `AI_DOCS_PROMPT.md`:

```
CLAUDE.md                           # ✅ EXISTS - Entry point
STATUS.md                           # ✅ EXISTS - Current state
docs/
├── TECH_SPEC.md                    # Consolidate architecture docs
├── IMPLEMENTATION_GUIDE.md         # Our new optimal guide
├── COMPETITIVE_ANALYSIS.md         # Our competitor analysis
├── performance/
│   ├── CURRENT_BENCHMARKS.md       # Real tested numbers
│   └── OPTIMIZATION_ROADMAP.md     # Phase 1/2/3 plan
├── archive/
│   └── [move old files here]       # Keep for reference
└── business/
    └── [YC and investor docs]      # Keep separate
```

## Action Plan

### Phase 1: Archive Old Files (Keep for Reference)
```bash
# Move outdated performance docs
mkdir -p docs/archive/performance-old/
mv docs/internal/performance/OPTIMIZATION_* docs/archive/performance-old/
mv docs/internal/performance/IDIOMATIC_* docs/archive/performance-old/

# Move old architecture docs
mkdir -p docs/archive/architecture-old/
mv docs/internal/ARCHITECTURE*.md docs/archive/architecture-old/
mv docs/internal/ALGORITHM_STRATEGY.md docs/archive/architecture-old/
mv docs/internal/MEMORY_POOL_LESSONS.md docs/archive/architecture-old/
```

### Phase 2: Consolidate Key Files
```bash
# Create the 5 essential docs
docs/TECH_SPEC.md                  # Combine all architecture
docs/IMPLEMENTATION_GUIDE.md       # Our optimal implementation plan  
docs/COMPETITIVE_ANALYSIS.md       # Our competitor research
docs/performance/BENCHMARKS.md     # Real tested numbers only
docs/performance/ROADMAP.md        # Phase 1/2/3 plan
```

### Phase 3: Update CLAUDE.md References
```bash
# Point to the new clean structure
@docs/TECH_SPEC.md                # Architecture overview
@docs/IMPLEMENTATION_GUIDE.md      # How to optimize
@docs/COMPETITIVE_ANALYSIS.md      # Why competitors are faster
```

## What to Keep vs Delete

### ✅ KEEP (8 core files):
- `COMPETITIVE_ARCHITECTURE_ANALYSIS.md` (NEW - August 23)
- `OPTIMAL_IMPLEMENTATION_GUIDE.md` (NEW - August 23)
- `ALGORITHM_STRATEGY.md` (good historical context)
- `MEMORY_POOL_LESSONS.md` (important lessons learned)
- Business docs in `/business/` (investor/YC materials)

### 📦 ARCHIVE (historical reference):
- Old performance docs from July/August
- Multiple optimization plans (outdated)
- Architecture reviews (superseded)
- Implementation summaries (superseded)

### 🗑️ DELETE (redundant/empty):
- "COMPLETE" and "FINAL" docs that are outdated
- Multiple roadmaps and plans (conflicting)
- Docs with just 1-2 paragraphs
- Pure duplicates

## New File Descriptions

### docs/TECH_SPEC.md
**Consolidates**: ARCHITECTURE.md, TECHNICAL_ARCHITECTURE.md, STORAGE_ENGINE_*.md
**Content**: Current architecture, DiskANN choice, Mojo rationale, storage design

### docs/IMPLEMENTATION_GUIDE.md  
**Source**: Our new OPTIMAL_IMPLEMENTATION_GUIDE.md
**Content**: Phase 1/2/3 optimization plan, zero-copy fixes, deferred indexing

### docs/COMPETITIVE_ANALYSIS.md
**Source**: Our new COMPETITOR_ARCHITECTURE_ANALYSIS.md  
**Content**: Why Qdrant/Weaviate/LanceDB are faster, what we can learn

### docs/performance/BENCHMARKS.md
**Content**: ONLY tested, verified performance numbers
**Format**: 
```
Date: 2025-08-23
Config: M3 Max, 1000x128 vectors
Results:
  - Numpy arrays: 3,250 vec/s
  - Python lists: 3,250 vec/s (proves zero-copy is fake)
  - Search: 0.6ms
```

### docs/performance/ROADMAP.md  
**Content**: Clear phase plan with targets
```
Phase 1: Fix critical issues → 15K vec/s (1 week)
Phase 2: Segment architecture → 30K vec/s (2 weeks)  
Phase 3: Arrow columnar → 50K+ vec/s (3 weeks)
```

## Success Criteria

✅ **From 102 files to ~15 key files**
✅ **Clear single source of truth for each topic**  
✅ **AI agents can find info in <3 file reads**
✅ **No conflicting information**
✅ **All performance claims are tested**

## Implementation Order

1. **First**: Create the 5 new consolidated files
2. **Second**: Update CLAUDE.md to point to new structure  
3. **Third**: Move old files to archive/
4. **Fourth**: Delete pure duplicates and empty files
5. **Last**: Update any scripts/tools that reference old paths