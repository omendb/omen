# OmenDB Technical Specification

## Overview
Embedded vector database written in Mojo, optimized for simplicity and performance.

## Core Requirements

### Functional
- Store and retrieve high-dimensional vectors (64-2048 dimensions)
- Approximate nearest neighbor search with >95% accuracy
- Metadata filtering on search results
- Persistence to disk with crash recovery
- Python API for ease of use

### Performance Targets
- **Insert**: 35,000 vectors/second (batch)
- **Search**: <1ms for k=10 @ 100K vectors
- **Memory**: <2x vector data size
- **Startup**: <100ms cold start

### Scale
- **Minimum**: 1 vector (no overhead for small datasets)
- **Maximum**: 1B vectors (disk-based, not all in memory)
- **Sweet spot**: 100K-10M vectors (all in memory)

## Architecture

### Single Algorithm Strategy
**DiskANN** - Works efficiently from 1 to 1B vectors
- No algorithm switching complexity
- Proven scalability
- No index rebuilds needed

### Two-Tier Storage
```
VectorBuffer (in-memory, fast)
    ↓ flush when full
DiskANN Index (persistent, scalable)
```

### Key Components

| Component | Purpose | Performance Impact |
|-----------|---------|-------------------|
| VectorBuffer | O(1) insertion buffer | 94K vec/s capability |
| DiskANN | Main index structure | 2-10ms search |
| Metadata Store | Key-value for filtering | Negligible |
| Storage Engine | Persistence layer | Write: 100MB/s |

## API Design

### Python Interface
```python
from omendb import DB

# Simple API
db = DB()
db.add("id1", [1.0, 2.0, 3.0], {"type": "example"})
results = db.search([1.0, 2.0, 3.0], k=5)

# Batch operations (faster)
db.add_batch(vectors, ids, metadata)
```

### Mojo Core
```mojo
struct DatabaseStore:
    var buffer: VectorBuffer           # Fast insertion
    var main_index: DiskANN           # Persistent index
    var metadata_store: Dict          # Metadata
    var storage: StorageEngine        # Persistence
```

## Implementation Status

### Working ✅
- DiskANN algorithm with SIMD optimization
- VectorBuffer for fast insertion
- Python API with auto-batching
- Snapshot persistence
- Metadata filtering
- 100% search accuracy

### Optimizations (Partial)
- ✅ SIMD distance calculations (41% faster search)
- ✅ Norm caching (10-15% improvement)
- ✅ Batch distance calculations
- ❌ Memory pool (disabled - thread safety issues)
- ❌ Parallel processing (DiskANN not thread-safe)

### Not Implemented
- Collections/namespaces (single DB design)
- Distributed/sharding (embedded focus)
- GPU acceleration (CPU-only for now)
- Windows support (Mojo limitation)

## Performance Characteristics

### Current (v0.2.0-beta)
| Operation | Performance | Notes |
|-----------|------------|--------|
| Batch insert | 23,438 vec/s | Memory pool disabled |
| Individual insert | 2,888 vec/s | FFI overhead dominant |
| Search @ 128d | 0.46ms | SIMD optimized |
| Memory usage | 1.5x vector size | Efficient |
| Startup time | <50ms | Fast |

### Bottlenecks
1. **Python-Mojo FFI**: 0.3ms overhead per call
2. **Memory allocation**: No pooling due to thread safety
3. **No zero-copy**: Numpy arrays still copied

## Design Decisions

### Why DiskANN Only?
- Scales from 1 to 1B vectors
- No algorithm switching bugs
- Simpler codebase
- Good enough performance at all scales

### Why No Memory Pool?
- Mojo lacks mutex/thread safety
- Mixed allocation sizes problematic
- Stability > 30% performance gain

### Why Embedded?
- No server overhead
- Instant startup
- Simple deployment
- "DuckDB of vector databases"

## Quality Attributes

### Reliability
- No segfaults in production
- Graceful degradation on errors
- Data integrity via snapshots

### Maintainability  
- Single algorithm reduces complexity
- Clear module boundaries
- Comprehensive test suite

### Performance
- Predictable latencies
- No garbage collection pauses
- Cache-friendly data structures

## Testing Strategy

### Unit Tests
- Core algorithms (DiskANN, VectorBuffer)
- Distance functions accuracy
- Metadata operations

### Integration Tests
- Python API functionality
- Persistence and recovery
- Large-scale operations

### Performance Tests
- Benchmark suite comparing versions
- Stress tests (24hr continuous operation)
- Memory leak detection

## Future Roadmap

### v0.3.0 (Next)
- Fix FFI overhead
- Re-enable memory pool (when Mojo ready)
- Target: 35K vec/s

### v1.0.0 (Production)
- Collections support
- Advanced filtering
- Target: 50K vec/s

### Long-term
- GPU acceleration
- Distributed support
- Rust core (if Mojo doesn't mature)