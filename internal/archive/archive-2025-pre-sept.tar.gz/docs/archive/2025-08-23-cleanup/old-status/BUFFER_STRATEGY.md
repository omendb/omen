# Buffer Strategy: Segment Architecture

**Last Updated**: December 13, 2024  
**Status**: Architecture redesign based on industry analysis  
**Key Insight**: Nobody updates graph indexes in-place - use immutable segments

## Problem Analysis

### Current Issue
- Buffer implemented but only 3K vec/s (expected 50K+)
- Using BruteForceIndex (500+ lines) as buffer
- Trying to flush buffer INTO existing DiskANN (wrong pattern)

### Root Cause
**Architectural mistake**: Attempting in-place graph updates
- DiskANN.add() is O(log n) but still expensive
- Graph updates require edge rewiring
- Industry doesn't do this - they rebuild segments

## Industry Patterns

### ChromaDB
```python
# Segments are immutable once built
segment = build_new_segment(buffer + old_data)
atomic_swap(old_segment, new_segment)
```

### Qdrant
```rust
// Append to buffer, build new immutable segment
let new_segment = Segment::build_from(memtable);
segments.push(new_segment);
```

### Weaviate/LanceDB
- LSM-tree approach: Immutable SSTables
- Delta Lake: Base + append-only deltas

**Pattern**: Immutable segments + atomic swaps

## Proposed Architecture

### Immediate Fix (1-2 days)
```mojo
struct SimpleBuffer:
    var vectors: UnsafePointer[Float32]
    var ids: List[String]
    var size: Int
    var capacity: Int
    
    @always_inline
    fn add(mut self, id: String, vec: DTypePointer) -> Bool:
        # Direct memory copy - no overhead
        memcpy(self.vectors + self.size * dim, vec, dim * 4)
        self.ids.append(id)
        self.size += 1
        return True
```

### Correct Architecture (1 week)
```mojo
struct SegmentStore:
    var memtable: SimpleBuffer      # Fast writes
    var segments: List[DiskANN]     # Immutable segments
    
    fn flush(mut self):
        # Build NEW segment, don't update existing
        var new_segment = DiskANN.build(self.memtable)
        self.segments.append(new_segment)
        self.memtable.clear()
```

## Implementation Plan

### Phase 1: Fix Buffer (Today)
1. Replace BruteForceIndex with SimpleBuffer
2. Remove all features except vector storage
3. Target: 50K+ vec/s

### Phase 2: Segment Architecture (This Week)
1. Make DiskANN segments immutable
2. Build new segments on flush
3. Atomic pointer swaps

### Phase 3: Production Features (Next Week)
1. Background segment merging
2. WAL for durability
3. Concurrent readers

## Performance Targets
- Buffer writes: 50K+ vec/s
- Segment build: <1s for 100K vectors  
- Search: <2ms across all segments
- Memory: 2x vector data (buffer + main)