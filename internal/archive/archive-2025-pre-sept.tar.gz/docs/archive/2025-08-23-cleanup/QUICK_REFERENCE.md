# OmenDB Quick Reference Card

**For AI sessions starting after August 11, 2025**

## 🚀 Start Every Session With
1. Check `/Users/nick/github/omendb/omendb-cloud/CLAUDE.md`
2. Check `/Users/nick/github/omendb/omendb-cloud/docs/internal/MASTER_STATUS.md`
3. Check `/Users/nick/github/omendb/omendb-cloud/docs/internal/CURRENT_SPRINT.md`

## 📁 Directory Structure (POST-REORGANIZATION)

### Private Repo (`omendb-cloud/`)
```
/Users/nick/github/omendb/omendb-cloud/
├── docs/internal/       # All internal docs
├── server/              # Rust server code
├── admin/               # Admin dashboard (planned)
└── CLAUDE.md           # Main context file
```

### Public Repo (`omendb/`)
```
/Users/nick/github/omendb/omendb/
├── omendb/             # Mojo source
│   └── algorithms/     # DiskANN ONLY (no HNSW/RoarGraph)
├── tests/              # All tests (NOT test/)
│   ├── benchmarks/     # Performance tests
│   └── unit/           # Unit tests
├── tools/              # Dev utilities
│   └── profiling/      # Profiling tools
└── CLAUDE.md          # Public context
```

## ⚠️ Key Changes (August 11, 2025)
- `test/` → `tests/` (renamed)
- `benchmarks/` → `tests/benchmarks/` (moved)
- `profiling/` → `tools/profiling/` (moved)
- Removed all HNSW and RoarGraph code
- DiskANN-only architecture

## 🎯 Current State
- **Algorithm**: DiskANN only
- **Performance**: 96K vec/s at 10K vectors
- **No Collections**: Mojo limitation
- **No Windows**: Use WSL2

## 🔧 Common Commands
```bash
# Build
pixi run mojo build omendb/native.mojo -o python/omendb/native.so --emit shared-lib

# Test
PYTHONPATH=python pixi run pytest tests/

# Benchmark
PYTHONPATH=python python tests/benchmarks/test_suite.py

# Profile
PYTHONPATH=python python tools/profiling/profile_suite.py
```

## 📊 Performance Truth
- **Current**: 96K vec/s at 10K vectors
- **NOT**: 99K, 156K, or 210K vec/s
- **Memory**: 16.7KB per vector
- **Query**: 2.59ms P50 latency

## ❌ Removed/Deprecated
- HNSW algorithm (removed)
- RoarGraph algorithm (removed)  
- Algorithm migration code (removed)
- Collections API (disabled - Mojo limitation)

## ✅ Trust These Files
1. `omendb-cloud/docs/internal/MASTER_STATUS.md`
2. `omendb-cloud/CLAUDE.md`
3. `omendb/CLAUDE.md`
4. This quick reference

---
**Remember**: DiskANN-only, 96K vec/s, tests/ not test/, no HNSW/RoarGraph