# OmenDB Documentation Structure

**Date**: December 2024  
**Purpose**: Clear documentation hierarchy for efficient development

## 📚 Documentation Hierarchy

```
CLAUDE.md (Entry point)
  ↓
Key Documents (5 files)
  ↓  
Detailed Documents (by topic)
```

## 🎯 Key Documents (Always Current)

1. **MASTER_STATUS.md** - Single source of truth for project status
2. **CURRENT_SPRINT.md** - Active tasks and immediate priorities  
3. **TECHNICAL_ARCHITECTURE.md** - System design and architecture
4. **business.md** - Business strategy and positioning
5. **DISKANN_COMPLETE_STRATEGY.md** - Core algorithm strategy

## 📁 Detailed Documents (Topic-Specific)

### Development
- `IMPLEMENTATION_STATUS.md` - Development progress tracking
- `STORAGE_ENGINE_PRACTICAL.md` - Storage implementation guide
- `STORAGE_ENGINE_ARCHITECTURE_DECISION.md` - Key architectural decisions

### Strategy
- `strategy/DISKANN_COMPLETE_STRATEGY.md` - DiskANN implementation roadmap
- `strategy/STORAGE_ENGINE_FUTURE.md` - Future storage considerations

### Investor Relations
- `investor/INVESTOR_OVERVIEW.md` - Business overview for investors
- `investor/YC_APPLICATION_DRAFT.md` - YC application materials

## 🗑️ What We're Removing

### Outdated Algorithm Comparisons
- All HNSW vs RoarGraph vs DiskANN comparison docs
- Algorithm migration documents (we don't migrate anymore)
- Lazy indexing plans (not using this approach)

### Test Files
- Moving test files from `docs/internal/tests/` to `/test/diskann/`

### Archive Cleanup
- Removing 90% of archive (it's in git history)
- Keeping only: critical learnings, useful code snippets

## ✅ Final Structure

```
omendb-cloud/
├── CLAUDE.md                          # Entry point with navigation
├── docs/
│   ├── internal/
│   │   ├── MASTER_STATUS.md          # Single source of truth
│   │   ├── CURRENT_SPRINT.md         # Active work
│   │   ├── TECHNICAL_ARCHITECTURE.md # System design
│   │   ├── business.md                # Business strategy
│   │   ├── IMPLEMENTATION_STATUS.md  # Progress tracking
│   │   ├── STORAGE_ENGINE_PRACTICAL.md # Storage guide
│   │   └── strategy/
│   │       ├── DISKANN_COMPLETE_STRATEGY.md
│   │       └── STORAGE_ENGINE_FUTURE.md
│   └── investor/
│       ├── INVESTOR_OVERVIEW.md
│       └── YC_APPLICATION_DRAFT.md
└── test/
    └── diskann/                      # Test files (moved from docs)
```

## 🚀 Benefits

1. **Clear Navigation** - Start at CLAUDE.md, find everything quickly
2. **No Duplication** - Single source of truth for each topic
3. **Focused Content** - Only DiskANN and current strategy
4. **Clean Structure** - Logical hierarchy, no clutter