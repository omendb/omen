# OmenDB Project Status
*Last Updated: August 23, 2025*

## 📊 Current Performance
**Version**: v0.2.0-dev  
**Status**: Fixing performance regression from persistence implementation

| Metric | Current | Previous Best | Target |
|--------|---------|---------------|--------|
| **In-memory** | 68,794 vec/s | 70K+ vec/s | 100K+ vec/s |
| **With persistence path** | 57,499 vec/s | - | 65K+ vec/s |
| **With checkpoint** | 665 vec/s | 70K vec/s | 50K+ vec/s |
| **Search latency** | 0.62ms | 0.6ms | <0.5ms |
| **Memory usage** | 40MB/1M vec | - | 12MB/1M vec |

## 🚨 Critical Issue: Checkpoint Performance Regression

### Problem
Checkpoint dropped from 70K to 62 vec/s (1000x slower), now improved to 665 vec/s after first fix.

### Root Causes Identified
1. ✅ **FIXED**: Copy constructor creating duplicate "_copy" files (10.7x speedup achieved)
2. 🔄 **IN PROGRESS**: Element-by-element copying instead of batch operations
3. ⏳ **TODO**: Synchronous blocking checkpoint (needs async)
4. ⏳ **TODO**: Full file rewrites instead of incremental updates

### Fix Progress
- [x] Fix copy constructor file duplication → 62 to 665 vec/s 
- [ ] Batch memory operations → Expected 5x gain (3.3K vec/s)
- [ ] Async checkpoint thread → Expected 10x gain (30K+ vec/s)
- [ ] Incremental WAL → Expected 1.5x gain (50K+ vec/s)

## ✅ What's Working Well
- **FFI zero-copy**: True zero-copy from numpy arrays via `unsafe_get_as_pointer`
- **In-memory performance**: Still excellent at 68K+ vec/s
- **Memory-mapped storage**: 3.9x faster than legacy storage
- **Search**: Sub-1ms latency maintained
- **Python API**: Clean, intuitive interface

## 🔧 Active Development

### This Sprint (Aug 23)
1. **Performance fixes** - Restore 50K+ vec/s with persistence
2. **Documentation cleanup** - Consolidate redundant docs
3. **Storage optimization** - Implement async checkpoint

### Implementation in Progress
See [`docs/internal/current/PERFORMANCE_FIX_PLAN.md`](docs/internal/current/PERFORMANCE_FIX_PLAN.md) for detailed optimization plan.

Current file being optimized: `omendb/core/memory_mapped_storage.mojo:530-550`

## 📂 Key Files

### Core Implementation
- `omendb/native.mojo` - Main database engine (2700 lines)
- `omendb/core/memory_mapped_storage.mojo` - New storage engine (630 lines)
- `omendb/algorithms/diskann.mojo` - DiskANN algorithm (800 lines)

### Documentation
- `CLAUDE.md` - Project overview and navigation
- `docs/INDEX.md` - Complete documentation map
- `docs/internal/current/*` - Active development docs

## 🎯 Decisions & Rationale

### Aug 23: Memory-Mapped Storage
- **Decision**: Replace WAL with memory-mapped storage
- **Why**: WAL is 2-3 generations behind state-of-art (2025 research)
- **Impact**: 3.9x improvement over legacy, but checkpoint needs async

### Aug 22: DiskANN Only
- **Decision**: Single algorithm, no switching
- **Why**: Simpler = fewer bugs, easier to optimize
- **Impact**: Predictable performance, easier debugging

### Aug 21: Disable Memory Pool
- **Decision**: Turn off memory pooling temporarily
- **Why**: Thread safety issues in Mojo
- **Impact**: -30% performance, but stable

## 📈 Competitive Position

| Database | Throughput | vs OmenDB | Notes |
|----------|------------|-----------|-------|
| LanceDB | 50K vec/s | Target | Arrow columnar, Rust |
| Qdrant | 40K vec/s | Target | Memory-mapped, Rust |
| Weaviate | 25K vec/s | Beat with fixes | LSM-tree, Go |
| ChromaDB | 5K vec/s | Already beat | SQLite + Rust |
| **OmenDB** | **665 vec/s** | Current | After first fix |
| **OmenDB** | **50K+ vec/s** | Target | After all fixes |

## 🚀 Next Steps

### Immediate (Today)
1. Implement batch memory operations in checkpoint
2. Test performance improvement
3. Start async checkpoint implementation

### This Week
1. Complete async checkpoint system
2. Add incremental persistence
3. Achieve 30K+ vec/s with persistence

### Next Week
1. Direct memory-mapped pointer access
2. SSD-optimized write patterns
3. Target 50K+ vec/s with full durability

## 📋 Testing Commands

```bash
# Build
cd /Users/nick/github/omendb/omendb
pixi run mojo build omendb/native.mojo -o python/omendb/native.so --emit shared-lib

# Test performance (use dev path!)
PYTHONPATH=/Users/nick/github/omendb/omendb/python:$PYTHONPATH python benchmarks/quick_benchmark.py

# Test memory-mapped storage
python test_memory_mapped_storage.py

# Performance regression test
./test_performance_regression.py
```

## 🔗 References
- [Performance Fix Plan](docs/internal/current/PERFORMANCE_FIX_PLAN.md)
- [Next-Gen Storage Design](docs/internal/current/NEXT_GEN_STORAGE_PLAN.md)
- [Competitive Analysis](docs/internal/current/COMPETITIVE_ANALYSIS.md)
- [Implementation Guide](docs/implementation/IMPLEMENTATION_GUIDE.md)