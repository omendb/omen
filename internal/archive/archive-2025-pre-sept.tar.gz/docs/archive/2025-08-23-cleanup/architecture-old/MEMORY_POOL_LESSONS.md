# Memory Pool Implementation Lessons

## What We Tried

### Attempt 1: Simple Global Pool ❌
**Implementation**: Global pool with lazy initialization
**Result**: Segfault on `db.clear()`
**Root Cause**: Pool not reset, double-free when destructor returns memory

### Attempt 2: Pool Reset on Clear ✅/❌  
**Implementation**: Added `reset_global_pool()` called before clearing buffer
**Result**: Fixed simple cases, but "invalid pointer" errors in batch operations
**Root Cause**: Mixed allocation sizes and thread safety issues

## Why Memory Pool Failed

### 1. Mixed Allocation Sizes
```mojo
# Pool designed for single vectors:
allocate_vector(dimension)  # Returns dimension-sized chunk

# But we also need:
VectorBuffer: capacity * dimension  # Much larger
Distance buffer: num_vectors        # Different size
```

**Issue**: Pool assumes all allocations are same size (dimension)

### 2. Thread Safety
- Auto-batching uses threading.Timer
- Multiple threads might allocate/free simultaneously  
- Pool has no locking mechanism
- Result: Corruption when threads interleave

### 3. Pointer Corruption
```
src/tcmalloc.cc:302] Attempt to free invalid pointer 0x11ff0b28ff1f240e
```
This suggests:
- Memory corruption (writing past bounds)
- Double-free (same pointer freed twice)
- Wrong size passed to free

### 4. Mojo Limitations
- No RAII - manual memory management error-prone
- No weak_ptr/shared_ptr - can't track ownership
- Limited debugging tools - hard to trace memory issues
- No valgrind support - can't detect memory errors

## What Would Work

### Option 1: Size-Aware Pools
```mojo
struct SizeAwarePool:
    var pools: Dict[Int, VectorMemoryPool]  # Pool per size
    
    fn get_buffer(self, size: Int) -> UnsafePointer[Float32]:
        if size not in self.pools:
            self.pools[size] = VectorMemoryPool(size, 10)
        return self.pools[size].get_buffer()
```

### Option 2: Thread-Safe Pool
```mojo
struct ThreadSafePool:
    var pool: VectorMemoryPool
    var lock: Mutex  # Need mutex support
    
    fn get_buffer(self) -> UnsafePointer[Float32]:
        self.lock.acquire()
        var ptr = self.pool.get_buffer()
        self.lock.release()
        return ptr
```

### Option 3: Per-Instance Pools
```mojo
struct DatabaseStore:
    var instance_pool: VectorMemoryPool
    
    # Pass pool to all allocations
    # No global state, no threading issues
```

### Option 4: Arena Allocator
```mojo
struct ArenaAllocator:
    var arena: UnsafePointer[UInt8]
    var offset: Int
    var size: Int
    
    fn alloc(self, bytes: Int) -> UnsafePointer[UInt8]:
        var ptr = self.arena + self.offset
        self.offset += bytes
        return ptr
    
    fn reset(self):
        self.offset = 0  # Super fast "free"
```

## Performance Without Pool

**Current Performance** (pool disabled):
- 128d: 23,438 vec/s
- 256d: 19,300 vec/s  
- 512d: 16,521 vec/s

**Expected with Pool** (if it worked):
- 128d: ~30,000 vec/s (+28%)
- 256d: ~25,000 vec/s (+30%)
- 512d: ~21,000 vec/s (+27%)

## Lessons Learned

### 1. Start Simple
Should have started with per-instance pool, not global

### 2. Test Threading Early
Didn't test with auto-batching threads initially

### 3. Size Assumptions
Assumed all allocations would be vector-sized

### 4. Mojo Not Ready
Memory management primitives too primitive for complex pooling

## Recommendation

**Don't use memory pools in Mojo yet**. Wait for:
1. Better threading primitives (mutex, atomics)
2. RAII or scope guards
3. Better debugging tools
4. More mature standard library

**Alternative optimizations**:
1. Reduce allocations (reuse buffers)
2. Batch operations (amortize overhead)
3. SIMD alignment (use aligned_alloc when available)
4. Custom allocator (jemalloc via FFI)

## The Real Bottleneck

The memory pool would give 20-30% improvement, but the real bottleneck is:
- **Python-Mojo FFI**: 0.3ms overhead per call
- **Python list conversion**: "Using Python list path"
- **No true zero-copy**: Even numpy arrays get copied

Fixing these would give 10x improvement vs 1.3x from memory pool.