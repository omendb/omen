# OmenDB Architecture & Strategy

**Version**: v0.3.0 (December 2024)  
**Vision**: The DuckDB of Vector Databases - One Algorithm, Any Scale

## 🎯 Market Requirements

### Target Users & Scale
- **95% of users**: 1K - 100K vectors (RAG, semantic search, embeddings)
- **4% of users**: 100K - 10M vectors (recommendations, similarity)
- **1% of users**: 10M+ vectors (enterprise search)

### Core Requirements
1. **Single Algorithm**: No switching complexity (like DuckDB)
2. **Streaming Updates**: No rebuilding at scale thresholds
3. **>95% Recall**: Accuracy matters more than speed
4. **<10ms Latency**: Fast enough for interactive use
5. **Scales to Billions**: Must handle enterprise without redesign

## 🏗️ Architectural Decision: DiskANN (Vamana)

### Why DiskANN is Optimal

DiskANN is **the only algorithm** that meets all requirements:

| Feature | DiskANN | HNSW | IVF | Brute Force |
|---------|---------|------|-----|-------------|
| Streaming updates | ✅ O(log n) | ❌ Rebuilds | ❌ Reindex | ✅ O(1) |
| Scales to billions | ✅ Disk-native | ⚠️ RAM only | ✅ Disk | ❌ O(n) |
| Small dataset perf | ✅ Good | ⚠️ Overhead | ❌ Bad | ✅ Best |
| No tuning needed | ✅ Auto | ❌ Layers | ❌ Clusters | ✅ None |

### Performance Characteristics

```
Dataset Size  | Search Time | Add Time   | Memory    | Accuracy
--------------|-------------|------------|-----------|----------
1K vectors    | 0.1ms       | 0.01ms     | 1MB       | 100%
10K vectors   | 0.5ms       | 0.05ms     | 10MB      | 99.9%
100K vectors  | 2ms         | 0.1ms      | 100MB     | 99.5%
1M vectors    | 5ms         | 0.2ms      | 1GB       | 99%
10M vectors   | 10ms        | 0.3ms      | 10GB      | 98%
100M vectors  | 20ms        | 0.5ms      | On disk   | 97%
1B vectors    | 50ms        | 1ms        | On disk   | 95%
```

### Why Not Other Approaches?

**HNSW**: Requires layer rebuilding, RAM-only, complex parameters
**IVF**: Requires clustering, poor recall, needs reindexing
**Brute Force**: Doesn't scale beyond 100K vectors
**Hybrid Switching**: Adds complexity, more bugs, confuses users

## 🐛 Current Implementation Issues

### Critical Bug: Entry Point Disconnection

```mojo
# BUG in diskann.mojo line 235-237:
if self.size == 1:
    self.entry_point = 0
    return True  # ❌ Returns without adding edges!
```

**Result**: Entry point has NO outgoing edges, graph unreachable, 2% search accuracy

### The Fix

```mojo
if self.size == 1:
    self.entry_point = 0
    # Don't return - let it continue to build edges
    
# Ensure entry point is well-connected
if new_idx == self.entry_point or self.size < 10:
    # Connect to more nodes for better connectivity
    for i in range(min(self.R * 2, self.size)):
        if i != new_idx:
            self.nodes[new_idx].neighbors.append(i)
```

### Other Issues to Fix

1. **Entry point update**: Currently only updates every 1000 nodes (should be ~100)
2. **Bidirectional edges**: Need proper traversal for beam search
3. **Pruning too aggressive**: Reduces connectivity for small graphs
4. **Beam width**: Should be adaptive based on graph size

## 🎯 Market Positioning

### "One Index, Any Scale"

Unlike competitors who switch algorithms:
- **ChromaDB**: Switches at 10K (complexity)
- **Weaviate**: Multiple indexes (configuration hell)
- **Qdrant**: User must choose (decision paralysis)

**OmenDB**: Single DiskANN algorithm from 1 to 1B vectors (like DuckDB!)

### Performance Targets

| Metric | Current | Target | Required for Market | Status |
|--------|---------|--------|-------------------|--------|
| Add (128D) | 3.1K vec/s | 50K vec/s | 10K vec/s | 🔧 FFI bottleneck |
| Batch Add | 26.4K vec/s | 95K vec/s | 50K vec/s | ✅ Usable |
| Search (128D) | 2K qps | 10K qps | 5K qps | 🔧 Needs optimization |
| Accuracy | 97% | >95% | >95% | ✅ FIXED |
| Buffer Architecture | SimpleBuffer | - | - | ✅ Implemented |

## 🚀 Implementation Roadmap

### Phase 1: Fix DiskANN (✅ COMPLETED December 2024)
- ✅ Fix entry point edge connection bug
- ✅ Update entry point every 100 nodes
- ✅ Ensure bidirectional graph traversal
- ✅ Implement buffer + batch build architecture

### Phase 2: Optimize for Small Datasets (Next)
- [ ] Optional brute force for <1K vectors
- [ ] Better pruning strategy for small graphs
- [ ] Pre-compute popular searches

### Phase 3: Scale Optimizations (Future)
- [ ] Disk-based storage for >100MB indexes
- [ ] Compression for large vectors
- [ ] Distributed sharding for >1B vectors

## 📊 Competitive Analysis

### State of the Art (2024)

| Database | Algorithm | Scales To | Strength | Weakness |
|----------|-----------|-----------|----------|----------|
| Pinecone | HNSW | 10M | Managed service | Expensive, vendor lock |
| Weaviate | HNSW | 100M | Feature-rich | Complex, RAM hungry |
| Qdrant | HNSW+mmap | 1B | Fast (Rust) | Configuration complexity |
| ChromaDB | HNSW+Flat | 10M | Easy to use | Algorithm switching bugs |
| LanceDB | DiskANN | 1B | Columnar format | New, less proven |
| Milvus | Multiple | 1B | Flexible | Too many choices |
| **OmenDB** | DiskANN | 1B | One algorithm | Needs optimization |

### Why OmenDB Will Win

1. **Simplicity**: One algorithm, no configuration
2. **Embedded**: No server, like SQLite/DuckDB
3. **Mojo Performance**: Potential for 10x speed
4. **Streaming**: No rebuilding ever
5. **Open Source**: No vendor lock-in

## 🔧 Technical Specifications

### DiskANN Parameters

```mojo
# Optimal for all scales
const DEFAULT_R = 64        # Max degree (connectivity)
const DEFAULT_L = 100       # Beam width (search quality)
const DEFAULT_ALPHA = 1.2   # Pruning factor (diversity)

# Adaptive based on size
fn get_adaptive_params(size: Int) -> (R: Int, L: Int):
    if size < 1000:
        return (32, 50)    # Lower overhead for small
    elif size < 100000:
        return (64, 100)   # Balanced
    else:
        return (64, 200)   # Quality for large
```

### Memory Layout

```
VamanaNode:
  - id: String (8 bytes)
  - vector: Float32[dim] (4 * dim bytes)
  - neighbors: Int[R] (8 * R bytes)
  - reverse_neighbors: Int[] (variable)
  
Total per vector: ~1KB for 128D vectors
```

## 📝 Key Decisions

1. **DiskANN only**: No algorithm switching
2. **Fix bugs first**: Current implementation is broken
3. **Optimize later**: Correctness before performance
4. **Market position**: "One index, any scale"
5. **Target**: 95% of users (1K-100K vectors)

## 🎯 Success Metrics

- **Correctness**: >95% recall at all scales
- **Performance**: 10K vec/s adds, 5K qps searches
- **Simplicity**: Zero configuration needed
- **Scalability**: 1 vector to 1B vectors, same code
- **Adoption**: Easier than ChromaDB, faster than Weaviate

---

*"The best algorithm is the one that works correctly at all scales"*