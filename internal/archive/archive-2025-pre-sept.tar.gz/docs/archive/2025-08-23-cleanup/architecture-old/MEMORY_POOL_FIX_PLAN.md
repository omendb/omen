# Memory Pool Fix Plan

## Root Cause Analysis

The segfault occurs because:
1. Global pool lazily initialized on first use
2. VectorBuffer gets memory from pool
3. `clear_database()` clears buffer, triggering destructor
4. Destructor tries to return memory to pool
5. Pool state inconsistent → segfault

## The Fix (Yes, Mojo Can Do It!)

### Option 1: Smart Pool Reset (RECOMMENDED) ✅

**Key Insight**: The pool already has a `clear()` method that marks all blocks as available!

```mojo
# Add to memory_pool.mojo
fn reset_global_pool():
    """Reset global pool, marking all blocks as available."""
    if __global_pool:
        __global_pool[0].clear()  # Marks all blocks as not in_use

# In native.mojo clear_database():
fn clear_database() raises -> PythonObject:
    # FIRST: Reset pool to mark all memory as available
    reset_global_pool()
    
    # THEN: Clear buffer (destructor won't double-free)
    db[].buffer.clear()
    
    # Continue with rest of clear...
```

### Option 2: Track Pool vs Direct Allocation

```mojo
struct VectorBuffer:
    var data: UnsafePointer[Float32]
    var is_from_pool: Bool  # NEW: Track allocation source
    
    fn __init__(out self, dimension: Int, capacity: Int):
        # Try pool first
        var pool = get_global_pool(dimension)
        self.data = pool[0].get_buffer()
        if self.data:
            self.is_from_pool = True
        else:
            self.data = UnsafePointer[Float32].alloc(capacity * dimension)
            self.is_from_pool = False
    
    fn __del__(owned self):
        if self.data:
            if self.is_from_pool:
                var pool = get_global_pool(self.dimension)
                pool[0].return_buffer(self.data)
            else:
                self.data.free()
```

### Option 3: Instance-Based Pools

```mojo
struct DatabaseStore:
    var instance_pool: VectorMemoryPool  # Per-instance pool
    
    fn __init__(out self, dimension: Int):
        self.instance_pool = VectorMemoryPool(dimension, 100)
        # Pass pool to VectorBuffer
        self.buffer = VectorBuffer(dimension, capacity, self.instance_pool)
```

## Why This Works with Current Mojo

1. **Manual Memory Management**: ✅ We control allocation/deallocation
2. **Clear Method Exists**: ✅ Pool already has `clear()` 
3. **Tracking State**: ✅ Can add bool flags
4. **Global Variables**: ✅ Work for simple cases like this

## What Mojo CAN'T Do (Yet)

- **RAII**: No automatic destructors at scope exit
- **Weak References**: Can't have non-owning smart pointers
- **Reference Counting**: Must implement manually
- **Move Semantics**: Limited compared to C++

## Implementation Steps

### Step 1: Add Pool Reset Function
```mojo
# memory_pool.mojo
fn reset_global_pool():
    """Reset pool, marking all blocks as available."""
    if __global_pool:
        __global_pool[0].clear()

fn clear_and_reset_global_pool():
    """Clear pool and zero all memory."""
    if __global_pool:
        var pool = __global_pool[0]
        pool.clear()
        # Zero all blocks for safety
        for i in range(len(pool.blocks)):
            memset_zero(pool.blocks[i].data, pool.dimension)
```

### Step 2: Update clear_database()
```mojo
# native.mojo
fn clear_database() raises -> PythonObject:
    var db = get_global_db()
    
    if db[].initialized:
        # CRITICAL: Reset pool BEFORE clearing buffer
        reset_global_pool()
        
        # Now safe to clear buffer
        db[].buffer.clear()
        
        # Clear other structures...
```

### Step 3: Make VectorBuffer Pool-Aware
```mojo
struct VectorBuffer:
    var data: UnsafePointer[Float32]
    var is_pooled: Bool
    
    fn clear(mut self):
        """Clear buffer and return memory to pool if applicable."""
        self.size = 0
        self.ids.clear()
        # Don't free memory - it goes back to pool or gets reused
```

## Expected Performance

With pool working:
- **Current**: 19,300 vec/s (no pool)
- **With Pool**: 25-28,000 vec/s (30% improvement)
- **Target**: 35,000 vec/s (with all optimizations)

## Testing Strategy

```python
# Test 1: Basic operations
db = DB()
db.clear()  # Should reset pool
db.add("test", [1.0] * 128)  # Should use pool
db.clear()  # Should return to pool

# Test 2: Rapid clear cycles
for i in range(100):
    db.clear()
    db.add(f"vec_{i}", np.random.rand(128))
    
# Test 3: Large batch after clear
db.clear()
db.add_batch(np.random.rand(10000, 128))
```

## Conclusion

**YES, we can fix the memory pool with current Mojo!** The language has all the primitives we need:
- Manual memory management ✅
- Global variables (basic) ✅ 
- Struct methods ✅
- Bool flags for tracking ✅

The fix is straightforward: **Reset the pool before clearing the buffer**. This prevents double-free and maintains pool integrity.