# API Redesign Proposal

**Created**: August 21, 2025

## Current API Problems

### 1. **Naming Inconsistency**
```python
# Python API
db.get("id")  # Returns (vector, metadata)

# Native Mojo
get_vector("id")  # Returns just vector
get_metadata("id")  # Returns just metadata
```

### 2. **Confusing Return Types**
```python
db.get("id")  # -> Optional[Tuple[List[float], Dict[str, str]]]
# Why tuple? Why not object?
```

### 3. **Mixed Paradigms**
```python
db.add()  # Individual
db.add_batch()  # Batch
db.upsert()  # Individual
db.upsert_batch()  # Batch
# Too many methods!
```

## Proposed API Design

### Core Principles

1. **Consistency**: Same names in Python and Mojo
2. **Simplicity**: Fewer methods that do more
3. **Performance**: Batch by default, individual as convenience
4. **Type Safety**: Clear return types

### New API

```python
from omendb import DB, Vector

# Initialize
db = DB()  # Simple
db = DB.connect("path/to/db")  # Persistent
db = DB.memory()  # Explicit in-memory

# Core CRUD Operations
# --------------------

# CREATE/UPDATE (upsert semantics always)
db.put("id", vector)  # Individual
db.put("id", vector, metadata={"key": "value"})  # With metadata
db.put({"id1": vec1, "id2": vec2})  # Batch dict
db.put(ids=["id1", "id2"], vectors=[vec1, vec2])  # Batch lists
db.put(dataframe)  # From pandas

# READ
vec = db.get("id")  # Returns Vector object (not tuple!)
vec = db["id"]  # Dict-like access
vecs = db.get(["id1", "id2"])  # Batch get
vec.vector  # The actual vector data
vec.metadata  # The metadata
vec.id  # The ID

# DELETE  
db.delete("id")  # Individual
db.delete(["id1", "id2"])  # Batch

# SEARCH
results = db.search(vector, k=10)  # Simple
results = db.search(vector, k=10, filter={"type": "doc"})  # Filtered
results[0].id  # "doc_123"
results[0].score  # 0.95
results[0].vector  # [...] 
results[0].metadata  # {"type": "doc"}

# Bulk Operations
# ---------------

# Import/Export
db.import_numpy(array, ids)  # Zero-copy numpy
db.import_parquet("file.parquet")  # From parquet
db.export_numpy()  # -> (vectors, ids, metadata)
db.export_parquet("file.parquet")  # To parquet

# Stats & Info
len(db)  # Number of vectors
db.info()  # Detailed stats
db.dimension  # Vector dimension
db.algorithm  # "diskann"

# Advanced
# --------

# Memory-mapped mode
db = DB.mmap("path/to/db")  # Open memory-mapped
db.sync()  # Force sync to disk

# Server mode (future)
db = DB.connect("omendb://localhost:8080")  # Remote connection
```

### Native Mojo API (Matching Python)

```mojo
fn put(id: String, vector: List[Float32], metadata: Dict[String, String]) -> Bool
fn get(id: String) -> Optional[Vector]
fn delete(id: String) -> Bool
fn search(vector: List[Float32], k: Int) -> List[SearchResult]

# Batch operations use same names
fn put(ids: List[String], vectors: List[List[Float32]]) -> List[Bool]
fn get(ids: List[String]) -> List[Optional[Vector]]
```

## Return Type Design

### Vector Class
```python
@dataclass
class Vector:
    """A vector with metadata."""
    id: str
    vector: np.ndarray  # Or List[float]
    metadata: Dict[str, str]
    
    # Convenience methods
    def distance_to(self, other: Vector) -> float
    def normalize(self) -> Vector
```

### SearchResult Class
```python
@dataclass
class SearchResult(Vector):
    """A search result with score."""
    score: float  # Similarity score [0, 1]
    
    # Inherit id, vector, metadata from Vector
```

## Migration Path

### Compatibility Layer
```python
# Old API still works but deprecated
class DB:
    def add(self, id, vector, metadata=None):
        """Deprecated: Use put() instead."""
        warnings.warn("add() is deprecated, use put()", DeprecationWarning)
        return self.put(id, vector, metadata)
    
    def get(self, id):
        """Returns old tuple format for compatibility."""
        vec = self.get_vector(id)
        if vec:
            return (vec.vector, vec.metadata)
        return None
```

## Why This Design?

### 1. **put() instead of add()**
- Clearer upsert semantics
- Matches key-value stores (Redis, RocksDB)
- Shorter to type

### 2. **Vector object instead of tuple**
- Self-documenting (vec.vector vs vec[0])
- Extensible (can add methods)
- Type hints work better

### 3. **Dict-like access**
- Intuitive: `db["id"]` 
- Pythonic
- Works with existing tools

### 4. **Unified batch interface**
- `put(dict)` or `put(ids=, vectors=)`
- No separate add_batch() method
- Overloading is cleaner

### 5. **Memory-mapped as first-class**
- `DB.mmap()` makes it explicit
- Important for large datasets
- Clear performance expectations

## Performance Implications

### Batch by Default
```python
# Slow (multiple FFI calls)
for id, vec in items:
    db.put(id, vec)  # 1000 FFI calls

# Fast (single FFI call)  
db.put(items)  # 1 FFI call

# Auto-batching (transparent)
with db.batch():  # Context manager
    for id, vec in items:
        db.put(id, vec)  # Batched automatically
```

### Zero-Copy Operations
```python
# Current (copies data)
db.add_batch(numpy_array.tolist())  # Slow!

# New (zero-copy)
db.import_numpy(numpy_array)  # Direct memory access
```

## Implementation Priority

1. **Week 1**: Implement Vector/SearchResult classes
2. **Week 1**: Add put/get/delete with new signatures
3. **Week 2**: Add compatibility layer
4. **Week 2**: Update native.mojo to match
5. **Week 3**: Add import/export methods
6. **Month 2**: Deprecate old API

## Success Metrics

- [ ] All methods have consistent names in Python/Mojo
- [ ] Return types are objects, not tuples
- [ ] Batch operations are primary, not secondary
- [ ] Zero-copy is default for numpy
- [ ] Memory-mapped is first-class citizen
- [ ] Migration path is smooth

## Open Questions

1. Should we keep `add()` as alias for `put()`?
2. Should `search()` return generator for large results?
3. Should we support async operations?
4. How to handle collections/namespaces?

## Conclusion

This redesign makes OmenDB's API:
- **Simpler**: Fewer methods, clearer semantics
- **Faster**: Batch-first, zero-copy default
- **Modern**: Type hints, dataclasses, memory-mapped
- **Consistent**: Same names everywhere
- **Pythonic**: Dict-like access, context managers