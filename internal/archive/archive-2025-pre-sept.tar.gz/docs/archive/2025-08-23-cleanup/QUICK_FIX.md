# Quick Fix Guide

## Problem: 3K vec/s (need 50K+)
**Cause**: Using BruteForceIndex (500+ lines) as buffer
**Wrong**: Flushing buffer INTO DiskANN (`O(n log n)`)
**Right**: Build NEW DiskANN from all data (`O(n)`)

## Immediate Fix
```mojo
# Replace this mess in native.mojo
struct SimpleBuffer:
    var data: UnsafePointer[Float32]
    var size: Int
    
    @always_inline
    fn add(mut self, vec: DTypePointer) -> Bool:
        memcpy(self.data + self.size * dim, vec, dim * 4)
        self.size += 1
        return True
        
    fn build_index(self) -> DiskANN:
        return DiskANN.build(self.data, self.size)
```

## Test Command
```bash
cd ../omendb && pixi run mojo build omendb/native.mojo -o python/omendb/native.so --emit shared-lib && python -c "import omendb, time, numpy as np; db = omendb.DB(); vecs = np.random.randn(1000, 128).astype(np.float32); t = time.perf_counter(); [db.add(f'id_{i}', vecs[i]) for i in range(1000)]; print(f'{1000/(time.perf_counter()-t):.0f} vec/s')"
```

## Files to Change
1. `/Users/nick/github/omendb/omendb/omendb/native.mojo` - Replace buffer
2. `/Users/nick/github/omendb/omendb/omendb/algorithms/diskann.mojo` - Add build() method