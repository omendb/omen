# OmenDB Development Roadmap
*Last Updated: August 26, 2025*

## Executive Summary

OmenDB must achieve **basic correctness and stability** before adding features. 
Target: Competitive with Chroma by v0.3.0, approaching Qdrant by v1.0.

## What Can We Fix Now vs Blocked by Mojo

### ✅ Fixable Now (No Language Limitations)

| Priority | Task | Effort | Impact | Details |
|----------|------|--------|--------|---------|
| 1 | Memory Reporting | Low | Critical | Shows 0 MB - blocks optimization verification |
| 2 | Quantization Optimization | Medium | High | Use quantized vectors for search, dequantize on-the-fly for 8x total reduction |
| 3 | Configuration System | Low | Medium | Replace 50+ hardcoded values with Config struct |
| 4 | Linear Search → O(1) | Medium | High | Replace 65+ O(n) lookups with Dict |
| 5 | Error Handling (Partial) | Medium | High | Add checks before unsafe_value() calls |

### ❌ Blocked by Mojo (Language Limitations)

| Feature | Blocker | Workaround | ETA |
|---------|---------|------------|-----|
| Thread Safety | No Arc, Mutex, atomics | Single-threaded only | Mojo 2026 |
| Module Splitting | Import system limitations | Keep 3300-line monolith | Unknown |
| SIMD Optimizations | Compiler bugs | Use scalar (auto-vectorized) | Next release |
| Async/Await | Not in language | Manual double-buffering | On roadmap |
| Generic Collections | Limited generics | Type-specific implementations | In progress |

## Competitive Requirements Analysis

### Minimum Viable (Table Stakes)
Based on 2024-2025 research, ALL vector databases must have:
- **Correctness**: ≥95% recall, reproducible results
- **Performance**: <100ms P95 latency @ 1K QPS
- **Durability**: No data loss on crash, recovery < minutes
- **Availability**: 99.9% uptime (managed) or HA mode (self-hosted)
- **Observability**: Metrics for latency, throughput, errors

### Current Market Leaders

| Database | Stability | Key Features | Performance |
|----------|-----------|--------------|-------------|
| **Qdrant** | Production-grade | Advanced filtering, sharding, gRPC/REST | 0.5ms @ 1M vectors |
| **Weaviate** | Enterprise SLAs | Multi-modal, hybrid search, GraphQL | 50ms P95 @ 1M vectors |
| **Chroma** | Dev/prototype | Simple API, embedded, Python-native | 100ms P95 @ 500K vectors |
| **Pinecone** | Cloud SLA 99.95% | Fully managed, serverless, auto-scaling | <10ms tail latency |

### OmenDB Current Position
- **Strengths**: Best memory efficiency (29MB/100K), high throughput (80K vec/s)
- **Critical Gaps**: No crash safety, no filtering, no monitoring, single-threaded

## Version Targets

### v0.1.0-dev: Basic Correctness (Target: Q4 2025)
**Goal**: Zero crashes, complete correctness, single-threaded stability

**Must Have:**
- [ ] NO panics or crashes (replace all unsafe_value() with checks)
- [ ] 100% recovery success rate
- [ ] Accurate memory reporting
- [ ] Optimized quantization (8x reduction achieved)
- [ ] O(1) ID lookups (Dict-based)
- [ ] Configuration file support
- [ ] Basic error types (no unwrap/panic)

**Nice to Have:**
- [ ] Simple metadata filtering
- [ ] Collections/namespaces
- [ ] Basic metrics (insert/search counts)

**Explicitly Excluded:**
- Thread safety (blocked by Mojo)
- REST/gRPC APIs (focus on Python)
- Replication/sharding
- Advanced filtering

### v0.2.0: Feature Parity with Chroma (Target: Q1 2026)
**Goal**: Usable for development and prototyping

**Features:**
- [ ] Metadata filtering during search
- [ ] Collections support
- [ ] Batch update/delete
- [ ] Range/radius search
- [ ] Import/export utilities
- [ ] Basic monitoring dashboard
- [ ] Docker container

### v0.3.0: Production Readiness (Target: Q2 2026)
**Goal**: Safe for single-instance production use

**Features:**
- [ ] Thread safety (if Mojo supports)
- [ ] REST API with OpenAPI spec
- [ ] Prometheus metrics
- [ ] Backup/restore tools
- [ ] Performance guarantees (<10ms P95)
- [ ] 99.9% uptime capability
- [ ] Comprehensive test suite

### v1.0.0: Enterprise Grade (Target: Q3 2026)
**Goal**: Competitive with Qdrant

**Features:**
- [ ] Horizontal scaling/sharding
- [ ] Replication and HA
- [ ] Advanced filtering (complex predicates)
- [ ] Multiple language SDKs
- [ ] Authentication/authorization
- [ ] Encryption at rest
- [ ] Audit logging
- [ ] SLA guarantees

## Implementation Priority for v0.1.0

### Phase 1: Foundation (Week 1)
1. **Fix memory reporting** (2 hours)
   - Fix calculation showing 0 MB
   - Add proper accumulation
   - Test with various dataset sizes

2. **Create Config struct** (4 hours)
   - Centralize all magic numbers
   - Support config file loading
   - Environment variable overrides

### Phase 2: Memory Optimization (Week 2)
3. **Optimize quantization** (2-3 days)
   - Modify search to use quantized vectors
   - Implement on-the-fly dequantization
   - Verify 8x reduction achieved
   - Benchmark performance impact

### Phase 3: Performance (Week 3)
4. **Replace linear searches** (2-3 days)
   - Audit all O(n) operations
   - Replace with Dict lookups
   - Benchmark improvements
   - Ensure no regressions

### Phase 4: Safety (Week 4)
5. **Error handling overhaul** (1 week)
   - Replace all unsafe_value() calls
   - Add bounds checking
   - Create error types
   - Test error paths

### Phase 5: Validation (Week 5)
6. **Comprehensive testing** (1 week)
   - Stress tests (1M+ vectors)
   - Recovery tests
   - Error injection
   - Performance benchmarks

## Success Metrics for v0.1.0

### Correctness
- Zero panics in 24-hour stress test
- 100% recovery success rate
- ≥99% recall accuracy
- All tests passing

### Performance
- Memory: ≤12MB per 100K vectors (with quantization)
- Insert: ≥50K vec/s batch
- Search: ≤5ms P95 @ 100K vectors
- No memory leaks over 1M operations

### Stability
- Handle all error cases gracefully
- Consistent performance under load
- Deterministic behavior
- Clean shutdown

## Questions for Product Direction

1. **Target Market**: Should we optimize for embedded (Chroma-like) or server (Qdrant-like) use cases?

2. **Language Support**: Focus on Python only, or add Go/Rust/JS SDKs?

3. **Quantization Trade-off**: Acceptable accuracy loss for 8x memory savings? (typically 2-5% recall drop)

4. **Feature Priority**: Metadata filtering vs. performance optimization?

5. **Cloud Strategy**: Build cloud service or stay embedded-only?

## Competitive Positioning

### Our Differentiators
- **Memory Efficiency**: 10x better than competitors
- **Embedded First**: True zero-dependency embedding
- **Mojo Performance**: Potential for C++ speeds with Python syntax

### Our Weaknesses
- **Maturity**: Years behind established players
- **Features**: Missing filtering, multi-tenancy, APIs
- **Ecosystem**: No integrations, limited docs

### Strategy
1. **v0.1-0.2**: Match Chroma for embedded use cases
2. **v0.3-1.0**: Approach Qdrant for production use
3. **Post-1.0**: Differentiate on memory efficiency and Mojo performance

## Conclusion

**Immediate Focus**: Fix what we can now (memory reporting, quantization, linear searches) to achieve v0.1.0's goal of **zero crashes and basic correctness**.

**Blocked Items**: Accept that thread safety, SIMD, and module splitting must wait for Mojo improvements.

**Competitive Target**: Be as stable as Chroma by v0.3.0, as capable as Qdrant by v1.0.

The path is clear: **correctness first, features second, performance third**.