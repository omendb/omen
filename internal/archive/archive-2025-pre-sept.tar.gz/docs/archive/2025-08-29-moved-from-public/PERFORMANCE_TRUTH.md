# OmenDB Performance Truth Document

**Date**: August 22, 2025  
**Version**: v0.2.0-dev  
**Status**: Verified with comprehensive benchmarks

## 🎯 Single Source of Truth

### Core Performance (128D vectors - most common)
- **Ingestion**: 1,400 vectors/second
- **Search**: 0.50ms latency
- **Batch speedup**: NONE (1.0x - same as single adds)
- **Scaling**: Linear (consistent from 100 to 50K vectors)

### Performance by Dimension
| Dimension | Ingestion (vec/s) | Search (ms) | Use Case |
|-----------|-------------------|-------------|----------|
| 64D       | 2,700             | 0.35        | Simple embeddings |
| **128D**  | **1,400**         | **0.50**    | **Standard (most ML)** |
| 256D      | 750               | 0.80        | Image embeddings |
| 384D      | 500               | 1.05        | Sentence transformers |
| 512D      | 375               | 1.40        | BERT/RoBERTa |
| 768D      | 250               | 1.95        | Large transformers |
| 1024D     | 190               | 2.60        | GPT embeddings |

### Scaling Performance (128D)
| Dataset Size | Ingestion (vec/s) | Search (ms) |
|--------------|-------------------|-------------|
| 100          | 1,443             | 0.60        |
| 1,000        | 1,472             | 0.64        |
| 10,000       | 1,396             | 0.68        |
| 50,000       | 1,341             | 0.75        |

## ❌ Wrong Claims to Remove

### Do NOT claim:
- ❌ "23K vec/s" or "40K vec/s" - Never achieved
- ❌ "96K vec/s" - Old incorrect measurement
- ❌ "157K vec/s" - Fantasy number
- ❌ "10x batch speedup" - No speedup exists
- ❌ "HNSW algorithm" - Uses DiskANN only
- ❌ "Automatic algorithm selection" - Always DiskANN

### Do NOT reference:
- ❌ HNSW migration
- ❌ Algorithm switching based on size
- ❌ Hybrid Rust/Mojo implementation
- ❌ Zero-copy FFI (not implemented)

## ✅ Correct Claims

### Architecture
- **Algorithm**: Pure DiskANN with buffer
- **Implementation**: 100% Mojo (no C/Rust)
- **Storage**: SnapshotStorage with binary format
- **Persistence**: Working checkpoint and recovery

### Performance Characteristics
- **Batch vs Single**: Same speed (no optimization benefit)
- **Dimension scaling**: Inversely proportional
- **Dataset scaling**: Linear (very consistent)
- **Memory**: ~16KB per vector

### Unique Features
- **Instant startup**: No index loading
- **No rebuilds**: DiskANN handles incremental updates
- **Persistence**: Atomic snapshots with recovery
- **Embedded**: Single process, like SQLite

## 📝 Standard Marketing Copy

### Short Version
"OmenDB: Embedded vector database with 1,400 vec/s ingestion and sub-millisecond search for 128D vectors."

### Medium Version
"OmenDB delivers consistent 1,400 vectors/second ingestion with 0.5ms search latency for standard 128-dimensional vectors. Pure Mojo implementation with DiskANN algorithm provides linear scaling from 100 to 50K+ vectors."

### Technical Version
"OmenDB uses DiskANN graph-based indexing with robust pruning for bounded degree graphs. Performance scales from 2,700 vec/s at 64D to 375 vec/s at 512D. No batch optimization needed - single adds perform identically to batch operations."

## 🚫 Common Mistakes

1. **Claiming batch speedup** - There is none
2. **Referencing HNSW** - Removed in v0.2.0
3. **Using old performance numbers** - Always use this doc
4. **Saying "automatic algorithm selection"** - It's always DiskANN
5. **Mentioning Rust integration** - Pure Mojo only

## 📊 Benchmark Command

To verify these numbers:
```bash
python benchmark_comprehensive.py
```

Expected output should match tables above ±5%

## 🔍 Quick Audit Commands

Find wrong numbers:
```bash
grep -r "23K\|40K\|96K\|157K" --include="*.md" --include="*.py"
```

Find HNSW references:
```bash
grep -ri "hnsw" --include="*.mojo" --include="*.py" --include="*.md"
```

## 📋 When to Update This Document

- After major algorithm changes
- After optimization work
- When adding new dimensions to benchmarks
- Never without running comprehensive benchmarks

---

**Remember**: When in doubt, run benchmarks. Never guess performance.